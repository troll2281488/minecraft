// @ts-nocheck
import * as THREE from "three";

import { initializeApp } from "firebase/app";
import { getDatabase, ref, set, get, update, push, remove, onValue, onChildAdded, onDisconnect, runTransaction } from "firebase/database";

    // =========================================================================
    // 1. FIREBASE REALTIME DATABASE MULTIPLAYER SETUP
    // =========================================================================
    const firebaseConfig = {
      apiKey: "AIzaSyCf1UO6hrlYXR2GYcgGZUfsbit4Zav1m4E",
      authDomain: "trolldonor.firebaseapp.com",
      databaseURL: "https://trolldonor-default-rtdb.firebaseio.com",
      projectId: "trolldonor",
      storageBucket: "trolldonor.firebasestorage.app",
      messagingSenderId: "761197257675",
      appId: "1:761197257675:web:53dc596cf349d0cd474c4e",
      measurementId: "G-B658V7L7ES"
    };

    let fbDb = null;
    try {
      const fbApp = initializeApp(firebaseConfig);
      fbDb = getDatabase(fbApp);
    } catch (err) {
      console.warn("Firebase offline fallback:", err);
    }

    const MP = {
      active: false,
      isHost: false,
      roomId: null,
      playerId: "p_" + Math.random().toString(36).slice(2, 10),
      nickname: "Steve",
      pingMs: 24,
      remotePlayers: new Map(),
      unsubs: [],
      syncAccum: 0,
      stateAccum: 0,
      sweepTimer: null,
      pingTimer: null
    };

    // =========================================================================
    // 2. WEB AUDIO API PROCEDURAL SOUND ENGINE
    // =========================================================================
    const SFX = {
      ctx: null,
      volume: 0.7,
      ensure() {
        if (!this.ctx) {
          const AC = window.AudioContext || window.webkitAudioContext;
          if (AC) this.ctx = new AC();
        }
        if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
      },
      tone(freq, type = "square", dur = 0.08, gainVal = 0.14, slideTo = null) {
        if (this.volume <= 0) return;
        this.ensure();
        if (!this.ctx) return;
        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, now);
        if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), now + dur);
        gain.gain.setValueAtTime(gainVal * this.volume, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + dur);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + dur);
      },
      click() { this.tone(640, "square", 0.04, 0.11, 410); },
      step(mat = "grass") {
        const f = mat === "stone" ? 155 : mat === "wood" ? 205 : 115;
        this.tone(f + Math.random() * 30, "triangle", 0.05, 0.07, 58);
      },
      breakBlock(mat = "grass") {
        const f = mat === "stone" ? 230 : mat === "wood" ? 280 : 175;
        this.tone(f, "sawtooth", 0.11, 0.15, 68);
      },
      placeBlock() { this.tone(310, "triangle", 0.07, 0.14, 185); },
      hurt() { this.tone(185, "sawtooth", 0.18, 0.22, 72); },
      shieldBlock() { this.tone(420, "square", 0.09, 0.2, 220); },
      bowShoot() { this.tone(520, "triangle", 0.12, 0.16, 190); },
      eyeLaunch() { this.tone(740, "sine", 0.28, 0.16, 1180); },
      pickup() { this.tone(880, "sine", 0.07, 0.11, 1320); },
      levelUp() {
        this.tone(523, "triangle", 0.12, 0.15);
        setTimeout(() => this.tone(659, "triangle", 0.12, 0.15), 90);
        setTimeout(() => this.tone(784, "triangle", 0.22, 0.16), 180);
      },
      explode() { this.tone(92, "sawtooth", 0.55, 0.35, 24); }
    };

    // =========================================================================
    // 3. BLOCKS, ITEMS & MUTED ALPHA/BETA 16x16 PIXEL TEXTURES
    // =========================================================================
    const B = {
      AIR: 0, GRASS: 1, DIRT: 2, STONE: 3, COBBLESTONE: 4, BEDROCK: 5,
      OAK_LOG: 6, OAK_PLANKS: 7, OAK_LEAVES: 8, SAND: 9, GRAVEL: 10,
      COAL_ORE: 11, IRON_ORE: 12, GOLD_ORE: 13, DIAMOND_ORE: 14,
      REDSTONE_ORE: 15, LAPIS_ORE: 16, CRAFTING_TABLE: 17, FURNACE: 18,
      CHEST: 19, TORCH: 20, GLASS: 21, WATER: 22, LAVA: 23,
      OBSIDIAN: 24, NETHERRACK: 25, SOUL_SAND: 26, GLOWSTONE: 27,
      NETHER_PORTAL: 28, END_STONE: 29, END_PORTAL_FRAME: 30,
      END_PORTAL_FRAME_EYE: 31, END_PORTAL: 32, FARMLAND: 33,
      WHEAT_1: 34, WHEAT_7: 35, POPPY: 36, DANDELION: 37,
      STONE_BRICKS: 38, DRAGON_EGG: 39, BOOKSHELF: 40, WOOL_WHITE: 41,
      BRICKS: 42, TNT: 43, HAY_BLOCK: 44, SANDSTONE: 45,
      NETHER_BRICKS: 46, QUARTZ_ORE: 47, GOLD_BLOCK: 48,
      BED_FOOT: 49, BED_HEAD: 50, CRYING_OBSIDIAN: 51, ANCIENT_DEBRIS: 52, NETHER_GOLD_ORE: 53, BASALT: 54, BLACKSTONE: 55, SOUL_SOIL: 56
    };

    const BLOCK_PROPS = {
      [B.AIR]: { name: "Воздух", solid: false, transparent: true, hardness: 0 },
      [B.GRASS]: { name: "Дёрн", solid: true, hardness: 0.6, mat: "grass", drop: B.DIRT },
      [B.DIRT]: { name: "Земля", solid: true, hardness: 0.5, mat: "grass", drop: B.DIRT },
      [B.STONE]: { name: "Камень", solid: true, hardness: 1.5, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.COBBLESTONE },
      [B.COBBLESTONE]: { name: "Булыжник", solid: true, hardness: 2.0, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.COBBLESTONE },
      [B.BEDROCK]: { name: "Бедрок", solid: true, hardness: -1, mat: "stone" },
      [B.OAK_LOG]: { name: "Дубовое бревно", solid: true, hardness: 1.6, mat: "wood", drop: B.OAK_LOG },
      [B.OAK_PLANKS]: { name: "Дубовые доски", solid: true, hardness: 1.4, mat: "wood", drop: B.OAK_PLANKS },
      [B.OAK_LEAVES]: { name: "Листва дуба", solid: true, transparent: true, hardness: 0.2, mat: "grass", drop: "apple_chance" },
      [B.SAND]: { name: "Песок", solid: true, hardness: 0.5, mat: "grass", drop: B.SAND },
      [B.GRAVEL]: { name: "Гравий", solid: true, hardness: 0.6, mat: "grass", drop: B.GRAVEL },
      [B.COAL_ORE]: { name: "Угольная руда", solid: true, hardness: 2.4, mat: "stone", tool: "pickaxe", minTier: 1, drop: "coal" },
      [B.IRON_ORE]: { name: "Железная руда", solid: true, hardness: 2.8, mat: "stone", tool: "pickaxe", minTier: 2, drop: B.IRON_ORE },
      [B.GOLD_ORE]: { name: "Золотая руда", solid: true, hardness: 2.8, mat: "stone", tool: "pickaxe", minTier: 3, drop: B.GOLD_ORE },
      [B.DIAMOND_ORE]: { name: "Алмазная руда", solid: true, hardness: 3.2, mat: "stone", tool: "pickaxe", minTier: 3, drop: "diamond" },
      [B.REDSTONE_ORE]: { name: "Редстоуновая руда", solid: true, hardness: 2.8, mat: "stone", tool: "pickaxe", minTier: 3, drop: "redstone" },
      [B.LAPIS_ORE]: { name: "Лазуритовая руда", solid: true, hardness: 2.6, mat: "stone", tool: "pickaxe", minTier: 2, drop: "lapis" },
      [B.CRAFTING_TABLE]: { name: "Верстак", solid: true, hardness: 1.5, mat: "wood", drop: B.CRAFTING_TABLE, interactive: "crafting" },
      [B.FURNACE]: { name: "Печь", solid: true, hardness: 2.2, mat: "stone", drop: B.FURNACE, interactive: "furnace" },
      [B.CHEST]: { name: "Сундук", solid: true, hardness: 1.5, mat: "wood", drop: B.CHEST, interactive: "chest" },
      [B.TORCH]: { name: "Факел", solid: false, transparent: true, hardness: 0.05, mat: "wood", drop: B.TORCH },
      [B.GLASS]: { name: "Стекло", solid: true, transparent: true, hardness: 0.3, mat: "stone", drop: null },
      [B.WATER]: { name: "Вода", solid: false, transparent: true, fluid: true, hardness: -1 },
      [B.LAVA]: { name: "Лава", solid: false, transparent: true, fluid: true, hardness: -1 },
      [B.OBSIDIAN]: { name: "Обсидиан", solid: true, hardness: 8.5, blastResistance: 1200, mat: "stone", tool: "pickaxe", minTier: 4, drop: B.OBSIDIAN },
      [B.NETHERRACK]: { name: "Незерак", solid: true, hardness: 0.5, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.NETHERRACK },
      [B.SOUL_SAND]: { name: "Песок душ", solid: true, hardness: 0.5, mat: "grass", drop: B.SOUL_SAND },
      [B.GLOWSTONE]: { name: "Светокамень", solid: true, hardness: 0.4, mat: "stone", drop: B.GLOWSTONE },
      [B.NETHER_PORTAL]: { name: "Портал в Нижний мир", solid: false, transparent: true, hardness: -1 },
      [B.END_STONE]: { name: "Эндерняк", solid: true, hardness: 2.4, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.END_STONE },
      [B.END_PORTAL_FRAME]: { name: "Рамка портала в Край", solid: true, hardness: 2.0, mat: "stone", drop: B.END_PORTAL_FRAME },
      [B.END_PORTAL_FRAME_EYE]: { name: "Рамка портала с Оком", solid: true, hardness: 2.0, mat: "stone", drop: B.END_PORTAL_FRAME },
      [B.END_PORTAL]: { name: "Портал в Край", solid: false, transparent: true, hardness: -1 },
      [B.FARMLAND]: { name: "Грядка", solid: true, hardness: 0.5, mat: "grass", drop: B.DIRT },
      [B.WHEAT_1]: { name: "Ростки пшеницы", solid: false, transparent: true, cross: true, hardness: 0.05, drop: "wheat_seeds" },
      [B.WHEAT_7]: { name: "Спелая пшеница", solid: false, transparent: true, cross: true, hardness: 0.05, drop: "wheat" },
      [B.POPPY]: { name: "Мак", solid: false, transparent: true, cross: true, hardness: 0.05, drop: B.POPPY },
      [B.DANDELION]: { name: "Одуванчик", solid: false, transparent: true, cross: true, hardness: 0.05, drop: B.DANDELION },
      [B.STONE_BRICKS]: { name: "Каменные кирпичи", solid: true, hardness: 1.8, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.STONE_BRICKS },
      [B.DRAGON_EGG]: { name: "Яйцо дракона", solid: true, hardness: 1.0, mat: "stone", drop: B.DRAGON_EGG },
      [B.BOOKSHELF]: { name: "Книжная полка", solid: true, hardness: 1.2, mat: "wood", drop: B.BOOKSHELF },
      [B.WOOL_WHITE]: { name: "Белая шерсть", solid: true, hardness: 0.6, mat: "grass", drop: B.WOOL_WHITE },
      [B.BRICKS]: { name: "Кирпичи", solid: true, hardness: 2.0, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.BRICKS },
      [B.TNT]: { name: "Динамит (TNT)", solid: true, hardness: 0.2, mat: "grass", drop: B.TNT },
      [B.HAY_BLOCK]: { name: "Сноп сена", solid: true, hardness: 0.5, mat: "grass", drop: B.HAY_BLOCK },
      [B.SANDSTONE]: { name: "Песчаник", solid: true, hardness: 1.0, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.SANDSTONE },
      [B.NETHER_BRICKS]: { name: "Адские кирпичи", solid: true, hardness: 2.0, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.NETHER_BRICKS },
      [B.QUARTZ_ORE]: { name: "Незер-кварцевая руда", solid: true, hardness: 2.2, mat: "stone", tool: "pickaxe", minTier: 1, drop: "quartz" },
      [B.GOLD_BLOCK]: { name: "Золотой блок", solid: true, hardness: 2.5, mat: "stone", tool: "pickaxe", minTier: 2, drop: B.GOLD_BLOCK },
      [B.BED_FOOT]: { name: "Кровать (низ)", solid: true, hardness: 0.3, mat: "wood", drop: "bed", interactive: "bed" },
      [B.BED_HEAD]: { name: "Кровать (изголовье)", solid: true, hardness: 0.3, mat: "wood", drop: "bed", interactive: "bed" },
      [B.CRYING_OBSIDIAN]: { name: "Плачущий обсидиан", solid: true, hardness: 8.5, blastResistance: 1200, mat: "stone", tool: "pickaxe", minTier: 4, drop: B.CRYING_OBSIDIAN },
      [B.ANCIENT_DEBRIS]: { name: "Древние обломки", solid: true, hardness: 30, blastResistance: 1200, mat: "stone", tool: "pickaxe", minTier: 4, drop: "ancient_debris" },
      [B.NETHER_GOLD_ORE]: { name: "Незерская золотая руда", solid: true, hardness: 3, mat: "stone", tool: "pickaxe", minTier: 1, drop: "gold_ingot" },
      [B.BASALT]: { name: "Базальт", solid: true, hardness: 1.25, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.BASALT },
      [B.BLACKSTONE]: { name: "Чернит", solid: true, hardness: 1.5, mat: "stone", tool: "pickaxe", minTier: 1, drop: B.BLACKSTONE },
      [B.SOUL_SOIL]: { name: "Почва душ", solid: true, hardness: 0.5, mat: "grass", drop: B.SOUL_SOIL }
    };

    // Legacy 1.12-era creative blocks: real numeric block IDs with collision and fallback pixel materials.
    const LEGACY_BLOCKS = [["GRANITE","Гранит","stone"],["POLISHED_GRANITE","Полированный гранит","stone"],["DIORITE","Диорит","stone"],["POLISHED_DIORITE","Полированный диорит","stone"],["ANDESITE","Андезит","stone"],["POLISHED_ANDESITE","Полированный андезит","stone"],["COARSE_DIRT","Каменистая земля","earth"],["PODZOL","Подзол","earth"],["MYCELIUM","Мицелий","earth"],["GRASS_PATH","Тропа","earth"],["CLAY","Глина","earth"],["SPONGE","Губка","earth"],["WET_SPONGE","Мокрая губка","earth"],["SNOW_BLOCK","Снежный блок","ice"],["PACKED_ICE","Плотный лёд","ice"],["SPRUCE_LOG","Еловое бревно","wood"],["BIRCH_LOG","Берёзовое бревно","wood"],["JUNGLE_LOG","Тропическое бревно","wood"],["ACACIA_LOG","Акациевое бревно","wood"],["DARK_OAK_LOG","Бревно тёмного дуба","wood"],["SPRUCE_PLANKS","Еловые доски","wood"],["BIRCH_PLANKS","Берёзовые доски","wood"],["JUNGLE_PLANKS","Тропические доски","wood"],["ACACIA_PLANKS","Акациевые доски","wood"],["DARK_OAK_PLANKS","Доски тёмного дуба","wood"],["SPRUCE_LEAVES","Еловая листва","leaf"],["BIRCH_LEAVES","Берёзовая листва","leaf"],["JUNGLE_LEAVES","Тропическая листва","leaf"],["ACACIA_LEAVES","Акациевая листва","leaf"],["DARK_OAK_LEAVES","Листва тёмного дуба","leaf"],["SPRUCE_SAPLING","Саженец ели","leaf"],["BIRCH_SAPLING","Саженец берёзы","leaf"],["JUNGLE_SAPLING","Саженец тропического дерева","leaf"],["ACACIA_SAPLING","Саженец акации","leaf"],["DARK_OAK_SAPLING","Саженец тёмного дуба","leaf"],["MOSSY_COBBLESTONE","Замшелый булыжник","stone"],["MOSSY_STONE_BRICKS","Замшелый каменный кирпич","stone"],["CRACKED_STONE_BRICKS","Потрескавшийся каменный кирпич","stone"],["CHISELED_STONE_BRICKS","Резной каменный кирпич","stone"],["PRISMARINE","Призмарин","ocean"],["PRISMARINE_BRICKS","Призмариновые кирпичи","ocean"],["DARK_PRISMARINE","Тёмный призмарин","ocean"],["SEA_LANTERN","Морской фонарь","glow"],["RED_SAND","Красный песок","earth"],["RED_SANDSTONE","Красный песчаник","earth"],["SMOOTH_RED_SANDSTONE","Гладкий красный песчаник","earth"],["CHISELED_RED_SANDSTONE","Резной красный песчаник","earth"],["QUARTZ_BLOCK","Кварцевый блок","quartz"],["QUARTZ_PILLAR","Кварцевая колонна","quartz"],["CHISELED_QUARTZ","Резной кварцевый блок","quartz"],["SMOOTH_QUARTZ","Гладкий кварц","quartz"],["COAL_BLOCK","Угольный блок","ore"],["IRON_BLOCK","Железный блок","ore"],["DIAMOND_BLOCK","Алмазный блок","gem"],["EMERALD_BLOCK","Изумрудный блок","gem"],["LAPIS_BLOCK","Лазуритовый блок","gem"],["REDSTONE_BLOCK","Редстоуновый блок","ore"],["SPONGE_BLOCK","Блок губки","earth"],["HARDENED_CLAY","Обожжённая глина","earth"],["WHITE_TERRACOTTA","Белая керамика","earth"],["WHITE_WOOL","Белая шерсть","wool"],["ORANGE_WOOL","Оранжевая шерсть","wool"],["MAGENTA_WOOL","Пурпурная шерсть","wool"],["LIGHT_BLUE_WOOL","Голубая шерсть","wool"],["YELLOW_WOOL","Жёлтая шерсть","wool"],["LIME_WOOL","Лаймовая шерсть","wool"],["PINK_WOOL","Розовая шерсть","wool"],["GRAY_WOOL","Серая шерсть","wool"],["LIGHT_GRAY_WOOL","Светло-серая шерсть","wool"],["CYAN_WOOL","Бирюзовая шерсть","wool"],["PURPLE_WOOL","Фиолетовая шерсть","wool"],["BLUE_WOOL","Синяя шерсть","wool"],["BROWN_WOOL","Коричневая шерсть","wool"],["GREEN_WOOL","Зелёная шерсть","wool"],["RED_WOOL","Красная шерсть","wool"],["BLACK_WOOL","Чёрная шерсть","wool"],["WHITE_CONCRETE","Белый бетон","wool"],["ORANGE_CONCRETE","Оранжевый бетон","wool"],["MAGENTA_CONCRETE","Пурпурный бетон","wool"],["LIGHT_BLUE_CONCRETE","Голубой бетон","wool"],["YELLOW_CONCRETE","Жёлтый бетон","wool"],["LIME_CONCRETE","Лаймовый бетон","wool"],["PINK_CONCRETE","Розовый бетон","wool"],["GRAY_CONCRETE","Серый бетон","wool"],["CYAN_CONCRETE","Бирюзовый бетон","wool"],["PURPLE_CONCRETE","Фиолетовый бетон","wool"],["BLUE_CONCRETE","Синий бетон","wool"],["BROWN_CONCRETE","Коричневый бетон","wool"],["GREEN_CONCRETE","Зелёный бетон","wool"],["RED_CONCRETE","Красный бетон","wool"],["BLACK_CONCRETE","Чёрный бетон","wool"],["WHITE_STAINED_GLASS","Белое стекло","glass"],["ORANGE_STAINED_GLASS","Оранжевое стекло","glass"],["MAGENTA_STAINED_GLASS","Пурпурное стекло","glass"],["LIGHT_BLUE_STAINED_GLASS","Голубое стекло","glass"],["YELLOW_STAINED_GLASS","Жёлтое стекло","glass"],["LIME_STAINED_GLASS","Лаймовое стекло","glass"],["PINK_STAINED_GLASS","Розовое стекло","glass"],["GRAY_STAINED_GLASS","Серое стекло","glass"],["CYAN_STAINED_GLASS","Бирюзовое стекло","glass"],["PURPLE_STAINED_GLASS","Фиолетовое стекло","glass"],["BLUE_STAINED_GLASS","Синее стекло","glass"],["BROWN_STAINED_GLASS","Коричневое стекло","glass"],["GREEN_STAINED_GLASS","Зелёное стекло","glass"],["RED_STAINED_GLASS","Красное стекло","glass"],["BLACK_STAINED_GLASS","Чёрное стекло","glass"],["PURPUR_BLOCK","Пурпурный блок","purpur"],["PURPUR_PILLAR","Пурпурная колонна","purpur"],["END_ROD_BLOCK","Стержень Края","glow"],["CHORUS_BLOCK","Блок хоруса","purpur"],["MAGMA_BLOCK","Блок магмы","nether"],["NETHER_WART_BLOCK","Блок адского нароста","nether"],["RED_NETHER_BRICKS","Красные незерские кирпичи","nether"],["BONE_BLOCK","Костяной блок","bone"],["OBSERVER","Наблюдатель","tech"],["SLIME_BLOCK","Слизневый блок","slime"],["HAY_BALE","Тюк сена","earth"],["COMMAND_BLOCK","Командный блок","tech"],["BEACON","Маяк","glow"],["ENCHANTING_TABLE","Стол зачаровывания","tech"],["BREWING_STAND_BLOCK","Зельеварка","tech"],["CAULDRON","Котёл","tech"],["ANVIL","Наковальня","iron"],["HOPPER","Воронка","iron"],["DISPENSER","Раздатчик","tech"],["DROPPER","Выбрасыватель","tech"],["NOTE_BLOCK","Нотный блок","wood"],["JUKEBOX","Проигрыватель","wood"],["FENCE","Дубовый забор","wood"],["COBBLESTONE_WALL","Булыжная ограда","stone"],["IRON_BARS","Железные прутья","iron"],["LADDER","Лестница","wood"],["TRAPDOOR","Люк","wood"],["IRON_TRAPDOOR","Железный люк","iron"],["DAYLIGHT_SENSOR","Датчик дневного света","tech"],["TNT_BLOCK","Блок динамита","nether"],["END_STONE_BRICKS","Кирпичи Края","stone"]];
    for (const [key, name, palette] of LEGACY_BLOCKS) {
      if (B[key] !== undefined) continue;
      const id = Math.max(...Object.values(B).filter(v => typeof v === "number")) + 1;
      B[key] = id;
      BLOCK_PROPS[id] = { name, solid: true, transparent: palette === "glass", hardness: palette === "glass" ? 0.3 : 1.2, mat: palette === "wood" ? "wood" : "stone", drop: id, legacyPalette: palette };
    }

    const ITEMS = {
      stick: { name: "Палка", cat: "misc", stack: 64 },
      emerald: { name: "Изумруд", cat: "misc", stack: 64 },
      quartz: { name: "Незер-кварц", cat: "misc", stack: 64 },
      wither_skull: { name: "Череп визер-скелета", cat: "misc", stack: 64 },
      bed: { name: "Красная кровать", cat: "misc", stack: 1 },
      coal: { name: "Уголь", cat: "misc", stack: 64 },
      iron_ingot: { name: "Железный слиток", cat: "misc", stack: 64 },
      gold_ingot: { name: "Золотой слиток", cat: "misc", stack: 64 },
      diamond: { name: "Алмаз", cat: "misc", stack: 64 },
      redstone: { name: "Редстоун", cat: "misc", stack: 64 },
      lapis: { name: "Лазурит", cat: "misc", stack: 64 },
      flint_and_steel: { name: "Огниво", cat: "tools", stack: 1 },
      bucket_water: { name: "Ведро воды", cat: "tools", stack: 1 },
      bucket_lava: { name: "Ведро лавы", cat: "tools", stack: 1 },
      ender_pearl: { name: "Жемчуг Эндера", cat: "misc", stack: 16 },
      blaze_rod: { name: "Огненный стержень", cat: "misc", stack: 64 },
      blaze_powder: { name: "Огненный порошок", cat: "misc", stack: 64 },
      ender_eye: { name: "Око Края", cat: "misc", stack: 64 },
      apple: { name: "Яблоко", cat: "armor_food", stack: 64, food: 4 },
      egg: { name: "Яйцо", cat: "misc", stack: 16 },
      pumpkin: { name: "Тыква", cat: "misc", stack: 64 },
      bowl: { name: "Миска", cat: "misc", stack: 64 },
      milk_bucket: { name: "Ведро молока", cat: "misc", stack: 1 },
      bucket: { name: "Пустое ведро", cat: "misc", stack: 16 },
      red_mushroom: { name: "Красный гриб", cat: "misc", stack: 64 },
      brown_mushroom: { name: "Коричневый гриб", cat: "misc", stack: 64 },
      bread: { name: "Хлеб", cat: "armor_food", stack: 64, food: 5 },
      cooked_beef: { name: "Жареная говядина", cat: "armor_food", stack: 64, food: 8 },
      raw_beef: { name: "Сырая говядина", cat: "armor_food", stack: 64, food: 3 },
      raw_chicken: { name: "Сырая курятина", cat: "armor_food", stack: 64, food: 2 },
      cooked_chicken: { name: "Жареная курятина", cat: "armor_food", stack: 64, food: 6 },
      potato: { name: "Картофель", cat: "misc", stack: 64 },
      baked_potato: { name: "Печёный картофель", cat: "armor_food", stack: 64, food: 5 },
      carrot: { name: "Морковь", cat: "armor_food", stack: 64, food: 3 },
      pumpkin_pie: { name: "Тыквенный пирог", cat: "armor_food", stack: 64, food: 8 },
      golden_carrot: { name: "Золотая морковь", cat: "armor_food", stack: 64, food: 6 },
      golden_apple: { name: "Золотое яблоко", cat: "armor_food", stack: 64, food: 8 },
      wheat: { name: "Пшеница", cat: "misc", stack: 64 },
      wheat_seeds: { name: "Семена пшеницы", cat: "misc", stack: 64 },
      feather: { name: "Перо", cat: "misc", stack: 64 },
      bone: { name: "Кость", cat: "misc", stack: 64 },
      string: { name: "Нить", cat: "misc", stack: 64 },
      bow: { name: "Лук", cat: "tools", stack: 1 },
      arrow: { name: "Стрела", cat: "tools", stack: 64 },
      shield: { name: "Щит", cat: "armor_food", stack: 1 },
      leather_helmet: { name: "Кожаный шлем", cat: "armor_food", stack: 1, armor: 1, equip: "head" },
      leather_chestplate: { name: "Кожаная куртка", cat: "armor_food", stack: 1, armor: 3, equip: "chest" },
      leather_leggings: { name: "Кожаные поножи", cat: "armor_food", stack: 1, armor: 2, equip: "legs" },
      leather_boots: { name: "Кожаные ботинки", cat: "armor_food", stack: 1, armor: 1, equip: "feet" },
      chainmail_helmet: { name: "Кольчужный шлем", cat: "armor_food", stack: 1, armor: 2, equip: "head" },
      chainmail_chestplate: { name: "Кольчужный нагрудник", cat: "armor_food", stack: 1, armor: 5, equip: "chest" },
      chainmail_leggings: { name: "Кольчужные поножи", cat: "armor_food", stack: 1, armor: 4, equip: "legs" },
      chainmail_boots: { name: "Кольчужные ботинки", cat: "armor_food", stack: 1, armor: 1, equip: "feet" },
      gold_helmet: { name: "Золотой шлем", cat: "armor_food", stack: 1, armor: 2, equip: "head" },
      gold_chestplate: { name: "Золотой нагрудник", cat: "armor_food", stack: 1, armor: 5, equip: "chest" },
      gold_leggings: { name: "Золотые поножи", cat: "armor_food", stack: 1, armor: 3, equip: "legs" },
      gold_boots: { name: "Золотые ботинки", cat: "armor_food", stack: 1, armor: 1, equip: "feet" },
      iron_helmet: { name: "Железный шлем", cat: "armor_food", stack: 1, armor: 2, equip: "head" },
      iron_chestplate: { name: "Железный нагрудник", cat: "armor_food", stack: 1, armor: 6, equip: "chest" },
      diamond_helmet: { name: "Алмазный шлем", cat: "armor_food", stack: 1, armor: 3, equip: "head" },
      diamond_chestplate: { name: "Алмазный нагрудник", cat: "armor_food", stack: 1, armor: 8, equip: "chest" },
      iron_leggings: { name: "Железные поножи", cat: "armor_food", stack: 1, armor: 5, equip: "legs" },
      iron_boots: { name: "Железные ботинки", cat: "armor_food", stack: 1, armor: 2, equip: "feet" },
      diamond_leggings: { name: "Алмазные поножи", cat: "armor_food", stack: 1, armor: 6, equip: "legs" },
      diamond_boots: { name: "Алмазные ботинки", cat: "armor_food", stack: 1, armor: 3, equip: "feet" },
      leather: { name: "Кожа", cat: "misc", stack: 64 },
      ancient_debris: { name: "Древние обломки", cat: "misc", stack: 64 },
      netherite_scrap: { name: "Незеритовый лом", cat: "misc", stack: 64 },
      netherite_ingot: { name: "Незеритовый слиток", cat: "misc", stack: 64 },
      netherite_helmet: { name: "Незеритовый шлем", cat: "armor_food", stack: 1, armor: 3, equip: "head", toughness: 3 },
      netherite_chestplate: { name: "Незеритовый нагрудник", cat: "armor_food", stack: 1, armor: 8, equip: "chest", toughness: 3 },
      netherite_leggings: { name: "Незеритовые поножи", cat: "armor_food", stack: 1, armor: 6, equip: "legs", toughness: 3 },
      netherite_boots: { name: "Незеритовые ботинки", cat: "armor_food", stack: 1, armor: 3, equip: "feet", toughness: 3 },
      elytra: { name: "Элитры", cat: "armor_food", stack: 1, equip: "chest", elytra: true },
      netherite_pickaxe: { name: "Незеритовая кирка", cat: "tools", stack: 1, tool: "pickaxe", tier: 5, speed: 9.5 },
      netherite_sword: { name: "Незеритовый меч", cat: "tools", stack: 1, damage: 9 },
      trident: { name: "Трезубец", cat: "tools", stack: 1, damage: 9, trident: true },
      wood_pickaxe: { name: "Деревянная кирка", cat: "tools", stack: 1, tool: "pickaxe", tier: 1, speed: 2.2 },
      stone_pickaxe: { name: "Каменная кирка", cat: "tools", stack: 1, tool: "pickaxe", tier: 2, speed: 4.0 },
      iron_pickaxe: { name: "Железная кирка", cat: "tools", stack: 1, tool: "pickaxe", tier: 3, speed: 6.0 },
      diamond_pickaxe: { name: "Алмазная кирка", cat: "tools", stack: 1, tool: "pickaxe", tier: 4, speed: 8.5 },
      wood_axe: { name: "Деревянный топор", cat: "tools", stack: 1, tool: "axe", tier: 1, speed: 2.4, damage: 4 },
      stone_axe: { name: "Каменный топор", cat: "tools", stack: 1, tool: "axe", tier: 2, speed: 4.0, damage: 5 },
      iron_axe: { name: "Железный топор", cat: "tools", stack: 1, tool: "axe", tier: 3, speed: 6.0, damage: 6 },
      diamond_axe: { name: "Алмазный топор", cat: "tools", stack: 1, tool: "axe", tier: 4, speed: 8.0, damage: 7 },
      wood_sword: { name: "Деревянный меч", cat: "tools", stack: 1, damage: 4 },
      stone_sword: { name: "Каменный меч", cat: "tools", stack: 1, damage: 5 },
      iron_sword: { name: "Железный меч", cat: "tools", stack: 1, damage: 6 },
      diamond_sword: { name: "Алмазный меч", cat: "tools", stack: 1, damage: 8 },
      wood_hoe: { name: "Деревянная мотыга", cat: "tools", stack: 1, tool: "hoe" },
      wood_shovel: { name: "Деревянная лопата", cat: "tools", stack: 1, tool: "shovel", tier: 1 },
      stone_shovel: { name: "Каменная лопата", cat: "tools", stack: 1, tool: "shovel", tier: 2 },
      iron_shovel: { name: "Железная лопата", cat: "tools", stack: 1, tool: "shovel", tier: 3 },
      diamond_shovel: { name: "Алмазная лопата", cat: "tools", stack: 1, tool: "shovel", tier: 4 },
      netherite_shovel: { name: "Незеритовая лопата", cat: "tools", stack: 1, tool: "shovel", tier: 5 },
      stone_hoe: { name: "Каменная мотыга", cat: "tools", stack: 1, tool: "hoe", tier: 2 },
      iron_hoe: { name: "Железная мотыга", cat: "tools", stack: 1, tool: "hoe", tier: 3 },
      diamond_hoe: { name: "Алмазная мотыга", cat: "tools", stack: 1, tool: "hoe", tier: 4 },
      netherite_axe: { name: "Незеритовый топор", cat: "tools", stack: 1, tool: "axe", tier: 5, damage: 10 },
      netherite_hoe: { name: "Незеритовая мотыга", cat: "tools", stack: 1, tool: "hoe", tier: 5 },
      cooked_porkchop: { name: "Жареная свинина", cat: "armor_food", stack: 64, food: 8 },
      porkchop: { name: "Сырая свинина", cat: "armor_food", stack: 64, food: 3 },
      cooked_mutton: { name: "Жареная баранина", cat: "armor_food", stack: 64, food: 6 },
      mutton: { name: "Сырая баранина", cat: "armor_food", stack: 64, food: 2 },
      cooked_rabbit: { name: "Жареный кролик", cat: "armor_food", stack: 64, food: 5 },
      rabbit: { name: "Сырой кролик", cat: "armor_food", stack: 64, food: 3 },
      rabbit_stew: { name: "Тушёный кролик", cat: "armor_food", stack: 1, food: 10 },
      mushroom_stew: { name: "Грибной суп", cat: "armor_food", stack: 1, food: 6 },
      beetroot: { name: "Свёкла", cat: "armor_food", stack: 64, food: 1 },
      beetroot_soup: { name: "Свекольный суп", cat: "armor_food", stack: 1, food: 6 },
      cookie: { name: "Печенье", cat: "armor_food", stack: 64, food: 2 },
      melon_slice: { name: "Ломтик арбуза", cat: "armor_food", stack: 64, food: 2 },
      cooked_fish: { name: "Жареная рыба", cat: "armor_food", stack: 64, food: 5 },
      raw_fish: { name: "Сырая рыба", cat: "armor_food", stack: 64, food: 2 },
      cooked_salmon: { name: "Жареный лосось", cat: "armor_food", stack: 64, food: 6 },
      raw_salmon: { name: "Сырой лосось", cat: "armor_food", stack: 64, food: 2 },
      chorus_fruit: { name: "Плод хоруса", cat: "armor_food", stack: 64, food: 4 },
      poisonous_potato: { name: "Ядовитый картофель", cat: "armor_food", stack: 64, food: 2 },
      rotten_flesh: { name: "Гнилая плоть", cat: "armor_food", stack: 64, food: 4 },
      spider_eye: { name: "Паучий глаз", cat: "misc", stack: 64 },
      slime_ball: { name: "Слизь", cat: "misc", stack: 64 },
      gunpowder: { name: "Порох", cat: "misc", stack: 64 },
      flint: { name: "Кремень", cat: "misc", stack: 64 },
      snowball: { name: "Снежок", cat: "misc", stack: 16 },
      paper: { name: "Бумага", cat: "misc", stack: 64 },
      book: { name: "Книга", cat: "misc", stack: 64 },
      sugar: { name: "Сахар", cat: "misc", stack: 64 },
      cocoa_beans: { name: "Какао-бобы", cat: "misc", stack: 64 },
      saddle: { name: "Седло", cat: "misc", stack: 1 },
      fishing_rod: { name: "Удочка", cat: "tools", stack: 1 },
      shears: { name: "Ножницы", cat: "tools", stack: 1 },
      compass: { name: "Компас", cat: "misc", stack: 64 },
      clock: { name: "Часы", cat: "misc", stack: 64 },
      lead: { name: "Поводок", cat: "misc", stack: 64 },
      name_tag: { name: "Бирка", cat: "misc", stack: 64 },
      experience_bottle: { name: "Пузырёк опыта", cat: "misc", stack: 64 },
      prismarine_shard: { name: "Осколок призмарина", cat: "misc", stack: 64 },
      rabbit_hide: { name: "Кроличья шкурка", cat: "misc", stack: 64 },
      rabbit_foot: { name: "Кроличья лапка", cat: "misc", stack: 64 },
      end_crystal: { name: "Кристалл Энда", cat: "misc", stack: 64 },
      trident: { name: "Трезубец", cat: "tools", stack: 1, damage: 9, trident: true },
      enchanted_golden_apple: { name: "Зачарованное золотое яблоко", cat: "armor_food", stack: 64, food: 8 },
      cake: { name: "Торт", cat: "armor_food", stack: 1, food: 14 },
      melon: { name: "Арбуз", cat: "armor_food", stack: 64, food: 2 },
      cooked_porkchop: { name: "Жареная свинина", cat: "armor_food", stack: 64, food: 8 },
      raw_porkchop: { name: "Сырая свинина", cat: "armor_food", stack: 64, food: 3 },
      cooked_mutton: { name: "Жареная баранина", cat: "armor_food", stack: 64, food: 6 },
      raw_mutton: { name: "Сырая баранина", cat: "armor_food", stack: 64, food: 2 },
      cooked_rabbit: { name: "Жареный кролик", cat: "armor_food", stack: 64, food: 5 },
      raw_rabbit: { name: "Сырой кролик", cat: "armor_food", stack: 64, food: 3 },
      rabbit_stew: { name: "Тушёный кролик", cat: "armor_food", stack: 1, food: 10 },
      mushroom_stew: { name: "Грибной суп", cat: "armor_food", stack: 1, food: 6 },
      beetroot: { name: "Свёкла", cat: "armor_food", stack: 64, food: 1 },
      beetroot_soup: { name: "Свекольный суп", cat: "armor_food", stack: 1, food: 6 },
      cookie: { name: "Печенье", cat: "armor_food", stack: 64, food: 2 },
      melon_slice: { name: "Ломтик арбуза", cat: "armor_food", stack: 64, food: 2 },
      cooked_fish: { name: "Жареная рыба", cat: "armor_food", stack: 64, food: 5 },
      raw_fish: { name: "Сырая рыба", cat: "armor_food", stack: 64, food: 2 },
      cooked_salmon: { name: "Жареный лосось", cat: "armor_food", stack: 64, food: 6 },
      raw_salmon: { name: "Сырой лосось", cat: "armor_food", stack: 64, food: 2 },
      clownfish: { name: "Рыба-клоун", cat: "armor_food", stack: 64, food: 1 },
      pufferfish: { name: "Иглобрюх", cat: "armor_food", stack: 64, food: 1 },
      chorus_fruit: { name: "Плод хоруса", cat: "armor_food", stack: 64, food: 4 },
      poisonous_potato: { name: "Ядовитый картофель", cat: "armor_food", stack: 64, food: 2 },
      rotten_flesh: { name: "Гнилая плоть", cat: "armor_food", stack: 64, food: 4 },
      sweet_berries: { name: "Сладкие ягоды", cat: "armor_food", stack: 64, food: 2 },
      netherite_sword: { name: "Незеритовый меч", cat: "tools", stack: 1, damage: 9 },
      netherite_axe: { name: "Незеритовый топор", cat: "tools", stack: 1, tool: "axe", tier: 5, damage: 10 },
      netherite_hoe: { name: "Незеритовая мотыга", cat: "tools", stack: 1, tool: "hoe", tier: 5 },
      netherite_shovel: { name: "Незеритовая лопата", cat: "tools", stack: 1, tool: "shovel", tier: 5 },
      stone_sword: { name: "Каменный меч", cat: "tools", stack: 1, damage: 5 },
      iron_sword: { name: "Железный меч", cat: "tools", stack: 1, damage: 6 },
      diamond_sword: { name: "Алмазный меч", cat: "tools", stack: 1, damage: 8 },
      wood_sword: { name: "Деревянный меч", cat: "tools", stack: 1, damage: 4 },
      crossbow: { name: "Арбалет", cat: "tools", stack: 1, damage: 7 },
      gold_pickaxe: { name: "Золотая кирка", cat: "tools", stack: 1, tool: "pickaxe", tier: 1, speed: 12 },
      gold_axe: { name: "Золотой топор", cat: "tools", stack: 1, tool: "axe", tier: 1, speed: 12, damage: 4 },
      gold_shovel: { name: "Золотая лопата", cat: "tools", stack: 1, tool: "shovel", tier: 1, speed: 12 },
      gold_hoe: { name: "Золотая мотыга", cat: "tools", stack: 1, tool: "hoe", tier: 1 },
      gold_sword: { name: "Золотой меч", cat: "tools", stack: 1, damage: 4 },
      trident: { name: "Трезубец", cat: "tools", stack: 1, damage: 9, trident: true }
    };

    // Spawn eggs: each living mob implemented by spawnMob has its own survival item.
    const SPAWN_EGG_TYPES = ['villager_fletcher', 'villager_farmer', 'villager_blacksmith', 'villager_cleric', 'cow', 'pig', 'sheep', 'chicken', 'rabbit', 'zombie', 'skeleton', 'wither_skeleton', 'creeper', 'enderman', 'blaze', 'dragon'];
    for (const [type, name] of [
      ["villager_fletcher", "Лучник"],
      ["villager_farmer", "Фермер"],
      ["villager_blacksmith", "Оружейник"],
      ["villager_cleric", "Священник"],
      ["cow", "Корова"],
      ["pig", "Свинья"],
      ["sheep", "Овца"],
      ["chicken", "Курица"],
      ["rabbit", "Кролик"],
      ["zombie", "Зомби"],
      ["skeleton", "Скелет"],
      ["wither_skeleton", "Визер-скелет"],
      ["creeper", "Крипер"],
      ["enderman", "Эндермен"],
      ["blaze", "Ифрит"],
      ["dragon", "Дракон Края"]
    ]) {
      ITEMS["spawn_egg_" + type] = { name: "Яйцо призыва: " + name, cat: "misc", stack: 16, spawnMob: type };
    }

    const ATLAS = {
      textures: {},
      materials: {},
      icons: {},
      itemTextures: {}
    };

    function makePixelTex(drawFn) {
      // Render the classic 16px art on a 32px canvas, then add restrained
      // single-pixel material grain. Nearest filtering keeps the block look crisp.
      const c = document.createElement("canvas");
      c.width = 32; c.height = 32;
      const ctx = c.getContext("2d", { willReadFrequently: true });
      ctx.imageSmoothingEnabled = false;
      ctx.setTransform(2, 0, 0, 2, 0, 0);
      drawFn(ctx);
      ctx.setTransform(1, 0, 0, 1, 0, 0);

      const image = ctx.getImageData(0, 0, 32, 32);
      const px = image.data;
      for (let y = 0; y < 32; y++) {
        for (let x = 0; x < 32; x++) {
          const p = (y * 32 + x) * 4;
          if (px[p + 3] === 0) continue;
          const hash = (Math.imul(x + 17, 374761393) + Math.imul(y + 31, 668265263)) | 0;
          const grain = ((hash ^ (hash >>> 13)) >>> 0) % 29;
          const shade = grain === 0 ? 15 : grain === 1 ? -13 : grain === 2 ? 8 : 0;
          if (shade) {
            px[p] = Math.max(0, Math.min(255, px[p] + shade));
            px[p + 1] = Math.max(0, Math.min(255, px[p + 1] + shade));
            px[p + 2] = Math.max(0, Math.min(255, px[p + 2] + shade));
          }
        }
      }
      ctx.putImageData(image, 0, 0);

      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestMipmapNearestFilter;
      tex.generateMipmaps = true;
      if (typeof renderer !== "undefined") tex.anisotropy = Math.min(4, renderer.capabilities.getMaxAnisotropy());
      return { tex, dataUrl: c.toDataURL() };
    }

    function noiseFill(ctx, baseHex, altHexes, density = 0.42) {
      ctx.fillStyle = baseHex;
      ctx.fillRect(0, 0, 16, 16);
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const h = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
          const r = h - Math.floor(h);
          if (r < density) {
            ctx.fillStyle = altHexes[Math.floor((r / density) * altHexes.length)];
            ctx.fillRect(x, y, 1, 1);
          }
        }
      }
      // Gentle edge contrast gives each tile more depth without leaving pixel art.
      ctx.fillStyle = "rgba(255,255,255,0.055)";
      ctx.fillRect(0, 0, 16, 1);
      ctx.fillRect(0, 0, 1, 16);
      ctx.fillStyle = "rgba(0,0,0,0.09)";
      ctx.fillRect(0, 15, 16, 1);
      ctx.fillRect(15, 0, 1, 16);
    }

    function initTextures() {
      const grassTop = makePixelTex(ctx => {
        noiseFill(ctx, "#5d8731", ["#527a2b", "#679238", "#4b7026"], 0.55);
        ctx.fillStyle = "#78a943";
        [[2,3],[5,10],[9,4],[13,8],[7,14],[12,2]].forEach(([x,y]) => ctx.fillRect(x,y,1,1));
        ctx.fillStyle = "#3e6124";
        [[1,8],[4,5],[10,12],[14,5],[6,2]].forEach(([x,y]) => ctx.fillRect(x,y,1,1));
      });
      const dirt = makePixelTex(ctx => {
        noiseFill(ctx, "#79553a", ["#684830", "#876043", "#5c3f29"], 0.5);
        ctx.fillStyle = "#a17a52";
        [[2,4],[9,2],[13,10],[5,13]].forEach(([x,y]) => ctx.fillRect(x,y,2,1));
        ctx.fillStyle = "#4f3828";
        [[4,7],[11,5],[7,11],[14,14]].forEach(([x,y]) => ctx.fillRect(x,y,1,2));
      });
      const grassSide = makePixelTex(ctx => {
        noiseFill(ctx, "#79553a", ["#684830", "#876043"], 0.45);
        ctx.fillStyle = "#5d8731";
        ctx.fillRect(0, 0, 16, 3);
        for (let x = 0; x < 16; x++) {
          const drop = (x * 7) % 3;
          ctx.fillStyle = x % 2 === 0 ? "#527a2b" : "#679238";
          ctx.fillRect(x, 3, 1, drop);
        }
      });
      const stone = makePixelTex(ctx => {
        noiseFill(ctx, "#7c7c7c", ["#6e6e6e", "#8a8a8a", "#636363"], 0.5);
        ctx.fillStyle = "#555555";
        ctx.fillRect(3,4,3,1); ctx.fillRect(5,5,1,2); ctx.fillRect(11,10,2,1); ctx.fillRect(10,11,1,2);
        ctx.fillStyle = "#a0a0a0";
        ctx.fillRect(2,3,2,1); ctx.fillRect(10,9,2,1); ctx.fillRect(6,13,3,1);
      });
      const cobble = makePixelTex(ctx => {
        noiseFill(ctx, "#747474", ["#5e5e5e", "#8a8a8a", "#525252"], 0.65);
        ctx.fillStyle = "#484848";
        ctx.fillRect(0, 5, 16, 1); ctx.fillRect(0, 11, 16, 1);
        ctx.fillRect(7, 0, 1, 5); ctx.fillRect(12, 6, 1, 5);
      });
      const bedrock = makePixelTex(ctx => noiseFill(ctx, "#363636", ["#1f1f1f", "#4f4f4f", "#141414"], 0.65));
      const oakSide = makePixelTex(ctx => {
        noiseFill(ctx, "#634b2e", ["#523d24", "#735837"], 0.45);
        ctx.fillStyle = "#45331d";
        for (let x = 2; x < 16; x += 4) ctx.fillRect(x, 0, 1, 16);
        ctx.fillStyle = "#98744a";
        ctx.fillRect(1,3,1,5); ctx.fillRect(8,1,1,4); ctx.fillRect(12,9,1,5);
        ctx.fillStyle = "#3c2b1a";
        ctx.fillRect(4,7,2,1); ctx.fillRect(10,5,2,1);
      });
      const oakTop = makePixelTex(ctx => {
        ctx.fillStyle = "#634b2e"; ctx.fillRect(0, 0, 16, 16);
        ctx.fillStyle = "#a38354"; ctx.fillRect(2, 2, 12, 12);
        ctx.fillStyle = "#876b42"; ctx.fillRect(4, 4, 8, 8);
        ctx.fillStyle = "#a38354"; ctx.fillRect(6, 6, 4, 4);
      });
      const planks = makePixelTex(ctx => {
        noiseFill(ctx, "#9c7f4e", ["#8c7144", "#ab8c57"], 0.4);
        ctx.fillStyle = "#66502d";
        ctx.fillRect(0, 3, 16, 1); ctx.fillRect(0, 7, 16, 1);
        ctx.fillRect(0, 11, 16, 1); ctx.fillRect(0, 15, 16, 1);
        ctx.fillStyle = "#c1a16a";
        ctx.fillRect(2,1,5,1); ctx.fillRect(9,5,4,1); ctx.fillRect(3,9,6,1);
        ctx.fillStyle = "#725833";
        ctx.fillRect(11,1,2,1); ctx.fillRect(5,5,2,1); ctx.fillRect(12,9,2,1);
      });
      const leaves = makePixelTex(ctx => {
        ctx.fillStyle = "#486e23";
        ctx.fillRect(0, 0, 16, 16);
        for (let y = 0; y < 16; y++) {
          for (let x = 0; x < 16; x++) {
            const v = (x * 13 + y * 29) % 11;
            if (v === 0 || v === 1) ctx.clearRect(x, y, 1, 1);
            else if (v < 5) { ctx.fillStyle = "#3a591b"; ctx.fillRect(x, y, 1, 1); }
            else if (v > 8) { ctx.fillStyle = "#56822b"; ctx.fillRect(x, y, 1, 1); }
          }
        }
      });
      const sand = makePixelTex(ctx => {
        noiseFill(ctx, "#cfc695", ["#c2b886", "#dbd2a2"], 0.45);
        ctx.fillStyle = "#e5d9a8";
        ctx.fillRect(1,4,5,1); ctx.fillRect(9,11,5,1);
        ctx.fillStyle = "#b6a978";
        ctx.fillRect(4,5,6,1); ctx.fillRect(0,13,4,1);
      });
      const sandstone = makePixelTex(ctx => {
        noiseFill(ctx, "#c7bd8b", ["#b8ae7d", "#d4ca98"], 0.45);
        ctx.fillStyle = "#a3996b";
        ctx.fillRect(0, 3, 16, 1); ctx.fillRect(0, 11, 16, 1);
      });
      const gravel = makePixelTex(ctx => noiseFill(ctx, "#7d7876", ["#666260", "#918c8a", "#575351"], 0.55));
      const glass = makePixelTex(ctx => {
        ctx.clearRect(0, 0, 16, 16);
        ctx.strokeStyle = "#bcd4db";
        ctx.lineWidth = 1;
        ctx.strokeRect(0.5, 0.5, 15, 15);
        ctx.fillStyle = "#dcebef";
        ctx.fillRect(2, 2, 3, 1); ctx.fillRect(2, 3, 1, 2);
      });

      const makeOre = (speckHex, base = "#7c7c7c", alts = ["#6e6e6e", "#8a8a8a"]) => makePixelTex(ctx => {
        noiseFill(ctx, base, alts, 0.45);
        ctx.fillStyle = speckHex;
        [[3,3],[4,3],[10,4],[11,5],[5,9],[6,10],[11,11],[12,11],[3,13]].forEach(([x,y]) => ctx.fillRect(x, y, 2, 2));
      });

      const coalOre = makeOre("#262626");
      const ironOre = makeOre("#bfa088");
      const goldOre = makeOre("#d9ca4e");
      const diamondOre = makeOre("#52c7b8");
      const redstoneOre = makeOre("#b82828");
      const lapisOre = makeOre("#28469e");
      const quartzOre = makeOre("#dcd8cc", "#662929", ["#541f1f", "#783232"]);

      const craftTop = makePixelTex(ctx => {
        noiseFill(ctx, "#9c7f4e", ["#856b40"], 0.3);
        ctx.strokeStyle = "#47351b";
        ctx.strokeRect(1.5, 1.5, 13, 13);
        ctx.fillStyle = "#47351b";
        ctx.fillRect(5, 2, 1, 12); ctx.fillRect(10, 2, 1, 12);
        ctx.fillRect(2, 5, 12, 1); ctx.fillRect(2, 10, 12, 1);
      });
      const craftSide = makePixelTex(ctx => {
        noiseFill(ctx, "#9c7f4e", ["#856b40"], 0.3);
        ctx.fillStyle = "#47351b";
        ctx.fillRect(0, 0, 16, 2);
        ctx.fillStyle = "#666666";
        ctx.fillRect(3, 5, 3, 6);
        ctx.fillRect(10, 4, 2, 7);
      });
      const furnaceFront = makePixelTex(ctx => {
        noiseFill(ctx, "#747474", ["#616161", "#858585"], 0.5);
        ctx.fillStyle = "#242424";
        ctx.fillRect(4, 3, 8, 4);
        ctx.fillRect(4, 9, 8, 5);
      });
      const chestFront = makePixelTex(ctx => {
        noiseFill(ctx, "#997032", ["#805c26", "#ad803b"], 0.4);
        ctx.strokeStyle = "#36250d";
        ctx.strokeRect(0.5, 0.5, 15, 15);
        ctx.fillStyle = "#36250d";
        ctx.fillRect(0, 5, 16, 1);
        ctx.fillStyle = "#c4c4c4";
        ctx.fillRect(7, 4, 2, 3);
      });
      const bookshelf = makePixelTex(ctx => {
        noiseFill(ctx, "#9c7f4e", ["#856b40"], 0.3);
        ctx.fillStyle = "#2b2114";
        ctx.fillRect(1, 2, 14, 5); ctx.fillRect(1, 9, 14, 5);
        const cols = ["#8c3232", "#32588c", "#467a36", "#9c8234"];
        for (let i = 0; i < 6; i++) {
          ctx.fillStyle = cols[i % 4];
          ctx.fillRect(2 + i * 2, 2, 2, 5);
          ctx.fillStyle = cols[(i + 2) % 4];
          ctx.fillRect(2 + i * 2, 9, 2, 5);
        }
      });
      const wool = makePixelTex(ctx => noiseFill(ctx, "#d4d4d4", ["#c4c4c4", "#e0e0e0"], 0.5));
      const bricks = makePixelTex(ctx => {
        noiseFill(ctx, "#8c4538", ["#78392e", "#9c4f41"], 0.45);
        ctx.fillStyle = "#aba59e";
        ctx.fillRect(0, 3, 16, 1); ctx.fillRect(0, 7, 16, 1);
        ctx.fillRect(0, 11, 16, 1); ctx.fillRect(0, 15, 16, 1);
        ctx.fillRect(7, 0, 1, 3); ctx.fillRect(15, 4, 1, 3);
        ctx.fillRect(7, 8, 1, 3); ctx.fillRect(15, 12, 1, 3);
      });
      const netherBricks = makePixelTex(ctx => {
        noiseFill(ctx, "#381c20", ["#2b1417", "#472429"], 0.45);
        ctx.fillStyle = "#1c0d0f";
        ctx.fillRect(0, 3, 16, 1); ctx.fillRect(0, 7, 16, 1);
        ctx.fillRect(0, 11, 16, 1); ctx.fillRect(0, 15, 16, 1);
        ctx.fillRect(7, 0, 1, 3); ctx.fillRect(15, 4, 1, 3);
      });
      const goldBlock = makePixelTex(ctx => noiseFill(ctx, "#d9c23b", ["#c7b030", "#e6d25a"], 0.45));
      const tntSide = makePixelTex(ctx => {
        ctx.fillStyle = "#a6382e"; ctx.fillRect(0, 0, 16, 16);
        ctx.fillStyle = "#dcdcdc"; ctx.fillRect(0, 5, 16, 6);
        ctx.fillStyle = "#1c1c1c";
        ctx.fillRect(2, 6, 3, 1); ctx.fillRect(3, 6, 1, 4);
        ctx.fillRect(6, 6, 1, 4); ctx.fillRect(7, 7, 1, 1); ctx.fillRect(8, 8, 1, 1); ctx.fillRect(9, 6, 1, 4);
        ctx.fillRect(11, 6, 3, 1); ctx.fillRect(12, 6, 1, 4);
      });
      const haySide = makePixelTex(ctx => {
        noiseFill(ctx, "#b59d3c", ["#9e8831", "#c4ab47"], 0.5);
        ctx.fillStyle = "#8a382c";
        ctx.fillRect(0, 4, 16, 1); ctx.fillRect(0, 11, 16, 1);
      });
      const bedBlanket = makePixelTex(ctx => noiseFill(ctx, "#9e3333", ["#872929", "#b33e3e"], 0.45));
      const bedPillow = makePixelTex(ctx => {
        ctx.fillStyle = "#9e3333"; ctx.fillRect(0, 0, 16, 16);
        ctx.fillStyle = "#d9d9d9"; ctx.fillRect(1, 1, 14, 8);
      });
      const poppy = makePixelTex(ctx => {
        ctx.clearRect(0, 0, 16, 16);
        ctx.fillStyle = "#3f6e24"; ctx.fillRect(7, 7, 2, 9); ctx.fillRect(5, 10, 2, 2);
        ctx.fillStyle = "#b82c2c"; ctx.fillRect(5, 2, 6, 5);
        ctx.fillStyle = "#242424"; ctx.fillRect(7, 4, 2, 2);
      });
      const dandelion = makePixelTex(ctx => {
        ctx.clearRect(0, 0, 16, 16);
        ctx.fillStyle = "#3f6e24"; ctx.fillRect(7, 7, 2, 9); ctx.fillRect(9, 11, 2, 2);
        ctx.fillStyle = "#d9c22b"; ctx.fillRect(5, 2, 6, 5);
        ctx.fillStyle = "#b39d1b"; ctx.fillRect(7, 4, 2, 2);
      });
      const wheatTex = makePixelTex(ctx => {
        ctx.clearRect(0, 0, 16, 16);
        ctx.fillStyle = "#bfa43b";
        [3, 7, 11].forEach(x => { ctx.fillRect(x, 3, 2, 13); });
      });
      const water = makePixelTex(ctx => noiseFill(ctx, "#325cb8", ["#294fa3", "#3d69c9"], 0.45));
      const lava = makePixelTex(ctx => noiseFill(ctx, "#c94d14", ["#db781d", "#ad370c", "#e39624"], 0.55));
      const obsidian = makePixelTex(ctx => noiseFill(ctx, "#1b1429", ["#2b2042", "#120d1c", "#392b57"], 0.5));
      const cryingObsidian = makePixelTex(ctx => {
        noiseFill(ctx, "#1b1429", ["#2b2042", "#120d1c"], 0.5);
        ctx.fillStyle = "#6c36b5";
        ctx.fillRect(3, 4, 2, 4); ctx.fillRect(11, 7, 2, 5);
      });
      const netherrack = makePixelTex(ctx => noiseFill(ctx, "#662929", ["#541f1f", "#783232", "#451717"], 0.55));
      const ancientDebris = makePixelTex(ctx => {
        noiseFill(ctx, "#493b35", ["#342b29", "#665047", "#2b2422"], 0.5);
        ctx.fillStyle = "#b27b3d";
        ctx.fillRect(3, 4, 3, 2); ctx.fillRect(10, 9, 3, 3); ctx.fillRect(6, 13, 2, 1);
        ctx.fillStyle = "#d0a05a";
        ctx.fillRect(4, 4, 1, 1); ctx.fillRect(11, 9, 1, 1);
      });
      const soulSand = makePixelTex(ctx => noiseFill(ctx, "#4a392e", ["#3b2d24", "#594639"], 0.5));
      const glowstone = makePixelTex(ctx => noiseFill(ctx, "#cfa946", ["#9e7929", "#e0c46c", "#7a5919"], 0.6));
      const portal = makePixelTex(ctx => noiseFill(ctx, "#6b2ca3", ["#8441bf", "#511c80"], 0.5));
      const endStone = makePixelTex(ctx => noiseFill(ctx, "#ccce95", ["#b8ba82", "#d9dba4"], 0.5));
      const endFrame = makePixelTex(ctx => {
        noiseFill(ctx, "#456e62", ["#36574d", "#568779"], 0.4);
        ctx.fillStyle = "#ccce95";
        ctx.fillRect(2, 2, 12, 12);
      });
      const endFrameEye = makePixelTex(ctx => {
        noiseFill(ctx, "#456e62", ["#36574d", "#568779"], 0.4);
        ctx.fillStyle = "#48ba7b";
        ctx.fillRect(5, 5, 6, 6);
      });
      const endPortal = makePixelTex(ctx => noiseFill(ctx, "#0b0d17", ["#19243b", "#133632"], 0.35));
      const farmland = makePixelTex(ctx => noiseFill(ctx, "#4d331e", ["#3b2615", "#5c3e26"], 0.5));
      const stoneBricks = makePixelTex(ctx => {
        noiseFill(ctx, "#757575", ["#636363", "#858585"], 0.4);
        ctx.fillStyle = "#474747";
        ctx.fillRect(0, 7, 16, 1); ctx.fillRect(0, 15, 16, 1);
        ctx.fillRect(7, 0, 1, 7); ctx.fillRect(15, 8, 1, 7);
      });
      const torch = makePixelTex(ctx => {
        ctx.clearRect(0, 0, 16, 16);
        ctx.fillStyle = "#704f29"; ctx.fillRect(7, 5, 2, 11);
        ctx.fillStyle = "#db9824"; ctx.fillRect(6, 2, 4, 4);
        ctx.fillStyle = "#f2e699"; ctx.fillRect(7, 3, 2, 2);
      });

      const mat = (t, extra = {}) => new THREE.MeshLambertMaterial({ map: t.tex, ...extra });

      ATLAS.materials[B.GRASS] = [mat(grassSide), mat(grassSide), mat(grassTop), mat(dirt), mat(grassSide), mat(grassSide)];
      ATLAS.icons[B.GRASS] = grassSide.dataUrl;

      ATLAS.materials[B.OAK_LOG] = [mat(oakSide), mat(oakSide), mat(oakTop), mat(oakTop), mat(oakSide), mat(oakSide)];
      ATLAS.icons[B.OAK_LOG] = oakSide.dataUrl;

      ATLAS.materials[B.CRAFTING_TABLE] = [mat(craftSide), mat(craftSide), mat(craftTop), mat(planks), mat(craftSide), mat(craftSide)];
      ATLAS.icons[B.CRAFTING_TABLE] = craftTop.dataUrl;

      ATLAS.materials[B.FURNACE] = [mat(stone), mat(stone), mat(stone), mat(stone), mat(furnaceFront), mat(stone)];
      ATLAS.icons[B.FURNACE] = furnaceFront.dataUrl;

      ATLAS.materials[B.CHEST] = [mat(chestFront), mat(chestFront), mat(planks), mat(planks), mat(chestFront), mat(chestFront)];
      ATLAS.icons[B.CHEST] = chestFront.dataUrl;

      ATLAS.materials[B.BOOKSHELF] = [mat(bookshelf), mat(bookshelf), mat(planks), mat(planks), mat(bookshelf), mat(bookshelf)];
      ATLAS.icons[B.BOOKSHELF] = bookshelf.dataUrl;

      ATLAS.materials[B.TNT] = [mat(tntSide), mat(tntSide), mat(planks), mat(planks), mat(tntSide), mat(tntSide)];
      ATLAS.icons[B.TNT] = tntSide.dataUrl;

      ATLAS.materials[B.BED_FOOT] = [mat(planks), mat(planks), mat(bedBlanket), mat(planks), mat(planks), mat(planks)];
      ATLAS.materials[B.BED_HEAD] = [mat(planks), mat(planks), mat(bedPillow), mat(planks), mat(planks), mat(planks)];
      ATLAS.icons[B.BED_FOOT] = bedPillow.dataUrl;
      ATLAS.icons[B.BED_HEAD] = bedPillow.dataUrl;

      const simple = [
        [B.DIRT, dirt], [B.STONE, stone], [B.COBBLESTONE, cobble], [B.BEDROCK, bedrock],
        [B.OAK_PLANKS, planks], [B.SAND, sand], [B.GRAVEL, gravel],
        [B.COAL_ORE, coalOre], [B.IRON_ORE, ironOre], [B.GOLD_ORE, goldOre],
        [B.DIAMOND_ORE, diamondOre], [B.REDSTONE_ORE, redstoneOre], [B.LAPIS_ORE, lapisOre],
        [B.OBSIDIAN, obsidian], [B.NETHERRACK, netherrack], [B.SOUL_SAND, soulSand],
        [B.GLOWSTONE, glowstone], [B.END_STONE, endStone],
        [B.END_PORTAL_FRAME, endFrame], [B.END_PORTAL_FRAME_EYE, endFrameEye],
        [B.FARMLAND, farmland], [B.STONE_BRICKS, stoneBricks], [B.DRAGON_EGG, obsidian],
        [B.WOOL_WHITE, wool], [B.BRICKS, bricks], [B.HAY_BLOCK, haySide],
        [B.SANDSTONE, sandstone], [B.NETHER_BRICKS, netherBricks], [B.QUARTZ_ORE, quartzOre],
        [B.GOLD_BLOCK, goldBlock], [B.CRYING_OBSIDIAN, cryingObsidian],
        [B.ANCIENT_DEBRIS, netherrack], [B.NETHER_GOLD_ORE, goldOre],
        [B.BASALT, stone], [B.BLACKSTONE, cobble], [B.SOUL_SOIL, soulSand]
      ];
      for (const [id, t] of simple) {
        ATLAS.materials[id] = mat(t);
        ATLAS.icons[id] = t.dataUrl;
      }
      const legacyColors = {
        stone: ["#777777", "#929292", "#555555"], earth: ["#8b633d", "#a17b52", "#67472d"],
        wood: ["#795631", "#a17a4a", "#50371f"], leaf: ["#426d2c", "#65963b", "#294d20"],
        ice: ["#a6d9e8", "#d8f4f7", "#6b9eae"], ocean: ["#3d9b91", "#68c7b4", "#276e72"],
        glow: ["#b9a96b", "#f1e5a2", "#6c6745"], quartz: ["#ddd6c8", "#f5eee0", "#aaa18f"],
        ore: ["#4e4e4e", "#777777", "#2b2b2b"], gem: ["#3caa8e", "#73e1c0", "#26705e"],
        wool: ["#a7a09a", "#d2cbc4", "#68615b"], glass: ["#80b9bd", "#c5e8e8", "#4c7d82"],
        purpur: ["#8b648f", "#b28bb5", "#604465"], nether: ["#713b35", "#a55b4d", "#492725"],
        bone: ["#c6bfa6", "#e8e1c9", "#89836e"], tech: ["#6d777c", "#a6b1b3", "#41494d"],
        slime: ["#62a84c", "#9bdc70", "#39702e"], iron: ["#9da7ad", "#d4dcdf", "#5c666b"]
      };
      for (const [key, name, palette] of LEGACY_BLOCKS) {
        const id = B[key], colors = legacyColors[palette] || legacyColors.stone;
        const tile = makePixelTex(ctx => {
          noiseFill(ctx, colors[0], colors.slice(1), 0.42);
          ctx.fillStyle = colors[2];
          ctx.fillRect(2, 4, 3, 1); ctx.fillRect(10, 11, 4, 1);
          ctx.fillStyle = colors[1];
          ctx.fillRect(5, 2, 2, 1); ctx.fillRect(12, 6, 2, 2);
        });
        ATLAS.materials[id] = mat(tile, palette === "glass" ? { transparent: true, opacity: 0.62 } : {});
        ATLAS.icons[id] = tile.dataUrl;
      }

      ATLAS.materials[B.ANCIENT_DEBRIS] = mat(ancientDebris);
      ATLAS.icons[B.ANCIENT_DEBRIS] = ancientDebris.dataUrl;
      ATLAS.materials[B.OAK_LEAVES] = mat(leaves, { alphaTest: 0.4, side: THREE.DoubleSide });
      ATLAS.icons[B.OAK_LEAVES] = leaves.dataUrl;

      ATLAS.materials[B.GLASS] = mat(glass, { alphaTest: 0.3, transparent: true });
      ATLAS.icons[B.GLASS] = glass.dataUrl;

      ATLAS.materials[B.WATER] = new THREE.MeshLambertMaterial({ map: water.tex, transparent: true, opacity: 0.72 });
      ATLAS.icons[B.WATER] = water.dataUrl;

      ATLAS.materials[B.LAVA] = new THREE.MeshBasicMaterial({ map: lava.tex });
      ATLAS.icons[B.LAVA] = lava.dataUrl;

      ATLAS.materials[B.NETHER_PORTAL] = new THREE.MeshBasicMaterial({ map: portal.tex, transparent: true, opacity: 0.8, side: THREE.DoubleSide });
      ATLAS.icons[B.NETHER_PORTAL] = portal.dataUrl;

      ATLAS.materials[B.END_PORTAL] = new THREE.MeshBasicMaterial({ map: endPortal.tex, side: THREE.DoubleSide });
      ATLAS.icons[B.END_PORTAL] = endPortal.dataUrl;

      ATLAS.materials[B.POPPY] = mat(poppy, { alphaTest: 0.5, side: THREE.DoubleSide });
      ATLAS.icons[B.POPPY] = poppy.dataUrl;

      ATLAS.materials[B.DANDELION] = mat(dandelion, { alphaTest: 0.5, side: THREE.DoubleSide });
      ATLAS.icons[B.DANDELION] = dandelion.dataUrl;

      ATLAS.materials[B.WHEAT_1] = mat(wheatTex, { alphaTest: 0.5, side: THREE.DoubleSide });
      ATLAS.materials[B.WHEAT_7] = mat(wheatTex, { alphaTest: 0.5, side: THREE.DoubleSide });
      ATLAS.icons[B.WHEAT_1] = wheatTex.dataUrl;
      ATLAS.icons[B.WHEAT_7] = wheatTex.dataUrl;

      ATLAS.materials[B.TORCH] = mat(torch, { alphaTest: 0.5, side: THREE.DoubleSide });
      ATLAS.icons[B.TORCH] = torch.dataUrl;

      // 16x16 Pixel Icons for Tools, Weapons, Armor, Food & Items
      const tierColors = { wood: "#967444", stone: "#828282", iron: "#c7c7c7", diamond: "#4ec2b4", netherite: "#51464d" };
      const drawPickaxe = (headCol) => makePixelTex(ctx => {
        ctx.clearRect(0, 0, 16, 16);
        ctx.fillStyle = "#6e4e2a";
        for (let i = 0; i < 9; i++) ctx.fillRect(3 + i, 12 - i, 2, 2);
        ctx.fillStyle = headCol;
        ctx.fillRect(4, 2, 7, 2); ctx.fillRect(10, 3, 3, 2); ctx.fillRect(12, 5, 2, 5); ctx.fillRect(3, 3, 2, 2);
      });
      const drawAxe = (headCol) => makePixelTex(ctx => {
        ctx.clearRect(0, 0, 16, 16);
        ctx.fillStyle = "#6e4e2a";
        for (let i = 0; i < 10; i++) ctx.fillRect(3 + i, 12 - i, 2, 2);
        ctx.fillStyle = headCol;
        ctx.fillRect(8, 2, 5, 5); ctx.fillRect(7, 3, 2, 4);
      });
      const drawSword = (bladeCol) => makePixelTex(ctx => {
        ctx.clearRect(0, 0, 16, 16);
        ctx.fillStyle = "#6e4e2a";
        ctx.fillRect(2, 12, 2, 2); ctx.fillRect(3, 11, 2, 2);
        ctx.fillStyle = "#4d361d";
        ctx.fillRect(4, 9, 4, 1); ctx.fillRect(6, 10, 1, 3);
        ctx.fillStyle = bladeCol;
        for (let i = 0; i < 7; i++) ctx.fillRect(6 + i, 9 - i, 2, 2);
      });
      const drawHoe = (headCol) => makePixelTex(ctx => {
        ctx.clearRect(0, 0, 16, 16);
        ctx.fillStyle = "#6e4e2a";
        for (let i = 0; i < 10; i++) ctx.fillRect(3 + i, 12 - i, 2, 2);
        ctx.fillStyle = headCol;
        ctx.fillRect(7, 2, 6, 2);
      });

      for (const t of ["wood", "stone", "iron", "diamond", "netherite"]) {
        const c = tierColors[t];
        const p = drawPickaxe(c); ATLAS.icons[`${t}_pickaxe`] = p.dataUrl; ATLAS.itemTextures[`${t}_pickaxe`] = p.tex;
        const a = drawAxe(c); ATLAS.icons[`${t}_axe`] = a.dataUrl; ATLAS.itemTextures[`${t}_axe`] = a.tex;
        const s = drawSword(c); ATLAS.icons[`${t}_sword`] = s.dataUrl; ATLAS.itemTextures[`${t}_sword`] = s.tex;
      }
      const hoe = drawHoe(tierColors.wood); ATLAS.icons.wood_hoe = hoe.dataUrl; ATLAS.itemTextures.wood_hoe = hoe.tex;

      const customItems = {
        stick: ctx => { ctx.fillStyle = "#7a5730"; for (let i = 0; i < 10; i++) ctx.fillRect(3 + i, 12 - i, 2, 2); },
        emerald: ctx => { ctx.fillStyle = "#3ba858"; ctx.fillRect(5, 3, 6, 10); ctx.fillRect(4, 5, 8, 6); ctx.fillStyle = "#7be095"; ctx.fillRect(6, 5, 2, 3); },
        quartz: ctx => { ctx.fillStyle = "#dcd8cc"; ctx.fillRect(4, 4, 8, 8); ctx.fillStyle = "#f2efe6"; ctx.fillRect(5, 5, 3, 3); },
        ancient_debris: ctx => { ctx.fillStyle = "#493b35"; ctx.fillRect(3, 4, 10, 8); ctx.fillStyle = "#b27b3d"; ctx.fillRect(5, 5, 3, 2); ctx.fillRect(9, 9, 2, 2); },
        netherite_scrap: ctx => { ctx.fillStyle = "#51464d"; ctx.fillRect(4, 4, 8, 8); ctx.fillStyle = "#8d766d"; ctx.fillRect(5, 5, 3, 2); },
        netherite_ingot: ctx => { ctx.fillStyle = "#51464d"; ctx.fillRect(3, 5, 10, 6); ctx.fillStyle = "#a18a78"; ctx.fillRect(4, 6, 8, 2); },
        wither_skull: ctx => { ctx.fillStyle = "#242424"; ctx.fillRect(3, 3, 10, 10); ctx.fillStyle = "#7a7a7a"; ctx.fillRect(5, 6, 2, 2); ctx.fillRect(9, 6, 2, 2); },
        bed: ctx => { ctx.fillStyle = "#9e3333"; ctx.fillRect(2, 6, 12, 6); ctx.fillStyle = "#d9d9d9"; ctx.fillRect(2, 6, 4, 4); ctx.fillStyle = "#6e4e2a"; ctx.fillRect(2, 12, 2, 2); ctx.fillRect(12, 12, 2, 2); },
        coal: ctx => { ctx.fillStyle = "#262626"; ctx.fillRect(4, 4, 8, 8); ctx.fillStyle = "#3b3b3b"; ctx.fillRect(5, 5, 3, 3); },
        iron_ingot: ctx => { ctx.fillStyle = "#c7c7c7"; ctx.fillRect(3, 5, 10, 6); ctx.fillStyle = "#dedede"; ctx.fillRect(4, 6, 8, 2); },
        gold_ingot: ctx => { ctx.fillStyle = "#d9c645"; ctx.fillRect(3, 5, 10, 6); ctx.fillStyle = "#ebe078"; ctx.fillRect(4, 6, 8, 2); },
        diamond: ctx => { ctx.fillStyle = "#4ec2b4"; ctx.fillRect(5, 3, 6, 10); ctx.fillRect(3, 5, 10, 6); ctx.fillStyle = "#8ce6db"; ctx.fillRect(6, 5, 3, 3); },
        redstone: ctx => { ctx.fillStyle = "#b52828"; ctx.fillRect(4, 5, 8, 6); ctx.fillRect(6, 4, 4, 8); },
        lapis: ctx => { ctx.fillStyle = "#2b4ca3"; ctx.fillRect(4, 4, 8, 8); },
        flint_and_steel: ctx => { ctx.fillStyle = "#b0b0b0"; ctx.fillRect(4, 3, 6, 3); ctx.fillRect(4, 3, 2, 7); ctx.fillStyle = "#363636"; ctx.fillRect(7, 7, 5, 5); },
        bucket_water: ctx => { ctx.fillStyle = "#9e9e9e"; ctx.fillRect(4, 5, 8, 8); ctx.fillStyle = "#325cb8"; ctx.fillRect(5, 5, 6, 3); },
        bucket_lava: ctx => { ctx.fillStyle = "#9e9e9e"; ctx.fillRect(4, 5, 8, 8); ctx.fillStyle = "#c94d14"; ctx.fillRect(5, 5, 6, 3); },
        ender_pearl: ctx => { ctx.fillStyle = "#1d5952"; ctx.fillRect(4, 4, 8, 8); ctx.fillStyle = "#3a8c82"; ctx.fillRect(6, 5, 3, 3); },
        blaze_rod: ctx => { ctx.fillStyle = "#d69422"; for (let i = 0; i < 10; i++) ctx.fillRect(3 + i, 12 - i, 2, 2); },
        blaze_powder: ctx => { ctx.fillStyle = "#d67c1c"; ctx.fillRect(4, 5, 8, 6); ctx.fillStyle = "#e8b438"; ctx.fillRect(6, 6, 4, 3); },
        ender_eye: ctx => { ctx.fillStyle = "#3b8c6e"; ctx.fillRect(3, 3, 10, 10); ctx.fillStyle = "#78c99e"; ctx.fillRect(5, 5, 6, 6); ctx.fillStyle = "#16241d"; ctx.fillRect(7, 5, 2, 6); },
        apple: ctx => { ctx.fillStyle = "#b52b2b"; ctx.fillRect(4, 4, 8, 8); ctx.fillStyle = "#5c4022"; ctx.fillRect(7, 2, 2, 2); },
        bread: ctx => { ctx.fillStyle = "#a87638"; ctx.fillRect(3, 5, 10, 6); ctx.fillStyle = "#c4914d"; ctx.fillRect(4, 6, 8, 2); },
        cooked_beef: ctx => { ctx.fillStyle = "#784226"; ctx.fillRect(3, 4, 10, 8); ctx.fillStyle = "#965838"; ctx.fillRect(5, 6, 6, 4); },
        raw_chicken: ctx => { ctx.fillStyle = "#e5d5c9"; ctx.fillRect(4, 4, 8, 8); ctx.fillStyle = "#b94a42"; ctx.fillRect(9, 9, 3, 3); },
        cooked_chicken: ctx => { ctx.fillStyle = "#a86a32"; ctx.fillRect(4, 4, 8, 8); ctx.fillStyle = "#e3b56a"; ctx.fillRect(6, 5, 4, 5); },
        potato: ctx => { ctx.fillStyle = "#b88a4c"; ctx.fillRect(4, 5, 8, 7); ctx.fillStyle = "#d1aa6c"; ctx.fillRect(6, 6, 2, 2); },
        baked_potato: ctx => { ctx.fillStyle = "#9b5d2e"; ctx.fillRect(4, 5, 8, 7); ctx.fillStyle = "#d59b4c"; ctx.fillRect(6, 6, 3, 3); },
        carrot: ctx => { ctx.fillStyle = "#e58b28"; ctx.fillRect(5, 5, 7, 8); ctx.fillStyle = "#4d8b37"; ctx.fillRect(5, 2, 5, 3); },
        pumpkin_pie: ctx => { ctx.fillStyle = "#bd762c"; ctx.fillRect(3, 6, 10, 6); ctx.fillStyle = "#e5b54a"; ctx.fillRect(4, 5, 8, 2); },
        golden_carrot: ctx => { ctx.fillStyle = "#d9b52e"; ctx.fillRect(5, 5, 7, 8); ctx.fillStyle = "#638d36"; ctx.fillRect(5, 2, 5, 3); },
        golden_apple: ctx => { ctx.fillStyle = "#d9c236"; ctx.fillRect(4, 4, 8, 8); ctx.fillStyle = "#6e5226"; ctx.fillRect(7, 2, 2, 2); },
        wheat: ctx => { ctx.fillStyle = "#bfa43b"; ctx.fillRect(4, 3, 8, 10); },
        wheat_seeds: ctx => { ctx.fillStyle = "#5c8532"; ctx.fillRect(5, 6, 2, 2); ctx.fillRect(9, 5, 2, 2); ctx.fillRect(7, 9, 2, 2); },
        bone: ctx => { ctx.fillStyle = "#cfccb8"; for (let i = 0; i < 8; i++) ctx.fillRect(4 + i, 11 - i, 2, 2); },
        string: ctx => { ctx.fillStyle = "#cfcfcf"; ctx.fillRect(5, 3, 2, 10); ctx.fillRect(7, 5, 2, 6); },
        bow: ctx => { ctx.fillStyle = "#785329"; ctx.fillRect(4, 2, 2, 12); ctx.fillRect(6, 3, 2, 2); ctx.fillRect(6, 11, 2, 2); ctx.fillStyle = "#cfcfcf"; ctx.fillRect(8, 3, 1, 10); },
        arrow: ctx => { ctx.fillStyle = "#785329"; for (let i = 0; i < 8; i++) ctx.fillRect(4 + i, 11 - i, 1, 1); ctx.fillStyle = "#a8a8a8"; ctx.fillRect(10, 3, 3, 3); },
        shield: ctx => { ctx.fillStyle = "#8c6e42"; ctx.fillRect(4, 2, 8, 12); ctx.strokeStyle = "#8a8a8a"; ctx.strokeRect(4.5, 2.5, 7, 11); },
        iron_helmet: ctx => { ctx.fillStyle = "#bdbdbd"; ctx.fillRect(3, 4, 10, 7); ctx.clearRect(5, 8, 6, 3); },
        iron_chestplate: ctx => { ctx.fillStyle = "#bdbdbd"; ctx.fillRect(2, 3, 12, 10); ctx.clearRect(6, 3, 4, 3); },
        diamond_helmet: ctx => { ctx.fillStyle = "#4ec2b4"; ctx.fillRect(3, 4, 10, 7); ctx.clearRect(5, 8, 6, 3); },
        diamond_chestplate: ctx => { ctx.fillStyle = "#4ec2b4"; ctx.fillRect(2, 3, 12, 10); ctx.clearRect(6, 3, 4, 3); }
      };

      for (const [k, fn] of Object.entries(customItems)) {
        const res = makePixelTex(fn);
        ATLAS.icons[k] = res.dataUrl;
        ATLAS.itemTextures[k] = res.tex;
      }
    }

    // Build the inventory/hotbar block icons as tiny three-face cubes, matching
    // the classic creative inventory reference instead of reusing one flat tile.
    function createIsometricBlockIcons() {
      const seen = new Set();
      const drawFace = (ctx, image, points, shade = 0) => {
        if (!image) return;
        ctx.save();
        ctx.beginPath();
        points.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
        ctx.closePath();
        ctx.clip();
        const [p0, p1, , p3] = points;
        const a = (p1[0] - p0[0]) / 32, b = (p1[1] - p0[1]) / 32;
        const c = (p3[0] - p0[0]) / 32, d = (p3[1] - p0[1]) / 32;
        ctx.setTransform(a, b, c, d, p0[0], p0[1]);
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(image, 0, 0, 32, 32);
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        if (shade) {
          ctx.fillStyle = `rgba(0,0,0,${shade})`;
          ctx.fill();
        }
        ctx.restore();
      };

      for (const rawId of Object.keys(BLOCK_PROPS)) {
        const id = Number(rawId);
        if (seen.has(id) || !BLOCK_PROPS[id]?.solid) continue;
        seen.add(id);
        const source = ATLAS.materials[id];
        if (!source) continue;
        const faces = Array.isArray(source) ? source : [source, source, source, source, source, source];
        const imageAt = index => faces[index]?.map?.image || null;
        const canvas = document.createElement("canvas");
        canvas.width = 64; canvas.height = 64;
        const ctx = canvas.getContext("2d");
        ctx.imageSmoothingEnabled = false;
        // Back/right face, left face, then top face: same layout as the supplied
        // inventory screenshot, with subtle directional shading.
        drawFace(ctx, imageAt(0), [[32, 33], [57, 19], [57, 46], [32, 60]], 0.18);
        drawFace(ctx, imageAt(4), [[7, 19], [32, 33], [32, 60], [7, 46]], 0.10);
        drawFace(ctx, imageAt(2), [[32, 5], [57, 19], [32, 33], [7, 19]], 0);
        ATLAS.icons[id] = canvas.toDataURL("image/png");
      }
    }

    // Load the unmodified vanilla block atlas textures from the public Minecraft asset mirror.
    // Procedural textures remain as an offline fallback if the asset host is unavailable.
    function loadVanillaBlockTextures() {
      const version = "1.21.11";
      const base = `https://mcasset.cloud/${version}/assets/minecraft/textures/block/`;
      const loader = new THREE.TextureLoader();
      loader.setCrossOrigin("anonymous");

      const blockFaces = new Map([
        [B.GRASS, ["grass_block_side.png", "grass_block_side.png", "grass_block_top.png", "dirt.png", "grass_block_side.png", "grass_block_side.png"]],
        [B.OAK_LOG, ["oak_log.png", "oak_log.png", "oak_log_top.png", "oak_log_top.png", "oak_log.png", "oak_log.png"]],
        [B.CRAFTING_TABLE, ["crafting_table_side.png", "crafting_table_side.png", "crafting_table_top.png", "oak_planks.png", "crafting_table_side.png", "crafting_table_side.png"]],
        [B.FURNACE, ["furnace_side.png", "furnace_side.png", "furnace_top.png", "furnace_top.png", "furnace_front.png", "furnace_side.png"]],
        [B.CHEST, ["chest.png", "chest.png", "chest.png", "chest.png", "chest.png", "chest.png"]],
        [B.BOOKSHELF, ["bookshelf.png", "bookshelf.png", "oak_planks.png", "oak_planks.png", "bookshelf.png", "bookshelf.png"]],
        [B.TNT, ["tnt_side.png", "tnt_side.png", "tnt_top.png", "tnt_bottom.png", "tnt_side.png", "tnt_side.png"]],
        [B.BED_FOOT, ["red_wool.png", "red_wool.png", "red_wool.png", "oak_planks.png", "red_wool.png", "red_wool.png"]],
        [B.BED_HEAD, ["red_wool.png", "red_wool.png", "red_wool.png", "oak_planks.png", "red_wool.png", "red_wool.png"]],
        [B.SANDSTONE, ["sandstone.png", "sandstone.png", "sandstone_top.png", "sandstone_bottom.png", "sandstone.png", "sandstone.png"]],
        [B.HAY_BLOCK, ["hay_block_side.png", "hay_block_side.png", "hay_block_top.png", "hay_block_top.png", "hay_block_side.png", "hay_block_side.png"]],
        [B.END_PORTAL_FRAME, ["end_portal_frame_side.png", "end_portal_frame_side.png", "end_portal_frame_top.png", "end_stone.png", "end_portal_frame_side.png", "end_portal_frame_side.png"]],
        [B.END_PORTAL_FRAME_EYE, ["end_portal_frame_side.png", "end_portal_frame_side.png", "end_portal_frame_eye.png", "end_stone.png", "end_portal_frame_side.png", "end_portal_frame_side.png"]],
        [B.BASALT, ["basalt_side.png", "basalt_side.png", "basalt_top.png", "basalt_top.png", "basalt_side.png", "basalt_side.png"]],
        [B.ANCIENT_DEBRIS, ["ancient_debris_side.png", "ancient_debris_side.png", "ancient_debris_top.png", "ancient_debris_top.png", "ancient_debris_side.png", "ancient_debris_side.png"]]
      ]);
      const blockFiles = new Map([
        [B.DIRT, "dirt.png"], [B.STONE, "stone.png"], [B.COBBLESTONE, "cobblestone.png"],
        [B.BEDROCK, "bedrock.png"], [B.OAK_PLANKS, "oak_planks.png"], [B.OAK_LEAVES, "oak_leaves.png"],
        [B.SAND, "sand.png"], [B.GRAVEL, "gravel.png"], [B.COAL_ORE, "coal_ore.png"],
        [B.IRON_ORE, "iron_ore.png"], [B.GOLD_ORE, "gold_ore.png"], [B.DIAMOND_ORE, "diamond_ore.png"],
        [B.REDSTONE_ORE, "redstone_ore.png"], [B.LAPIS_ORE, "lapis_ore.png"], [B.GLASS, "glass.png"],
        [B.OBSIDIAN, "obsidian.png"], [B.NETHERRACK, "netherrack.png"], [B.SOUL_SAND, "soul_sand.png"],
        [B.GLOWSTONE, "glowstone.png"], [B.END_STONE, "end_stone.png"], [B.FARMLAND, "farmland.png"],
        [B.STONE_BRICKS, "stone_bricks.png"], [B.DRAGON_EGG, "dragon_egg.png"], [B.WOOL_WHITE, "white_wool.png"],
        [B.BRICKS, "bricks.png"], [B.NETHER_BRICKS, "nether_bricks.png"], [B.QUARTZ_ORE, "nether_quartz_ore.png"],
        [B.GOLD_BLOCK, "gold_block.png"], [B.CRYING_OBSIDIAN, "crying_obsidian.png"],
        [B.NETHER_GOLD_ORE, "nether_gold_ore.png"], [B.BLACKSTONE, "blackstone.png"], [B.SOUL_SOIL, "soul_soil.png"],
        [B.POPPY, "poppy.png"], [B.DANDELION, "dandelion.png"], [B.WHEAT_1, "wheat_stage0.png"],
        [B.WHEAT_7, "wheat_stage7.png"], [B.TORCH, "torch.png"], [B.WATER, "water_still.png"],
        [B.LAVA, "lava_still.png"], [B.NETHER_PORTAL, "nether_portal.png"], [B.END_PORTAL, "end_portal.png"]
      ]);

      const configureTexture = texture => {
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.magFilter = THREE.NearestFilter;
        texture.minFilter = THREE.NearestMipmapNearestFilter;
        texture.generateMipmaps = true;
        texture.anisotropy = Math.min(4, renderer.capabilities.getMaxAnisotropy());
        texture.needsUpdate = true;
      };
      const loadTexture = (file, onLoad) => loader.load(base + file, texture => {
        configureTexture(texture);
        onLoad(texture);
      }, undefined, () => console.warn("Vanilla texture unavailable:", file));

      // Keep the supplied classic muted 16px block atlas authoritative.
      // A remote modern pack previously overwrote the intended palette.
      createIsometricBlockIcons();

      // Vanilla item sprites replace the hand-made icons when available; procedural art remains as fallback.
      const vanillaItemFiles = {
        wood_pickaxe: "wooden_pickaxe.png", stone_pickaxe: "stone_pickaxe.png", iron_pickaxe: "iron_pickaxe.png",
        diamond_pickaxe: "diamond_pickaxe.png", netherite_pickaxe: "netherite_pickaxe.png",
        wood_axe: "wooden_axe.png", stone_axe: "stone_axe.png", iron_axe: "iron_axe.png", diamond_axe: "diamond_axe.png",
        wood_sword: "wooden_sword.png", stone_sword: "stone_sword.png", iron_sword: "iron_sword.png",
        diamond_sword: "diamond_sword.png", netherite_sword: "netherite_sword.png", wood_hoe: "wooden_hoe.png",
        apple: "apple.png", bread: "bread.png", cooked_beef: "cooked_beef.png", raw_chicken: "chicken.png",
        cooked_chicken: "cooked_chicken.png", potato: "potato.png", baked_potato: "baked_potato.png",
        carrot: "carrot.png", pumpkin_pie: "pumpkin_pie.png", golden_carrot: "golden_carrot.png",
        golden_apple: "golden_apple.png", stick: "stick.png", coal: "coal.png", iron_ingot: "iron_ingot.png",
        gold_ingot: "gold_ingot.png", diamond: "diamond.png", emerald: "emerald.png", redstone: "redstone.png",
        lapis: "lapis_lazuli.png", bow: "bow.png", arrow: "arrow.png", shield: "shield.png",
        flint_and_steel: "flint_and_steel.png", ender_pearl: "ender_pearl.png", ender_eye: "ender_eye.png",
        blaze_rod: "blaze_rod.png", blaze_powder: "blaze_powder.png", wheat: "wheat.png",
        wheat_seeds: "wheat_seeds.png", feather: "feather.png", bone: "bone.png", string: "string.png",
        netherite_ingot: "netherite_ingot.png", netherite_scrap: "netherite_scrap.png",
        bucket_water: "water_bucket.png", bucket_lava: "lava_bucket.png", bed: "red_bed.png",
        wither_skull: "wither_skeleton_skull.png", quartz: "quartz.png", ancient_debris: "ancient_debris.png",
        leather_helmet: "leather_helmet.png", leather_chestplate: "leather_chestplate.png",
        leather_leggings: "leather_leggings.png", leather_boots: "leather_boots.png",
        chainmail_helmet: "chainmail_helmet.png", chainmail_chestplate: "chainmail_chestplate.png",
        chainmail_leggings: "chainmail_leggings.png", chainmail_boots: "chainmail_boots.png",
        gold_helmet: "golden_helmet.png", gold_chestplate: "golden_chestplate.png",
        gold_leggings: "golden_leggings.png", gold_boots: "golden_boots.png",
        iron_helmet: "iron_helmet.png", iron_chestplate: "iron_chestplate.png",
        iron_leggings: "iron_leggings.png", iron_boots: "iron_boots.png",
        diamond_helmet: "diamond_helmet.png", diamond_chestplate: "diamond_chestplate.png",
        diamond_leggings: "diamond_leggings.png", diamond_boots: "diamond_boots.png",
        netherite_helmet: "netherite_helmet.png", netherite_chestplate: "netherite_chestplate.png",
        netherite_leggings: "netherite_leggings.png", netherite_boots: "netherite_boots.png",
        elytra: "elytra.png", trident: "trident.png"
      };
      for (const [id, file] of Object.entries(vanillaItemFiles)) {
        loader.load(`https://mcasset.cloud/${version}/assets/minecraft/textures/item/${file}`, texture => {
          configureTexture(texture);
          ATLAS.itemTextures[id] = texture;
          ATLAS.icons[id] = texture.image?.src || ATLAS.icons[id];
        }, undefined, () => console.warn("Vanilla item texture unavailable:", file));
      }

      // Vanilla destroy-stage overlays (stage 1..10).
      for (let stage = 1; stage <= 10; stage++) {
        loadTexture(`destroy_stage_${stage - 1}.png`, texture => {
          const material = new THREE.MeshBasicMaterial({
            map: texture, transparent: true, opacity: 0.88,
            depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1
          });
          crackStageMaterials[stage] = material;
          if (crackMesh.visible && Math.min(10, Math.floor(miningState.progress * 10)) === stage) {
            crackMesh.material = material;
          }
        });
      }
    }

function referenceHash2(x, y, s) {
  let n = Math.sin(x * 127.1 + y * 311.7 + s * 74.7) * 43758.5453;
  return n - Math.floor(n);
}

function referenceCanvas16(drawFn) {
  const c = document.createElement('canvas');
  c.width = 16; c.height = 16;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  drawFn(ctx);
  return c;
}

function getAvgHex(canvas) {
  const data = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data;
  let r = 0, g = 0, b = 0, cnt = 0;
  for (let i = 0; i < data.length; i += 4) {
    if (data[i+3] > 20) { r += data[i]; g += data[i+1]; b += data[i+2]; cnt++; }
  }
  if (!cnt) return '#000000';
  const toH = v => Math.round(v / cnt).toString(16).padStart(2, '0');
  return '#' + toH(r) + toH(g) + toH(b);
}

function referencePx(ctx, x, y, col) {
  ctx.fillStyle = col;
  ctx.fillRect(x, y, 1, 1);
}

function referenceFillNoise(ctx, palette, seed) {
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const idx = Math.floor(referenceHash2(x, y, seed) * palette.length);
      referencePx(ctx, x, y, palette[idx]);
    }
  }
}
const REF_TEX = {};

function initReferenceTextures() {
  const dirtPal = ['#593d29', '#66462f', '#4d3422', '#734f36', '#422c1d'];
  REF_TEX.dirt = referenceCanvas16(ctx => {
    referenceFillNoise(ctx, dirtPal, 11);
    for (let i = 0; i < 18; i++) {
      const x = Math.floor(referenceHash2(i, 1, 12)*16), y = Math.floor(referenceHash2(i, 2, 12)*16);
      referencePx(ctx, x, y, '#6e6e6e');
    }
  });

  const grassTopPal = ['#4a7a26', '#416e20', '#53872c', '#39611b', '#5b9131'];
  REF_TEX.grass_top = referenceCanvas16(ctx => referenceFillNoise(ctx, grassTopPal, 21));

  REF_TEX.grass_side = referenceCanvas16(ctx => {
    ctx.drawImage(REF_TEX.dirt, 0, 0);
    const depths = [3,4,3,2,4,5,3,2,3,4,3,2,4,3,2,3];
    for (let x = 0; x < 16; x++) {
      for (let y = 0; y < depths[x]; y++) {
        referencePx(ctx, x, y, grassTopPal[Math.floor(referenceHash2(x, y, 22)*grassTopPal.length)]);
      }
      referencePx(ctx, x, depths[x], '#362316');
    }
  });

  const stonePal = ['#5c5c5c', '#636363', '#545454', '#6b6b6b', '#4b4b4b'];
  REF_TEX.stone = referenceCanvas16(ctx => {
    referenceFillNoise(ctx, stonePal, 31);
    for (let y = 0; y < 16; y += 2) {
      for (let x = 0; x < 15; x++) {
        if (referenceHash2(x, y, 32) > 0.65) { referencePx(ctx, x, y, '#474747'); referencePx(ctx, x+1, y, '#474747'); }
      }
    }
  });

  REF_TEX.cobblestone = referenceCanvas16(ctx => {
    ctx.fillStyle = '#3b3b3b'; ctx.fillRect(0,0,16,16);
    const stones = [
      [1,1,5,4,'#5e5e5e'], [7,1,4,3,'#545454'], [12,1,3,5,'#666666'],
      [1,6,4,4,'#525252'], [6,5,5,5,'#636363'], [12,7,3,4,'#555555'],
      [1,11,6,4,'#616161'], [8,11,7,4,'#575757']
    ];
    stones.forEach(([x,y,w,h,c]) => {
      ctx.fillStyle = c; ctx.fillRect(x,y,w,h);
      ctx.fillStyle = '#737373'; ctx.fillRect(x,y,w-1,1);
      ctx.fillStyle = '#454545'; ctx.fillRect(x+1,y+h-1,w-1,1);
    });
  });

  REF_TEX.mossy_cobble = referenceCanvas16(ctx => {
    ctx.drawImage(REF_TEX.cobblestone, 0, 0);
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
      if (referenceHash2(x, y, 39) > 0.68) referencePx(ctx, x, y, referenceHash2(x,y,40)>0.5 ? '#43692c' : '#335220');
    }
  });

  REF_TEX.bedrock = referenceCanvas16(ctx => referenceFillNoise(ctx, ['#222222','#363636','#4a4a4a','#141414','#595959'], 44));

  function makeOre(dots, light, dark, seed) {
    return referenceCanvas16(ctx => {
      ctx.drawImage(REF_TEX.stone, 0, 0);
      dots.forEach(([x, y]) => {
        referencePx(ctx, x, y, light);
        if (x+1 < 16) referencePx(ctx, x+1, y, dark);
        if (y+1 < 16 && referenceHash2(x,y,seed) > 0.35) referencePx(ctx, x, y+1, dark);
      });
    });
  }
  const oreSpots = [[2,3],[6,2],[11,3],[4,7],[9,6],[13,8],[2,11],[7,12],[12,12]];
  REF_TEX.coal_ore = makeOre(oreSpots, '#262626', '#141414', 51);
  REF_TEX.iron_ore = makeOre(oreSpots, '#b89278', '#91705a', 52);
  REF_TEX.gold_ore = makeOre(oreSpots, '#d4c43b', '#ab851d', 53);
  REF_TEX.redstone_ore = makeOre(oreSpots, '#cc2222', '#870b0b', 54);
  REF_TEX.lapis_ore = makeOre([[3,3],[8,3],[5,8],[11,7],[4,12],[10,12]], '#2147a8', '#132b70', 55);
  REF_TEX.diamond_ore = makeOre([[3,3],[10,3],[6,7],[12,8],[3,12],[9,12]], '#4ec9ba', '#239c8e', 56);
  REF_TEX.emerald_ore = makeOre([[4,3],[11,4],[7,8],[3,11],[11,12]], '#34c76b', '#13873d', 57);

  function makeMineralBlock(c1, c2, c3, border) {
    return referenceCanvas16(ctx => {
      ctx.fillStyle = border; ctx.fillRect(0,0,16,16);
      ctx.fillStyle = c2; ctx.fillRect(1,1,14,14);
      ctx.fillStyle = c1; ctx.fillRect(2,2,11,11);
      ctx.fillStyle = c3; ctx.fillRect(2,2,4,4);
    });
  }
  REF_TEX.iron_block = makeMineralBlock('#a8a8a8', '#999999', '#bdbdbd', '#6e6e6e');
  REF_TEX.gold_block = makeMineralBlock('#cca61d', '#b89416', '#deba2b', '#82660b');
  REF_TEX.diamond_block = makeMineralBlock('#42b8aa', '#339e92', '#5ecfc2', '#1e6e65');
  REF_TEX.emerald_block = makeMineralBlock('#3ec26d', '#25a351', '#6ee096', '#136b32');
  REF_TEX.redstone_block = makeMineralBlock('#b52119', '#941610', '#d6453c', '#5e0a06');
  REF_TEX.lapis_block = makeMineralBlock('#20479e', '#17367a', '#3d68c7', '#0e224f');

  function makePlanks(cMain, cLight, cDark, cSeam) {
    return referenceCanvas16(ctx => {
      for (let row = 0; row < 4; row++) {
        const y0 = row * 4;
        ctx.fillStyle = cMain; ctx.fillRect(0, y0, 16, 4);
        ctx.fillStyle = cLight; ctx.fillRect(0, y0, 16, 1);
        ctx.fillStyle = cSeam; ctx.fillRect(0, y0+3, 16, 1);
        const vSeam = (row * 5 + 3) % 15;
        referencePx(ctx, vSeam, y0+1, cSeam); referencePx(ctx, vSeam, y0+2, cSeam);
        for (let x = 0; x < 16; x++) {
          if (referenceHash2(x, row, 71) > 0.72) referencePx(ctx, x, y0+1, cDark);
        }
      }
    });
  }
  REF_TEX.oak_planks = makePlanks('#7d6138', '#8f7042', '#6b522e', '#4f3b1f');
  REF_TEX.spruce_planks = makePlanks('#594025', '#694b2c', '#4a351e', '#362614');
  REF_TEX.birch_planks = makePlanks('#9e8f5c', '#ab9b65', '#8c7e4f', '#6e623b');
  REF_TEX.jungle_planks = makePlanks('#875e41', '#966949', '#755137', '#573b27');
  REF_TEX.acacia_planks = makePlanks('#99502b', '#ab5a31', '#824323', '#613018');
  REF_TEX.dark_oak_planks = makePlanks('#382412', '#452d17', '#2b1b0d', '#1c1108');

  function makeLogSide(c1, c2, c3, birch) {
    return referenceCanvas16(ctx => {
      for (let x = 0; x < 16; x++) {
        const col = x % 3 === 0 ? c2 : (x % 2 === 0 ? c1 : c3);
        for (let y = 0; y < 16; y++) {
          referencePx(ctx, x, y, referenceHash2(x,y,81) > 0.7 ? c2 : col);
        }
      }
      if (birch) {
        [[2,3,4],[9,2,5],[5,7,6],[1,11,5],[10,12,4]].forEach(([x,y,w]) => {
          ctx.fillStyle = '#262626'; ctx.fillRect(x,y,w,1);
          ctx.fillStyle = '#4f4f4f'; ctx.fillRect(x+1,y+1,Math.max(1,w-2),1);
        });
      }
    });
  }
  function makeLogTop(bark, ring1, ring2) {
    return referenceCanvas16(ctx => {
      ctx.fillStyle = bark; ctx.fillRect(0,0,16,16);
      ctx.fillStyle = ring1; ctx.fillRect(2,2,12,12);
      ctx.fillStyle = ring2; ctx.fillRect(4,4,8,8);
      ctx.fillStyle = ring1; ctx.fillRect(6,6,4,4);
      ctx.fillStyle = ring2; ctx.fillRect(7,7,2,2);
    });
  }
  REF_TEX.oak_log_side = makeLogSide('#574429','#42331e','#665031', false);
  REF_TEX.oak_log_top = makeLogTop('#4a3922','#8f7042','#6b522e');
  REF_TEX.birch_log_side = makeLogSide('#bdbcb7','#a8a7a2','#c9c8c3', true);
  REF_TEX.birch_log_top = makeLogTop('#b0afa9','#9e8f5c','#7d7046');
  REF_TEX.spruce_log_side = makeLogSide('#332110','#24160a','#402a15', false);
  REF_TEX.spruce_log_top = makeLogTop('#2b1b0d','#694b2c','#4a351e');

  REF_TEX.leaves = referenceCanvas16(ctx => {
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
      const r = referenceHash2(x, y, 91);
      if (r < 0.22) continue;
      referencePx(ctx, x, y, r < 0.5 ? '#315c1c' : (r < 0.8 ? '#3f7325' : '#244714'));
    }
  });

  REF_TEX.sand = referenceCanvas16(ctx => referenceFillNoise(ctx, ['#b5ad7e','#bfb786','#a8a072','#c7bf8d'], 101));
  REF_TEX.gravel = referenceCanvas16(ctx => referenceFillNoise(ctx, ['#5e5b5b','#4f4c4c','#6b6868','#423f3f','#757272'], 102));

  REF_TEX.bricks = referenceCanvas16(ctx => {
    ctx.fillStyle = '#8f8b83'; ctx.fillRect(0,0,16,16);
    const bCols = ['#7a372b','#6b2f24','#873f32'];
    for (let row = 0; row < 4; row++) {
      const y = row * 4;
      const off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        ctx.fillStyle = bCols[(row + Math.abs(bx)) % 3];
        ctx.fillRect(bx + off, y, 7, 3);
      }
    }
  });

  REF_TEX.stone_bricks = referenceCanvas16(ctx => {
    ctx.drawImage(REF_TEX.stone, 0, 0);
    ctx.fillStyle = '#3d3d3d';
    ctx.fillRect(0,7,16,1); ctx.fillRect(0,15,16,1);
    ctx.fillRect(7,0,1,7); ctx.fillRect(15,8,1,7);
    ctx.fillStyle = '#757575';
    ctx.fillRect(0,8,16,1); ctx.fillRect(0,0,16,1);
  });

  REF_TEX.obsidian = referenceCanvas16(ctx => referenceFillNoise(ctx, ['#14101d','#1e172b','#2d2142','#0d0a14','#3d2b59'], 111));
  REF_TEX.glowstone = referenceCanvas16(ctx => referenceFillNoise(ctx, ['#c79c38','#a6771e','#dbaf46','#78500d','#b88825'], 112));
  REF_TEX.netherrack = referenceCanvas16(ctx => referenceFillNoise(ctx, ['#5e2424','#4a1a1a','#702d2d','#3b1313','#803636'], 113));
  REF_TEX.end_stone = referenceCanvas16(ctx => referenceFillNoise(ctx, ['#b0b57e','#a1a670','#bdc28a','#919662'], 114));
  REF_TEX.slime_block = referenceCanvas16(ctx => {
    ctx.fillStyle = '#589e43'; ctx.fillRect(0,0,16,16);
    ctx.fillStyle = '#71bd5b'; ctx.fillRect(1,1,14,14);
    ctx.fillStyle = '#448231'; ctx.fillRect(4,4,8,8);
  });

  REF_TEX.glass = referenceCanvas16(ctx => {
    ctx.fillStyle = 'rgba(180,215,225,0.22)'; ctx.fillRect(0,0,16,16);
    ctx.fillStyle = '#a8cad4';
    ctx.fillRect(0,0,16,1); ctx.fillRect(0,15,16,1);
    ctx.fillRect(0,0,1,16); ctx.fillRect(15,0,1,16);
    referencePx(ctx,2,2,'#dceef2'); referencePx(ctx,3,2,'#dceef2'); referencePx(ctx,2,3,'#dceef2');
    referencePx(ctx,12,12,'#dceef2'); referencePx(ctx,13,13,'#dceef2');
  });

  REF_TEX.crafting_top = referenceCanvas16(ctx => {
    ctx.drawImage(REF_TEX.oak_planks, 0, 0);
    ctx.fillStyle = '#4a3118'; ctx.fillRect(1,1,14,14);
    ctx.fillStyle = '#73502c'; ctx.fillRect(2,2,12,12);
    ctx.fillStyle = '#4a3118';
    ctx.fillRect(5,2,1,12); ctx.fillRect(10,2,1,12);
    ctx.fillRect(2,5,12,1); ctx.fillRect(2,10,12,1);
  });
  REF_TEX.crafting_side = referenceCanvas16(ctx => {
    ctx.drawImage(REF_TEX.oak_planks, 0, 0);
    ctx.fillStyle = '#4a3118'; ctx.fillRect(0,0,16,3);
    ctx.fillStyle = '#737373'; ctx.fillRect(3,5,3,5);
    ctx.fillStyle = '#3d2814'; ctx.fillRect(4,10,1,4);
    ctx.fillStyle = '#949494'; ctx.fillRect(10,5,3,3);
    ctx.fillStyle = '#3d2814'; ctx.fillRect(11,8,1,6);
  });

  REF_TEX.furnace_front = referenceCanvas16(ctx => {
    ctx.drawImage(REF_TEX.cobblestone, 0, 0);
    ctx.fillStyle = '#1f1f1f'; ctx.fillRect(3,3,10,4);
    ctx.fillStyle = '#141414'; ctx.fillRect(4,10,8,5);
  });

  REF_TEX.tnt_side = referenceCanvas16(ctx => {
    ctx.fillStyle = '#b5291f'; ctx.fillRect(0,0,16,16);
    for (let x = 0; x < 16; x += 2) { ctx.fillStyle = '#941d15'; ctx.fillRect(x,0,1,16); }
    ctx.fillStyle = '#cfcfcf'; ctx.fillRect(0,5,16,6);
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(2,6,3,1); ctx.fillRect(3,6,1,4);
    ctx.fillRect(6,6,1,4); ctx.fillRect(7,7,1,2); ctx.fillRect(8,6,1,4);
    ctx.fillRect(10,6,3,1); ctx.fillRect(11,6,1,4);
  });
  REF_TEX.tnt_top = referenceCanvas16(ctx => {
    ctx.fillStyle = '#b5291f'; ctx.fillRect(0,0,16,16);
    ctx.fillStyle = '#3b3b3b'; ctx.fillRect(6,6,4,4);
    ctx.fillStyle = '#c7c7c7'; ctx.fillRect(7,7,2,2);
  });

  REF_TEX.bookshelf = referenceCanvas16(ctx => {
    ctx.drawImage(REF_TEX.oak_planks, 0, 0);
    ctx.fillStyle = '#24190d'; ctx.fillRect(1,2,14,5); ctx.fillRect(1,9,14,5);
    const cols = ['#8c2929','#294b8c','#2c7532','#a38022','#632b75'];
    for (let x = 2; x < 14; x += 2) {
      ctx.fillStyle = cols[x % cols.length]; ctx.fillRect(x,2,2,5);
      ctx.fillStyle = cols[(x+2) % cols.length]; ctx.fillRect(x,9,2,5);
    }
  });

  REF_TEX.water = referenceCanvas16(ctx => referenceFillNoise(ctx, ['#2851b5','#315ec9','#21459c','#3a6ad9'], 131));
  REF_TEX.lava = referenceCanvas16(ctx => referenceFillNoise(ctx, ['#c74d12','#db7318','#ab360a','#e09524'], 132));
}


function makeReferenceItemCanvas(type, c1, c2, c3) {
  return referenceCanvas16(ctx => {
    if (type === 'sword') {
      for (let i = 0; i < 9; i++) {
        referencePx(ctx, 13-i, 2+i, c1); referencePx(ctx, 12-i, 2+i, c3); referencePx(ctx, 13-i, 3+i, c2);
      }
      referencePx(ctx, 14, 1, c3); referencePx(ctx, 13, 1, c1); referencePx(ctx, 14, 2, c2);
      referencePx(ctx, 3, 9, '#4f361d'); referencePx(ctx, 4, 10, '#4f361d'); referencePx(ctx, 5, 11, '#4f361d'); referencePx(ctx, 6, 12, '#4f361d');
      referencePx(ctx, 3, 12, '#6e4d2b'); referencePx(ctx, 2, 13, '#6e4d2b'); referencePx(ctx, 1, 14, c2);
    } else if (type === 'pickaxe') {
      for (let i = 4; i <= 12; i++) { referencePx(ctx, i, 15-i, '#5c4023'); referencePx(ctx, i-1, 15-i, '#785530'); }
      ctx.fillStyle = c1;
      ctx.fillRect(4, 2, 7, 2); ctx.fillRect(11, 3, 2, 2); ctx.fillRect(12, 5, 2, 5);
      referencePx(ctx, 5, 2, c3); referencePx(ctx, 8, 2, c3); referencePx(ctx, 13, 6, c2);
    } else if (type === 'axe') {
      for (let i = 4; i <= 13; i++) { referencePx(ctx, i, 16-i, '#5c4023'); referencePx(ctx, i-1, 16-i, '#785530'); }
      ctx.fillStyle = c1;
      ctx.fillRect(7, 2, 5, 5); ctx.fillRect(6, 3, 2, 4);
      referencePx(ctx, 8, 2, c3); referencePx(ctx, 11, 6, c2);
    } else if (type === 'shovel') {
      for (let i = 3; i <= 10; i++) { referencePx(ctx, i, 15-i, '#5c4023'); referencePx(ctx, i-1, 15-i, '#785530'); }
      ctx.fillStyle = c1;
      ctx.fillRect(10, 2, 4, 4); referencePx(ctx, 11, 2, c3); referencePx(ctx, 13, 5, c2);
    } else if (type === 'hoe') {
      for (let i = 4; i <= 12; i++) { referencePx(ctx, i, 15-i, '#5c4023'); referencePx(ctx, i-1, 15-i, '#785530'); }
      ctx.fillStyle = c1;
      ctx.fillRect(6, 2, 6, 2); ctx.fillRect(11, 3, 2, 2);
      referencePx(ctx, 7, 2, c3);
    } else if (type === 'bow') {
      ctx.fillStyle = '#6e4d2b';
      ctx.fillRect(4, 2, 2, 2); ctx.fillRect(6, 2, 3, 1); ctx.fillRect(9, 3, 2, 2);
      ctx.fillRect(11, 5, 1, 5); ctx.fillRect(9, 10, 2, 2); ctx.fillRect(6, 12, 3, 1); ctx.fillRect(4, 11, 2, 2);
      ctx.fillStyle = '#cfcfcf';
      for (let y = 3; y <= 11; y++) referencePx(ctx, 4, y, '#cfcfcf');
    } else if (type === 'arrow') {
      for (let i = 3; i <= 12; i++) referencePx(ctx, i, 15-i, '#785530');
      ctx.fillStyle = '#b0b0b0';
      ctx.fillRect(11, 2, 3, 2); ctx.fillRect(12, 2, 2, 3);
      ctx.fillStyle = '#e6e6e6';
      ctx.fillRect(2, 11, 2, 3); ctx.fillRect(3, 12, 3, 2);
    } else if (type === 'shield') {
      ctx.fillStyle = '#8c8c8c'; ctx.fillRect(3, 1, 10, 14);
      ctx.fillStyle = '#73502c'; ctx.fillRect(4, 2, 8, 12);
      ctx.fillStyle = '#5c4023'; ctx.fillRect(6, 2, 1, 12); ctx.fillRect(9, 2, 1, 12);
      ctx.fillStyle = '#b5b5b5'; ctx.fillRect(7, 6, 2, 4);
    } else if (type === 'fishing_rod') {
      for (let i = 2; i <= 11; i++) referencePx(ctx, i, 14-i, '#6e4d2b');
      ctx.fillStyle = '#d9d9d9';
      for (let y = 3; y <= 12; y++) referencePx(ctx, 11, y, '#d9d9d9');
      ctx.fillStyle = '#b5291f'; ctx.fillRect(10, 11, 2, 2);
    } else if (type === 'flint_and_steel') {
      ctx.fillStyle = '#b5b5b5'; ctx.fillRect(7, 3, 5, 2); ctx.fillRect(10, 5, 2, 5); ctx.fillRect(8, 9, 3, 2);
      ctx.fillStyle = '#363636'; ctx.fillRect(3, 6, 5, 6);
      ctx.fillStyle = '#636363'; ctx.fillRect(4, 7, 2, 2);
    } else if (type === 'potion') {
      ctx.fillStyle = '#785530'; ctx.fillRect(7, 1, 2, 2);
      ctx.fillStyle = '#b8d8e6'; ctx.fillRect(6, 3, 4, 2); ctx.fillRect(4, 5, 8, 9);
      ctx.fillStyle = c1; ctx.fillRect(5, 7, 6, 6);
      ctx.fillStyle = c3; ctx.fillRect(5, 7, 2, 2);
    } else if (type === 'spectral_arrow') {
      for (let i = 3; i <= 12; i++) referencePx(ctx, i, 15-i, '#d4af37');
      ctx.fillStyle = '#ffea61';
      ctx.fillRect(11, 2, 3, 2); ctx.fillRect(12, 2, 2, 3);
      ctx.fillStyle = '#fff5b8';
      ctx.fillRect(2, 11, 2, 3); ctx.fillRect(3, 12, 3, 2);
    } else if (type === 'tnt_item') {
      ctx.drawImage(REF_TEX.tnt_side, 2, 2, 12, 12);
    }
    // === ВСЕ ВИДЫ ЕДЫ 1.12.2 ===
    else if (type === 'apple') {
      ctx.fillStyle = '#5c3d1e'; ctx.fillRect(7, 2, 2, 3);
      ctx.fillStyle = '#3a7a23'; ctx.fillRect(9, 2, 3, 2);
      ctx.fillStyle = c2; ctx.fillRect(4, 5, 8, 9); ctx.fillRect(3, 6, 10, 7);
      ctx.fillStyle = c1; ctx.fillRect(4, 5, 7, 8);
      ctx.fillStyle = c3; ctx.fillRect(5, 6, 2, 3);
    } else if (type === 'bread') {
      ctx.fillStyle = '#693f16'; ctx.fillRect(2, 6, 12, 6); ctx.fillRect(3, 5, 10, 7);
      ctx.fillStyle = '#b5762d'; ctx.fillRect(3, 6, 10, 4);
      ctx.fillStyle = '#d49546'; ctx.fillRect(4, 6, 2, 2); ctx.fillRect(8, 6, 2, 2);
    } else if (type === 'steak') {
      ctx.fillStyle = c2; ctx.fillRect(3, 4, 10, 8); ctx.fillRect(2, 5, 12, 6);
      ctx.fillStyle = c1; ctx.fillRect(4, 5, 8, 6);
      ctx.fillStyle = c3; ctx.fillRect(4, 5, 3, 2); referencePx(ctx, 9, 8, c3);
    } else if (type === 'porkchop') {
      ctx.fillStyle = c2; ctx.fillRect(3, 4, 10, 8); ctx.fillRect(4, 3, 8, 10);
      ctx.fillStyle = c1; ctx.fillRect(4, 5, 8, 6);
      ctx.fillStyle = c3; ctx.fillRect(5, 5, 4, 2);
    } else if (type === 'chicken_food') {
      ctx.fillStyle = '#e3d5c3'; ctx.fillRect(2, 10, 4, 3);
      ctx.fillStyle = c2; ctx.fillRect(5, 4, 8, 8);
      ctx.fillStyle = c1; ctx.fillRect(6, 5, 6, 6);
      ctx.fillStyle = c3; ctx.fillRect(7, 5, 3, 2);
    } else if (type === 'mutton') {
      ctx.fillStyle = c2; ctx.fillRect(3, 5, 10, 7);
      ctx.fillStyle = c1; ctx.fillRect(4, 6, 8, 5);
      ctx.fillStyle = '#e8dfd5'; ctx.fillRect(3, 7, 3, 3);
    } else if (type === 'rabbit_food') {
      ctx.fillStyle = '#d9ccb8'; ctx.fillRect(3, 11, 3, 3);
      ctx.fillStyle = c2; ctx.fillRect(5, 4, 7, 8);
      ctx.fillStyle = c1; ctx.fillRect(6, 5, 5, 6);
    } else if (type === 'fish') {
      ctx.fillStyle = c2; ctx.fillRect(3, 5, 8, 6); ctx.fillRect(11, 4, 3, 8);
      ctx.fillStyle = c1; ctx.fillRect(4, 6, 6, 4);
      referencePx(ctx, 4, 7, '#1a1a1a');
      ctx.fillStyle = c3; ctx.fillRect(6, 6, 3, 2);
    } else if (type === 'pufferfish') {
      ctx.fillStyle = '#c9a628'; ctx.fillRect(4, 4, 8, 8);
      ctx.fillStyle = '#e8c743'; ctx.fillRect(5, 5, 6, 6);
      ctx.fillStyle = '#8fa8b5'; ctx.fillRect(5, 8, 6, 3);
      referencePx(ctx, 3, 4, '#fff2a6'); referencePx(ctx, 12, 4, '#fff2a6'); referencePx(ctx, 3, 11, '#fff2a6'); referencePx(ctx, 12, 11, '#fff2a6');
      referencePx(ctx, 5, 6, '#1a1a1a'); referencePx(ctx, 10, 6, '#1a1a1a');
    } else if (type === 'carrot') {
      ctx.fillStyle = '#3a7a23'; ctx.fillRect(10, 2, 4, 3); ctx.fillRect(11, 5, 2, 2);
      ctx.fillStyle = c2;
      for (let i = 0; i < 8; i++) ctx.fillRect(3+i, 11-i, 3, 3);
      ctx.fillStyle = c1;
      for (let i = 1; i < 7; i++) ctx.fillRect(3+i, 11-i, 2, 2);
    } else if (type === 'potato') {
      ctx.fillStyle = c2; ctx.fillRect(4, 4, 8, 9); ctx.fillRect(3, 5, 10, 7);
      ctx.fillStyle = c1; ctx.fillRect(5, 5, 6, 7);
      referencePx(ctx, 6, 7, c3); referencePx(ctx, 9, 9, c3);
    } else if (type === 'beetroot') {
      ctx.fillStyle = '#3a7a23'; ctx.fillRect(6, 1, 4, 4);
      ctx.fillStyle = c2; ctx.fillRect(4, 5, 8, 8); ctx.fillRect(5, 13, 6, 2);
      ctx.fillStyle = c1; ctx.fillRect(5, 6, 6, 6);
    } else if (type === 'melon_slice') {
      ctx.fillStyle = '#3a7a23'; ctx.fillRect(2, 10, 12, 2); ctx.fillRect(4, 12, 8, 2);
      ctx.fillStyle = '#b8322c'; ctx.fillRect(3, 6, 10, 4); ctx.fillRect(5, 4, 6, 2);
      referencePx(ctx, 5, 7, '#1a1a1a'); referencePx(ctx, 8, 6, '#1a1a1a'); referencePx(ctx, 10, 8, '#1a1a1a');
    } else if (type === 'cookie') {
      ctx.fillStyle = '#8c5828'; ctx.fillRect(4, 3, 8, 10); ctx.fillRect(3, 4, 10, 8);
      ctx.fillStyle = '#b57638'; ctx.fillRect(4, 4, 8, 8);
      referencePx(ctx, 5, 6, '#361f0d'); referencePx(ctx, 9, 5, '#361f0d'); referencePx(ctx, 7, 9, '#361f0d'); referencePx(ctx, 10, 9, '#361f0d');
    } else if (type === 'pumpkin_pie') {
      ctx.fillStyle = '#9c6631'; ctx.fillRect(2, 8, 12, 5);
      ctx.fillStyle = '#c96f24'; ctx.fillRect(3, 5, 10, 4);
      ctx.fillStyle = '#e68a39'; ctx.fillRect(4, 5, 8, 2);
    } else if (type === 'cake') {
      ctx.fillStyle = '#8c5828'; ctx.fillRect(2, 9, 12, 5);
      ctx.fillStyle = '#e6e6e6'; ctx.fillRect(2, 6, 12, 3);
      referencePx(ctx, 4, 9, '#e6e6e6'); referencePx(ctx, 8, 9, '#e6e6e6'); referencePx(ctx, 11, 9, '#e6e6e6');
      referencePx(ctx, 5, 7, '#b5291f'); referencePx(ctx, 9, 7, '#b5291f'); referencePx(ctx, 7, 6, '#b5291f');
    } else if (type === 'bowl_stew') {
      ctx.fillStyle = '#694422'; ctx.fillRect(2, 8, 12, 4); ctx.fillRect(4, 12, 8, 2);
      ctx.fillStyle = c1; ctx.fillRect(3, 6, 10, 3);
      referencePx(ctx, 5, 7, c3); referencePx(ctx, 9, 7, c2);
    } else if (type === 'chorus_fruit') {
      ctx.fillStyle = '#633d6e'; ctx.fillRect(5, 4, 6, 8); ctx.fillRect(4, 5, 8, 6);
      ctx.fillStyle = '#8a5999'; ctx.fillRect(6, 5, 4, 6);
      ctx.fillStyle = '#472b4f'; ctx.fillRect(7, 2, 2, 2);
    } else if (type === 'rotten_flesh') {
      ctx.fillStyle = '#6e3523'; ctx.fillRect(3, 4, 10, 8);
      ctx.fillStyle = '#8f4730'; ctx.fillRect(4, 5, 8, 6);
      ctx.fillStyle = '#476e2b'; ctx.fillRect(5, 6, 3, 3); referencePx(ctx, 9, 8, '#476e2b');
    } else if (type === 'spider_eye') {
      ctx.fillStyle = '#5c1428'; ctx.fillRect(4, 4, 8, 8);
      ctx.fillStyle = '#8c1d3b'; ctx.fillRect(5, 5, 6, 6);
      ctx.fillStyle = '#41b868'; ctx.fillRect(6, 6, 2, 2);
    } else if (type === 'milk_bucket') {
      ctx.fillStyle = '#737373'; ctx.fillRect(4, 5, 8, 9); ctx.fillRect(5, 14, 6, 1);
      ctx.fillStyle = '#9c9c9c'; ctx.fillRect(5, 6, 6, 7);
      ctx.fillStyle = '#e6e6e6'; ctx.fillRect(5, 4, 6, 3);
    }
    // === РЕСУРСЫ И БРОНЯ ===
    else if (type === 'ingot') {
      ctx.fillStyle = c2; ctx.fillRect(3, 6, 10, 5);
      ctx.fillStyle = c1; ctx.fillRect(4, 5, 8, 5);
      ctx.fillStyle = c3; ctx.fillRect(5, 5, 5, 2);
    } else if (type === 'gem') {
      ctx.fillStyle = c2; ctx.fillRect(4, 3, 8, 10); ctx.fillRect(3, 5, 10, 6);
      ctx.fillStyle = c1; ctx.fillRect(5, 4, 6, 8); ctx.fillRect(4, 6, 8, 4);
      ctx.fillStyle = c3; ctx.fillRect(5, 5, 3, 3);
    } else if (type === 'pearl') {
      ctx.fillStyle = '#0d3d36'; ctx.fillRect(4, 4, 8, 8); ctx.fillRect(3, 5, 10, 6);
      ctx.fillStyle = '#1e786b'; ctx.fillRect(5, 5, 6, 6);
      ctx.fillStyle = '#5ecfc2'; ctx.fillRect(6, 5, 2, 2);
    } else if (type === 'armor_helmet') {
      ctx.fillStyle = c2; ctx.fillRect(3, 4, 10, 8);
      ctx.fillStyle = c1; ctx.fillRect(4, 5, 8, 6);
      ctx.fillStyle = '#141619'; ctx.fillRect(5, 8, 6, 4);
      ctx.fillStyle = c3; ctx.fillRect(5, 5, 3, 2);
    } else if (type === 'armor_chest') {
      ctx.fillStyle = c2; ctx.fillRect(2, 3, 12, 10);
      ctx.fillStyle = c1; ctx.fillRect(3, 4, 10, 8);
      ctx.fillStyle = '#141619'; ctx.fillRect(6, 3, 4, 2);
      ctx.fillStyle = c3; ctx.fillRect(4, 5, 2, 4);
    } else if (type === 'armor_legs') {
      ctx.fillStyle = c2; ctx.fillRect(3, 2, 10, 12);
      ctx.fillStyle = c1; ctx.fillRect(4, 3, 8, 10);
      ctx.fillStyle = '#141619'; ctx.fillRect(7, 7, 2, 7);
      ctx.fillStyle = c3; ctx.fillRect(5, 4, 2, 4);
    } else if (type === 'armor_boots') {
      ctx.fillStyle = c2; ctx.fillRect(2, 7, 5, 7); ctx.fillRect(9, 7, 5, 7);
      ctx.fillStyle = c1; ctx.fillRect(3, 8, 3, 5); ctx.fillRect(10, 8, 3, 5);
      ctx.fillStyle = c3; ctx.fillRect(3, 8, 2, 2); ctx.fillRect(10, 8, 2, 2);
    } else if (type === 'elytra') {
      ctx.fillStyle = '#636675'; ctx.fillRect(4, 2, 3, 11); ctx.fillRect(9, 2, 3, 11);
      ctx.fillStyle = '#8c90a3'; ctx.fillRect(3, 4, 3, 8); ctx.fillRect(10, 4, 3, 8);
      ctx.fillStyle = '#b4b8cc'; ctx.fillRect(5, 3, 1, 6); ctx.fillRect(10, 3, 1, 6);
    }
  });
}



    // Reference atlas imported from maksik.txt: this replaces the previous atlas rather than layering over it.
    function referenceMaterial(canvas, extra = {}) {
      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestMipmapNearestFilter;
      tex.generateMipmaps = true;
      tex.needsUpdate = true;
      return new THREE.MeshLambertMaterial({ map: tex, ...extra });
    }
    function applyReferenceAtlas() {
      initReferenceTextures();
      const assign = (id, top, side = top, bottom = top, extra = {}) => {
        ATLAS.materials[id] = [referenceMaterial(side,extra),referenceMaterial(side,extra),referenceMaterial(top,extra),referenceMaterial(bottom,extra),referenceMaterial(side,extra),referenceMaterial(side,extra)];
        ATLAS.icons[id] = top.toDataURL("image/png");
      };
      assign(B.GRASS,REF_TEX.grass_top,REF_TEX.grass_side,REF_TEX.dirt);
      assign(B.DIRT,REF_TEX.dirt); assign(B.STONE,REF_TEX.stone); assign(B.COBBLESTONE,REF_TEX.cobblestone);
      assign(B.BEDROCK,REF_TEX.bedrock); assign(B.OAK_LOG,REF_TEX.oak_log_top,REF_TEX.oak_log_side,REF_TEX.oak_log_top);
      assign(B.OAK_PLANKS,REF_TEX.oak_planks); assign(B.OAK_LEAVES,REF_TEX.leaves,REF_TEX.leaves,REF_TEX.leaves,{transparent:true,alphaTest:0.18});
      assign(B.SAND,REF_TEX.sand); assign(B.GRAVEL,REF_TEX.gravel);
      assign(B.COAL_ORE,REF_TEX.coal_ore); assign(B.IRON_ORE,REF_TEX.iron_ore); assign(B.GOLD_ORE,REF_TEX.gold_ore);
      assign(B.DIAMOND_ORE,REF_TEX.diamond_ore); assign(B.REDSTONE_ORE,REF_TEX.redstone_ore); assign(B.LAPIS_ORE,REF_TEX.lapis_ore);
      assign(B.CRAFTING_TABLE,REF_TEX.crafting_top,REF_TEX.crafting_side,REF_TEX.oak_planks);
      assign(B.FURNACE,REF_TEX.stone,REF_TEX.cobblestone,REF_TEX.stone);
      assign(B.CHEST,REF_TEX.oak_planks,REF_TEX.oak_planks,REF_TEX.oak_planks);
      assign(B.TORCH,REF_TEX.leaves,REF_TEX.leaves,REF_TEX.leaves,{transparent:true});
      assign(B.GLASS,REF_TEX.glass,REF_TEX.glass,REF_TEX.glass,{transparent:true,opacity:0.65});
      assign(B.WATER,REF_TEX.water,REF_TEX.water,REF_TEX.water,{transparent:true,opacity:0.82});
      assign(B.LAVA,REF_TEX.lava);
      assign(B.OBSIDIAN,REF_TEX.obsidian); assign(B.NETHERRACK,REF_TEX.netherrack); assign(B.SOUL_SAND,REF_TEX.dirt);
      assign(B.GLOWSTONE,REF_TEX.glowstone); assign(B.NETHER_PORTAL,REF_TEX.obsidian,REF_TEX.obsidian,REF_TEX.obsidian,{transparent:true,opacity:0.75});
      assign(B.END_STONE,REF_TEX.end_stone); assign(B.END_PORTAL_FRAME,REF_TEX.stone,REF_TEX.stone,REF_TEX.end_stone);
      assign(B.END_PORTAL_FRAME_EYE,REF_TEX.emerald_block,REF_TEX.stone,REF_TEX.end_stone);
      assign(B.END_PORTAL,REF_TEX.obsidian,REF_TEX.obsidian,REF_TEX.obsidian,{transparent:true,opacity:0.8});
      assign(B.FARMLAND,REF_TEX.dirt); assign(B.WHEAT_1,REF_TEX.leaves,REF_TEX.leaves,REF_TEX.leaves,{transparent:true});
      assign(B.WHEAT_7,REF_TEX.leaves,REF_TEX.leaves,REF_TEX.leaves,{transparent:true});
      assign(B.POPPY,REF_TEX.leaves,REF_TEX.leaves,REF_TEX.leaves,{transparent:true});
      assign(B.DANDELION,REF_TEX.leaves,REF_TEX.leaves,REF_TEX.leaves,{transparent:true});
      assign(B.STONE_BRICKS,REF_TEX.stone_bricks); assign(B.DRAGON_EGG,REF_TEX.obsidian);
      assign(B.BOOKSHELF,REF_TEX.bookshelf,REF_TEX.bookshelf,REF_TEX.oak_planks);
      assign(B.WOOL_WHITE,REF_TEX.leaves); assign(B.BRICKS,REF_TEX.bricks); assign(B.TNT,REF_TEX.tnt_top,REF_TEX.tnt_side,REF_TEX.tnt_top);
      assign(B.HAY_BLOCK,REF_TEX.oak_planks); assign(B.SANDSTONE,REF_TEX.sand,REF_TEX.sand,REF_TEX.sand);
      assign(B.NETHER_BRICKS,REF_TEX.bricks); assign(B.QUARTZ_ORE,REF_TEX.iron_ore);
      assign(B.GOLD_BLOCK,REF_TEX.gold_block); assign(B.BED_FOOT,REF_TEX.oak_planks); assign(B.BED_HEAD,REF_TEX.oak_planks);
      assign(B.CRYING_OBSIDIAN,REF_TEX.obsidian); assign(B.ANCIENT_DEBRIS,REF_TEX.iron_ore);
      assign(B.NETHER_GOLD_ORE,REF_TEX.gold_ore); assign(B.BASALT,REF_TEX.stone); assign(B.BLACKSTONE,REF_TEX.cobblestone);
      assign(B.SOUL_SOIL,REF_TEX.dirt);
      const legacy = {stone:REF_TEX.stone,earth:REF_TEX.dirt,wood:REF_TEX.oak_planks,leaf:REF_TEX.leaves,ice:REF_TEX.glass,ocean:REF_TEX.water,glow:REF_TEX.glowstone,quartz:REF_TEX.sand,ore:REF_TEX.iron_ore,gem:REF_TEX.diamond_block,wool:REF_TEX.oak_planks,glass:REF_TEX.glass,purpur:REF_TEX.obsidian,nether:REF_TEX.netherrack,bone:REF_TEX.sand,tech:REF_TEX.stone,slime:REF_TEX.leaves,iron:REF_TEX.stone};
      for (const [key,,palette] of LEGACY_BLOCKS) if (B[key] !== undefined) assign(B[key],legacy[palette]||REF_TEX.stone);
      const tier = {wood:['#8f7042','#5c4524','#b38f59'],stone:['#7d7d7d','#4d4d4d','#a8a8a8'],iron:['#c9c9c9','#858585','#f0f0f0'],gold:['#e3c22b','#9c7c14','#fff28c'],diamond:['#4ec9ba','#1e877b','#9ef7ec'],netherite:['#71636a','#423b40','#a18a92']};
      const itemType = id => {
        const k=String(id).toLowerCase();
        if(k.includes('spawn_egg'))return 'spawn_egg';
        if(k.includes('sword'))return 'sword'; if(k.includes('pickaxe'))return 'pickaxe'; if(k.includes('axe'))return 'axe';
        if(k.includes('shovel'))return 'shovel'; if(k.includes('hoe'))return 'hoe'; if(k.includes('bow'))return 'bow';
        if(k.includes('arrow'))return k.includes('spectral')?'spectral_arrow':'arrow'; if(k.includes('shield'))return 'shield';
        if(k.includes('fishing_rod'))return 'fishing_rod'; if(k.includes('flint_and_steel'))return 'flint_and_steel';
        if(k.includes('potion'))return 'potion'; if(k.includes('golden_apple')||k==='apple')return 'apple';
        if(k.includes('bread'))return 'bread'; if(k.includes('beef'))return 'steak'; if(k.includes('pork'))return 'porkchop';
        if(k.includes('chicken'))return 'chicken_food'; if(k.includes('mutton'))return 'mutton'; if(k.includes('rabbit'))return 'rabbit_food';
        if(k.includes('fish')||k.includes('salmon'))return 'fish'; if(k.includes('carrot'))return 'carrot'; if(k.includes('potato'))return 'potato';
        if(k.includes('beetroot'))return 'beetroot'; if(k.includes('melon'))return 'melon_slice'; if(k.includes('cookie'))return 'cookie';
        if(k.includes('pumpkin_pie'))return 'pumpkin_pie'; if(k.includes('cake'))return 'cake'; if(k.includes('stew')||k.includes('soup'))return 'bowl_stew';
        if(k.includes('chorus'))return 'chorus_fruit'; if(k.includes('rotten_flesh'))return 'rotten_flesh'; if(k.includes('spider_eye'))return 'spider_eye';
        if(k.includes('bucket'))return 'milk_bucket'; if(k.includes('ingot')||k.includes('scrap'))return 'ingot';
        if(k.includes('diamond')||k.includes('emerald')||k.includes('gem'))return 'gem'; if(k.includes('pearl')||k.includes('eye'))return 'pearl';
        if(k.includes('helmet'))return 'armor_helmet'; if(k.includes('chestplate'))return 'armor_chest';
        if(k.includes('leggings'))return 'armor_legs'; if(k.includes('boots'))return 'armor_boots'; if(k.includes('elytra'))return 'elytra';
        if(k.includes('tnt'))return 'tnt_item'; if(k.includes('coal'))return 'gem'; if(k.includes('bone'))return 'ingot';
        return 'gem';
      };
      for (const id of Object.keys(ITEMS)) {
        const t=itemType(id), tierKey=Object.keys(tier).find(k=>id.includes(k))||'iron';
        const foodColors = {
          apple:['#b5291f','#6e140e','#e3594f'],golden_apple:['#e3c22b','#9c7c14','#fff28c'],
          bread:['#b5762d','#693f16','#d49546'],raw_beef:['#a83232','#631717','#d97373'],cooked_beef:['#733c26','#421f12','#b88c72'],
          raw_porkchop:['#cf6f6f','#8c3f3f','#f0a8a8'],cooked_porkchop:['#a66b3c','#663c1c','#d49e6e'],
          raw_chicken:['#cf8a82','#8c524b','#f0bdb6'],cooked_chicken:['#9e5c2b','#5e3313','#cc8852'],
          raw_mutton:['#9e3434','#5e1919','#cf6b6b'],cooked_mutton:['#753f29','#422012','#ab6e52'],
          raw_rabbit:['#c97973','#85443f','#eba6a0'],cooked_rabbit:['#99592e','#593014','#c78354'],
          raw_fish:['#6b8c99','#3e5761','#9ec2cf'],cooked_fish:['#8c6e46','#523e24','#ba9b70'],
          carrot:['#d46b1c','#8c410b','#f09348'],golden_carrot:['#e3c22b','#9c7c14','#fff28c'],
          potato:['#ba954e','#785c29','#dec07c'],baked_potato:['#9e7334','#5e4017','#cc9f58'],
          poisonous_potato:['#7d8c3a','#4a541d','#a8b85c'],beetroot:['#8c2432','#4f0e17','#b84857']
        };
        const colors=foodColors[id]||tier[tierKey];
        const canvas = t==='spawn_egg' ? referenceCanvas16(ctx=>{ctx.fillStyle='#e5dfc7';ctx.fillRect(4,2,8,12);ctx.fillStyle='#6b9b4a';ctx.fillRect(5,4,6,5);ctx.fillStyle='#3d6634';ctx.fillRect(6,5,3,2);}) : makeReferenceItemCanvas(t,...colors);
        const tex = new THREE.CanvasTexture(canvas); tex.colorSpace=THREE.SRGBColorSpace; tex.magFilter=THREE.NearestFilter; tex.minFilter=THREE.NearestMipmapNearestFilter; tex.generateMipmaps=true;
        ATLAS.icons[id]=canvas.toDataURL('image/png'); ATLAS.itemTextures[id]=tex;
      }
      // Common world drops and hand-held resources use the same reference sprites.
      for (const id of ['coal','redstone','lapis','quartz','stick','bone','string','feather','leather','egg','gunpowder','blaze_rod','blaze_powder','ender_pearl','ender_eye','wheat','wheat_seeds','bucket_water','bucket_lava','netherite_scrap','netherite_ingot','wither_skull']) {
        if (ATLAS.itemTextures[id]) continue;
        const type=itemType(id), colors=tier.iron;
        const canvas=makeReferenceItemCanvas(type,...colors),tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;tex.magFilter=THREE.NearestFilter;tex.minFilter=THREE.NearestMipmapNearestFilter;tex.generateMipmaps=true;
        ATLAS.icons[id]=canvas.toDataURL('image/png');ATLAS.itemTextures[id]=tex;
      }
    }
    const REF_MOB_TEXTURES = new Map();
    function getReferenceMobTexture(type) {
      if(REF_MOB_TEXTURES.has(type)) return REF_MOB_TEXTURES.get(type);
      const palettes = {
        cow:['#45362b','#bfb8b2'],pig:['#d98f8c','#b06663'],sheep:['#d6d6d6','#bf8c86'],chicken:['#e0e0e0','#c72424'],rabbit:['#b69a78','#8c7258'],
        wolf:['#b8b2ad','#4a4542'],creeper:['#48a83b','#1b2619'],zombie:['#48733b','#2e828c'],skeleton:['#c9c9c9','#757575'],
        wither_skeleton:['#262626','#4b4b4b'],spider:['#362e2b','#b81d1d'],enderman:['#161616','#cc49f5'],ghast:['#d9d9d9','#999999'],
        blaze:['#d9a11e','#7a2b0a'],slime:['#4fa13b','#316923'],shulker:['#825882','#d6cc96'],iron_golem:['#bfb4a8','#45732f'],
        dragon:['#1a181c','#b53dd6'],wither:['#242424','#5c7c9c'],
        villager_fletcher:['#75604a','#8a6a45'],villager_farmer:['#6b7c3b','#b59a52'],villager_blacksmith:['#55585a','#777777'],villager_cleric:['#8d4e8b','#b58ab2'],villager_skin:['#b98662','#e0b28c']
      };
      const [base,accent]=palettes[type]||['#806b54','#493c32'];
      const canvas=referenceCanvas16(ctx=>{
        ctx.fillStyle=base;ctx.fillRect(0,0,16,16);
        for(let y=0;y<16;y++)for(let x=0;x<16;x++){
          const h=referenceHash2(x,y,type.length*17);
          if(type==='cow' && h>0.68){ctx.fillStyle=accent;ctx.fillRect(x,y,1,1);}
          else if(type==='sheep' && h>0.64){ctx.fillStyle=h>0.84?'#f1eee5':accent;ctx.fillRect(x,y,1,1);}
          else if(type==='pig' && h>0.74){ctx.fillStyle=accent;ctx.fillRect(x,y,1,1);}
          else if(type==='chicken' && h>0.72){ctx.fillStyle=accent;ctx.fillRect(x,y,1,1);}
          else if(type.startsWith('villager_') && (y<3 || (x+y)%7===0)){ctx.fillStyle=accent;ctx.fillRect(x,y,1,1);}
          else if(h>0.79){ctx.fillStyle=accent;ctx.fillRect(x,y,1,1);}
        }
        if(type==='cow'){ctx.fillStyle=accent;ctx.fillRect(2,2,4,3);ctx.fillRect(10,10,4,3);}
        if(type==='pig'){ctx.fillStyle='#efb1b0';ctx.fillRect(5,6,6,4);}
        if(type==='chicken'){ctx.fillStyle='#f5f1e7';ctx.fillRect(3,3,10,8);}
        if(type.startsWith('villager_')){ctx.fillStyle=base;ctx.fillRect(0,0,16,16);ctx.fillStyle=accent;ctx.fillRect(0,0,16,3);ctx.fillRect(2,7,12,2);}
      });
      const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;tex.magFilter=THREE.NearestFilter;tex.minFilter=THREE.NearestMipmapNearestFilter;tex.generateMipmaps=true;tex.needsUpdate=true;
      REF_MOB_TEXTURES.set(type,tex);return tex;
    }

    // =========================================================================
    // 4. RECIPES, SMELTING & VILLAGER TRADES (FLETCHER, FARMER, BLACKSMITH, CLERIC)
    // =========================================================================
    const RECIPES = [
      { out: { id: B.OAK_PLANKS, count: 4 }, req: { [B.OAK_LOG]: 1 } },
      { out: { id: "stick", count: 4 }, req: { [B.OAK_PLANKS]: 2 } },
      { out: { id: B.CRAFTING_TABLE, count: 1 }, req: { [B.OAK_PLANKS]: 4 } },
      { out: { id: B.TORCH, count: 4 }, req: { coal: 1, stick: 1 } },
      { out: { id: B.FURNACE, count: 1 }, req: { [B.COBBLESTONE]: 8 } },
      { out: { id: B.CHEST, count: 1 }, req: { [B.OAK_PLANKS]: 8 } },
      { out: { id: "bed", count: 1 }, req: { [B.WOOL_WHITE]: 3, [B.OAK_PLANKS]: 3 } },
      { out: { id: "shield", count: 1 }, req: { [B.OAK_PLANKS]: 6, iron_ingot: 1 } },
      { out: { id: "wood_pickaxe", count: 1 }, req: { [B.OAK_PLANKS]: 3, stick: 2 } },
      { out: { id: "wood_axe", count: 1 }, req: { [B.OAK_PLANKS]: 3, stick: 2 } },
      { out: { id: "wood_sword", count: 1 }, req: { [B.OAK_PLANKS]: 2, stick: 1 } },
      { out: { id: "wood_hoe", count: 1 }, req: { [B.OAK_PLANKS]: 2, stick: 2 } },
      { out: { id: "wood_shovel", count: 1 }, req: { [B.OAK_PLANKS]: 1, stick: 2 } },
      { out: { id: "stone_shovel", count: 1 }, req: { [B.COBBLESTONE]: 1, stick: 2 } },
      { out: { id: "iron_shovel", count: 1 }, req: { iron_ingot: 1, stick: 2 } },
      { out: { id: "diamond_shovel", count: 1 }, req: { diamond: 1, stick: 2 } },
      { out: { id: "stone_hoe", count: 1 }, req: { [B.COBBLESTONE]: 2, stick: 2 } },
      { out: { id: "iron_hoe", count: 1 }, req: { iron_ingot: 2, stick: 2 } },
      { out: { id: "diamond_hoe", count: 1 }, req: { diamond: 2, stick: 2 } },
      { out: { id: "netherite_axe", count: 1 }, req: { diamond: 1, netherite_ingot: 1, stick: 2 } },
      { out: { id: "netherite_hoe", count: 1 }, req: { diamond: 1, netherite_ingot: 1, stick: 2 } },
      { out: { id: "stone_pickaxe", count: 1 }, req: { [B.COBBLESTONE]: 3, stick: 2 } },
      { out: { id: "stone_axe", count: 1 }, req: { [B.COBBLESTONE]: 3, stick: 2 } },
      { out: { id: "stone_sword", count: 1 }, req: { [B.COBBLESTONE]: 2, stick: 1 } },
      { out: { id: "iron_pickaxe", count: 1 }, req: { iron_ingot: 3, stick: 2 } },
      { out: { id: "iron_axe", count: 1 }, req: { iron_ingot: 3, stick: 2 } },
      { out: { id: "iron_sword", count: 1 }, req: { iron_ingot: 2, stick: 1 } },
      { out: { id: "iron_helmet", count: 1 }, req: { iron_ingot: 5 } },
      { out: { id: "iron_chestplate", count: 1 }, req: { iron_ingot: 8 } },
      { out: { id: "leather_helmet", count: 1 }, req: { leather: 5 } },
      { out: { id: "leather_chestplate", count: 1 }, req: { leather: 8 } },
      { out: { id: "leather_leggings", count: 1 }, req: { leather: 7 } },
      { out: { id: "leather_boots", count: 1 }, req: { leather: 4 } },
      { out: { id: "gold_helmet", count: 1 }, req: { gold_ingot: 5 } },
      { out: { id: "gold_chestplate", count: 1 }, req: { gold_ingot: 8 } },
      { out: { id: "gold_leggings", count: 1 }, req: { gold_ingot: 7 } },
      { out: { id: "gold_boots", count: 1 }, req: { gold_ingot: 4 } },
      { out: { id: "diamond_pickaxe", count: 1 }, req: { diamond: 3, stick: 2 } },
      { out: { id: "diamond_axe", count: 1 }, req: { diamond: 3, stick: 2 } },
      { out: { id: "diamond_sword", count: 1 }, req: { diamond: 2, stick: 1 } },
      { out: { id: "diamond_helmet", count: 1 }, req: { diamond: 5 } },
      { out: { id: "diamond_chestplate", count: 1 }, req: { diamond: 8 } },
      { out: { id: "iron_leggings", count: 1 }, req: { iron_ingot: 7 } },
      { out: { id: "iron_boots", count: 1 }, req: { iron_ingot: 4 } },
      { out: { id: "diamond_leggings", count: 1 }, req: { diamond: 7 } },
      { out: { id: "diamond_boots", count: 1 }, req: { diamond: 4 } },
      { out: { id: "netherite_scrap", count: 1 }, req: { ancient_debris: 1 } },
      { out: { id: "netherite_ingot", count: 1 }, req: { gold_ingot: 4, netherite_scrap: 4 } },
      { out: { id: "netherite_helmet", count: 1 }, req: { diamond: 1, netherite_ingot: 1 } },
      { out: { id: "netherite_chestplate", count: 1 }, req: { diamond: 1, netherite_ingot: 1 } },
      { out: { id: "netherite_leggings", count: 1 }, req: { diamond: 1, netherite_ingot: 1 } },
      { out: { id: "netherite_boots", count: 1 }, req: { diamond: 1, netherite_ingot: 1 } },
      { out: { id: "netherite_pickaxe", count: 1 }, req: { diamond: 1, netherite_ingot: 1, stick: 2 } },
      { out: { id: "netherite_sword", count: 1 }, req: { diamond: 1, netherite_ingot: 1, stick: 1 } },
      { out: { id: "elytra", count: 1 }, req: { string: 8, leather: 4 } },
      { out: { id: "flint_and_steel", count: 1 }, req: { iron_ingot: 1, [B.GRAVEL]: 1 } },
      { out: { id: "bread", count: 1 }, req: { wheat: 3 } },
      { out: { id: "fishing_rod", count: 1 }, req: { stick: 3, string: 2 } },
      { out: { id: "bucket", count: 1 }, req: { iron_ingot: 3 } },
      { out: { id: "cookie", count: 8 }, req: { wheat: 2, cocoa_beans: 1 } },
      { out: { id: "pumpkin_pie", count: 1 }, req: { pumpkin: 1, sugar: 1, egg: 1 } },
      { out: { id: "golden_carrot", count: 1 }, req: { carrot: 1, gold_ingot: 8 } },
      { out: { id: "mushroom_stew", count: 1 }, req: { red_mushroom: 1, brown_mushroom: 1, bowl: 1 } },
      { out: { id: "beetroot_soup", count: 1 }, req: { beetroot: 6, bowl: 1 } },
      { out: { id: "rabbit_stew", count: 1 }, req: { cooked_rabbit: 1, carrot: 1, potato: 1, mushroom_stew: 1 } },
      { out: { id: "cake", count: 1 }, req: { wheat: 3, sugar: 2, egg: 1, milk_bucket: 3 } },
      { out: { id: B.TNT, count: 4 }, req: { gunpowder: 5, [B.SAND]: 4 } },
      { out: { id: "golden_apple", count: 1 }, req: { apple: 1, gold_ingot: 8 } },
      { out: { id: "bow", count: 1 }, req: { stick: 3, string: 3 } },
      { out: { id: "arrow", count: 4 }, req: { stick: 1, [B.GRAVEL]: 1 } },
      { out: { id: "blaze_powder", count: 2 }, req: { blaze_rod: 1 } },
      { out: { id: "ender_eye", count: 1 }, req: { ender_pearl: 1, blaze_powder: 1 } },
      { out: { id: "paper", count: 3 }, req: { sugar_cane: 3 } },
      { out: { id: "book", count: 1 }, req: { paper: 3, leather: 1 } },
      { out: { id: "compass", count: 1 }, req: { iron_ingot: 4, redstone: 1 } },
      { out: { id: "clock", count: 1 }, req: { gold_ingot: 4, redstone: 1 } },
      { out: { id: "shears", count: 1 }, req: { iron_ingot: 2 } },
      { out: { id: "snowball", count: 4 }, req: { snow_block: 1 } },
      { out: { id: "lead", count: 2 }, req: { string: 4, slime_ball: 1 } }
    ];

    const VILLAGER_PROFESSIONS = {
      fletcher: {
        title: "Житель — Лучник (Fletcher)",
        hatColor: 0x6e5232,
        trades: [
          { give: { id: "stick", count: 16 }, get: { id: "emerald", count: 1 } },
          { give: { id: "emerald", count: 1 }, get: { id: "arrow", count: 16 } },
          { give: { id: "emerald", count: 3 }, get: { id: "bow", count: 1 } },
          { give: { id: "emerald", count: 5 }, get: { id: "shield", count: 1 } }
        ]
      },
      farmer: {
        title: "Житель — Фермер",
        hatColor: 0xb59c45,
        trades: [
          { give: { id: "wheat", count: 12 }, get: { id: "emerald", count: 1 } },
          { give: { id: "emerald", count: 1 }, get: { id: "bread", count: 6 } },
          { give: { id: "emerald", count: 1 }, get: { id: "apple", count: 4 } }
        ]
      },
      blacksmith: {
        title: "Житель — Оружейник",
        hatColor: 0x3b3b3b,
        trades: [
          { give: { id: "coal", count: 10 }, get: { id: "emerald", count: 1 } },
          { give: { id: "iron_ingot", count: 4 }, get: { id: "emerald", count: 1 } },
          { give: { id: "emerald", count: 6 }, get: { id: "iron_sword", count: 1 } },
          { give: { id: "emerald", count: 12 }, get: { id: "diamond_pickaxe", count: 1 } }
        ]
      },
      cleric: {
        title: "Житель — Священник",
        hatColor: 0x5c2e78,
        trades: [
          { give: { id: "gold_ingot", count: 3 }, get: { id: "emerald", count: 1 } },
          { give: { id: "emerald", count: 5 }, get: { id: "ender_pearl", count: 1 } },
          { give: { id: "emerald", count: 2 }, get: { id: "redstone", count: 4 } }
        ]
      }
    };

    const SMELT_MAP = {
      [B.IRON_ORE]: "iron_ingot",
      [B.GOLD_ORE]: "gold_ingot",
      [B.ANCIENT_DEBRIS]: "netherite_scrap",
      [B.NETHER_GOLD_ORE]: "gold_ingot",
      raw_chicken: "cooked_chicken",
      potato: "baked_potato",
      [B.COBBLESTONE]: B.STONE,
      [B.SAND]: B.GLASS,
      raw_beef: "cooked_beef",
      porkchop: "cooked_porkchop",
      raw_porkchop: "cooked_porkchop",
      mutton: "cooked_mutton",
      raw_mutton: "cooked_mutton",
      rabbit: "cooked_rabbit",
      raw_rabbit: "cooked_rabbit",
      raw_fish: "cooked_fish",
      raw_salmon: "cooked_salmon"
    };

    // =========================================================================
    // 5. THREE.JS SCENE, SKY, LIGHTING & CAMERA
    // =========================================================================
    const canvas = document.getElementById("game-canvas");
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 0.85));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.shadowMap.enabled = false;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x88aae0);
    scene.fog = new THREE.Fog(0x88aae0, 90000, 100000);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 560);
    camera.rotation.order = "YXZ";
    camera.rotation.z = 0;

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.72);
    const skyLight = new THREE.HemisphereLight(0xdceaff, 0x65533b, 0.34);
    scene.add(ambientLight, skyLight);

    const sunLight = new THREE.DirectionalLight(0xfff1d8, 1.05);
    sunLight.position.set(40, 80, 30);
    sunLight.castShadow = false;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.bias = -0.00018;
    sunLight.shadow.normalBias = 0.025;
    sunLight.shadow.camera.near = 5;
    sunLight.shadow.camera.far = 160;
    const d = 38;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    scene.add(sunLight);
    scene.add(sunLight.target);

    const sunMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(10, 10),
      new THREE.MeshBasicMaterial({ color: 0xf0e6a8, side: THREE.DoubleSide, fog: false })
    );
    const moonMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(8, 8),
      new THREE.MeshBasicMaterial({ color: 0xcbd4e8, side: THREE.DoubleSide, fog: false })
    );
    scene.add(sunMesh, moonMesh);

    const cloudGroup = new THREE.Group();
    const cloudMat = new THREE.MeshLambertMaterial({ color: 0xf2f4f4, transparent: true, opacity: 0.92 });
    const cloudShadeMat = new THREE.MeshLambertMaterial({ color: 0xd9e0e5, transparent: true, opacity: 0.82 });
    for (let i = 0; i < 18; i++) {
      const cloud = new THREE.Group();
      const width = 7 + (i % 3) * 2;
      const depth = 4 + (i % 2) * 2;
      const pieces = [
        [0, 0, 0, width, 1.15, depth],
        [-width * 0.28, 0.48, 0, width * 0.48, 1.0, depth * 0.82],
        [width * 0.22, 0.35, 0, width * 0.52, 0.9, depth * 0.78],
        [0, 0.72, -depth * 0.12, width * 0.42, 0.7, depth * 0.6]
      ];
      pieces.forEach(([x,y,z,w,h,d], index) => {
        const puff = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), index === 0 ? cloudShadeMat : cloudMat);
        puff.position.set(x,y,z);
        cloud.add(puff);
      });
      cloud.position.set((i - 9) * 14, 62 + (i % 3) * 0.6, ((i * 19) % 120) - 60);
      cloudGroup.add(cloud);
    }
    scene.add(cloudGroup);

    // First-Person Viewmodels: Main Hand (Right) + Off-Hand (Left) + 3D Shield
    const fpGroup = new THREE.Group();
    camera.add(fpGroup);
    scene.add(camera);

    const fpArm = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.58, 0.22), new THREE.MeshLambertMaterial({ color: 0xb58665 }));
    fpArm.position.set(0.50, -0.49, -0.64);
    fpArm.rotation.set(0.12, -0.22, -0.12);
    fpGroup.add(fpArm);
    const fpHand = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.20, 0.22), new THREE.MeshLambertMaterial({ color: 0xc99a78 }));
    fpHand.position.set(0.49, -0.77, -0.72);
    fpHand.rotation.set(0.12, -0.22, -0.12);
    fpGroup.add(fpHand);

    const fpBlock = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.32, 0.32), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    fpBlock.position.set(0.48, -0.38, -0.78);
    fpBlock.visible = false;
    fpGroup.add(fpBlock);

    const fpItemSprite = new THREE.Mesh(
      new THREE.PlaneGeometry(0.44, 0.44),
      new THREE.MeshBasicMaterial({ transparent: true, alphaTest: 0.4, side: THREE.DoubleSide })
    );
    fpItemSprite.position.set(0.45, -0.32, -0.72);
    fpItemSprite.rotation.set(0.1, -0.4, 0.15);
    fpItemSprite.visible = false;
    fpGroup.add(fpItemSprite);

    function create3DShieldMesh() {
      const g = new THREE.Group();
      const board = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.56, 0.05), new THREE.MeshLambertMaterial({ color: 0x7d5d38 }));
      const rim = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(0.35, 0.57, 0.06)), new THREE.LineBasicMaterial({ color: 0x9c9c9c }));
      const boss = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.07), new THREE.MeshLambertMaterial({ color: 0x9c9c9c }));
      g.add(board, rim, boss);
      return g;
    }

    const fpMainShield = create3DShieldMesh();
    fpMainShield.visible = false;
    fpGroup.add(fpMainShield);

    // Off-Hand Viewmodels (Left side)
    const fpOffBlock = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.26, 0.26), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    fpOffBlock.position.set(-0.48, -0.4, -0.76);
    fpOffBlock.visible = false;
    fpGroup.add(fpOffBlock);

    const fpOffSprite = new THREE.Mesh(
      new THREE.PlaneGeometry(0.36, 0.36),
      new THREE.MeshBasicMaterial({ transparent: true, alphaTest: 0.4, side: THREE.DoubleSide })
    );
    fpOffSprite.position.set(-0.46, -0.36, -0.72);
    fpOffSprite.visible = false;
    fpGroup.add(fpOffSprite);

    const fpOffShield = create3DShieldMesh();
    fpOffShield.visible = false;
    fpGroup.add(fpOffShield);

    // Block Selection Wireframe & Break Cracks
    const highlightBox = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(1.006, 1.006, 1.006)),
      new THREE.LineBasicMaterial({ color: 0x1a1a1a })
    );
    highlightBox.visible = false;
    scene.add(highlightBox);

    const crackCanvas = document.createElement("canvas");
    crackCanvas.width = 16; crackCanvas.height = 16;
    const crackCtx = crackCanvas.getContext("2d");
    const crackTex = new THREE.CanvasTexture(crackCanvas);
    crackTex.magFilter = THREE.NearestFilter;
    const crackMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.01, 1.01, 1.01),
      new THREE.MeshBasicMaterial({ map: crackTex, transparent: true, depthWrite: false })
    );
    crackMesh.visible = false;
    scene.add(crackMesh);

    const crackStageMaterials = new Array(11).fill(null);
    const crackFallbackMaterial = crackMesh.material;
    function updateCrackStage(stage) {
      if (stage <= 0) { crackMesh.visible = false; return; }
      crackMesh.visible = true;
      const stageMaterial = crackStageMaterials[stage];
      if (stageMaterial) {
        crackMesh.material = stageMaterial;
        return;
      }
      crackMesh.material = crackFallbackMaterial;
      crackCtx.clearRect(0, 0, 16, 16);
      crackCtx.fillStyle = "rgba(18,18,18,0.72)";
      for (let i = 0; i < stage * 5; i++) {
        const x = (i * 7 + stage * 3) % 14 + 1;
        const y = (i * 11 + stage * 5) % 14 + 1;
        crackCtx.fillRect(x, y, 1, 2);
      }
      crackTex.needsUpdate = true;
    }

    // Pooled Particles & Projectiles
    const breakParticles = [];
    function spawnParticles(bx, by, bz, colorOrBlockId, count = 8) {
      let useMat = null;
      if (typeof colorOrBlockId === "number") {
        const m = ATLAS.materials[colorOrBlockId];
        useMat = Array.isArray(m) ? m[2] : m;
      } else {
        useMat = new THREE.MeshBasicMaterial({ color: colorOrBlockId });
      }
      if (!useMat) return;
      for (let i = 0; i < count; i++) {
        const pm = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.14), useMat);
        pm.position.set(bx + (Math.random() - 0.5) * 0.6, by + (Math.random() - 0.5) * 0.6, bz + (Math.random() - 0.5) * 0.6);
        scene.add(pm);
        breakParticles.push({
          mesh: pm,
          vel: new THREE.Vector3((Math.random() - 0.5) * 3.5, 1.4 + Math.random() * 2.4, (Math.random() - 0.5) * 3.5),
          life: 0.45
        });
      }
    }

    // =========================================================================
    // 6. VOXEL WORLD GENERATOR (STRUCTURES, STRONGHOLD <=500 BLOCKS, PORTALS)
    // =========================================================================
    const CHUNK_SIZE = 16;
    const WORLD_HEIGHT = 64;

    function hash2(x, z, seed) {
      let n = Math.sin(x * 127.1 + z * 311.7 + seed * 74.7) * 43758.5453123;
      return n - Math.floor(n);
    }

    function valueNoise2D(x, z, seed) {
      const ix = Math.floor(x), iz = Math.floor(z);
      const fx = x - ix, fz = z - iz;
      const ux = fx * fx * (3 - 2 * fx);
      const uz = fz * fz * (3 - 2 * fz);
      const a = hash2(ix, iz, seed);
      const b = hash2(ix + 1, iz, seed);
      const c = hash2(ix, iz + 1, seed);
      const d = hash2(ix + 1, iz + 1, seed);
      return a + (b - a) * ux + (c - a) * uz + (a - b - c + d) * ux * uz;
    }

    function fbm2D(x, z, seed) {
      return valueNoise2D(x * 0.03, z * 0.03, seed) * 0.65 +
             valueNoise2D(x * 0.08, z * 0.08, seed + 17) * 0.35;
    }

    class VoxelWorld {
      constructor(seed) {
        this.seed = seed;
        this.dimension = "overworld";
        this.chunks = new Map();
        this.meshes = new Map();
        this.meshQueue = [];
        this.meshQueueSet = new Set();
        this.modifications = { overworld: new Map(), nether: new Map(), end: new Map() };
        this.chests = new Map();
        this.generatedRegions = new Set();

        // Guaranteed Underground Stronghold strictly within 320..480 blocks of spawn (0,0)
        const shAngle = (seed % 360) * (Math.PI / 180);
        const shDist = 340 + (seed % 130); // 340..470 blocks
        this.structures = {
          stronghold: {
            x: Math.round(Math.cos(shAngle) * shDist),
            y: 18,
            z: Math.round(Math.sin(shAngle) * shDist)
          },
          villages: [],
          pyramids: [],
          ruinedPortals: [],
          biomeStructures: []
        };
      }

      chunkKey(cx, cz) { return `${this.dimension}:${cx},${cz}`; }

      getBiome(x, z) {
        if (this.dimension === "nether") return "Пустоши Нижнего мира";
        if (this.dimension === "end") return "Край";
        const climate = valueNoise2D(x * 0.006, z * 0.006, this.seed + 99);
        const detail = valueNoise2D(x * 0.021, z * 0.021, this.seed + 177);
        const wet = valueNoise2D(x * 0.009, z * 0.009, this.seed + 291);
        if (climate < 0.16) return detail > 0.48 ? "Ледяные пики" : "Снежная тайга";
        if (climate < 0.29) return wet < 0.42 ? "Пустыня" : "Бесплодные земли";
        if (climate < 0.43) return wet > 0.58 ? "Болото" : "Саванна";
        if (climate < 0.57) return detail > 0.5 ? "Джунгли" : "Берёзовый лес";
        if (climate < 0.72) return wet < 0.38 ? "Тёмный лес" : "Равнины";
        if (climate < 0.86) return wet > 0.62 ? "Тропический берег" : "Тайга";
        return "Дубовый лес";
      }

      getSurfaceHeight(x, z) {
        if (this.dimension === "nether") return 28;
        if (this.dimension === "end") return Math.hypot(x, z) < 34 ? 32 : -1;
        return Math.floor(24 + fbm2D(x, z, this.seed) * 14);
      }

      generateChunkData(cx, cz) {
        const data = new Uint8Array(CHUNK_SIZE * WORLD_HEIGHT * CHUNK_SIZE);
        const setLocal = (lx, y, lz, id) => {
          if (lx < 0 || lx >= CHUNK_SIZE || y < 0 || y >= WORLD_HEIGHT || lz < 0 || lz >= CHUNK_SIZE) return;
          data[lx + lz * CHUNK_SIZE + y * CHUNK_SIZE * CHUNK_SIZE] = id;
        };

        for (let lx = 0; lx < CHUNK_SIZE; lx++) {
          for (let lz = 0; lz < CHUNK_SIZE; lz++) {
            const wx = cx * CHUNK_SIZE + lx;
            const wz = cz * CHUNK_SIZE + lz;

            if (this.dimension === "overworld") {
              const h = this.getSurfaceHeight(wx, wz);
              const biome = this.getBiome(wx, wz);
              setLocal(lx, 0, lz, B.BEDROCK);

              for (let y = 1; y <= h; y++) {
                const cave = valueNoise2D(wx * 0.09 + y * 0.13, wz * 0.09 - y * 0.11, this.seed + 31);
                if (y < h - 3 && y > 2 && cave > 0.78) {
                  setLocal(lx, y, lz, y < 7 ? B.LAVA : B.AIR);
                  continue;
                }
                const sandyBiome = biome === "Пустыня" || biome === "Бесплодные земли" || biome === "Тропический берег";
                const snowyBiome = biome === "Ледяные пики" || biome === "Снежная тайга";
                if (y === h) setLocal(lx, y, lz, sandyBiome ? B.SAND : (snowyBiome ? (B.SNOW_BLOCK || B.GRASS) : B.GRASS));
                else if (y >= h - 3) setLocal(lx, y, lz, sandyBiome ? B.SAND : B.DIRT);
                else {
                  const r = hash2(wx * 13 + y, wz * 17 - y, this.seed);
                  if (y < 14 && r < 0.012) setLocal(lx, y, lz, B.DIAMOND_ORE);
                  else if (y < 16 && r < 0.026) setLocal(lx, y, lz, B.REDSTONE_ORE);
                  else if (y < 24 && r < 0.042) setLocal(lx, y, lz, B.GOLD_ORE);
                  else if (y < 26 && r < 0.055) setLocal(lx, y, lz, B.LAPIS_ORE);
                  else if (y < 34 && r < 0.095) setLocal(lx, y, lz, B.IRON_ORE);
                  else if (r < 0.15) setLocal(lx, y, lz, B.COAL_ORE);
                  else setLocal(lx, y, lz, B.STONE);
                }
              }

              for (let y = h + 1; y <= 26; y++) setLocal(lx, y, lz, B.WATER);

              if (h >= 27 && !["Пустыня","Бесплодные земли","Ледяные пики","Саванна"].includes(biome)) {
                const treeNoise = hash2(wx, wz, this.seed + 55);
                const dense = ["Дубовый лес","Тёмный лес","Джунгли","Тайга","Берёзовый лес","Снежная тайга"].includes(biome);
                const treeChance = dense ? (biome === "Джунгли" || biome === "Тёмный лес" ? 0.052 : 0.034) : 0.009;
                if (lx >= 2 && lx <= 13 && lz >= 2 && lz <= 13 && treeNoise < treeChance) {
                  const jungle = biome === "Джунгли";
                  const spruce = biome === "Тайга" || biome === "Снежная тайга";
                  const birch = biome === "Берёзовый лес";
                  const logId = jungle ? (B.JUNGLE_LOG || B.OAK_LOG) : spruce ? (B.SPRUCE_LOG || B.OAK_LOG) : birch ? (B.BIRCH_LOG || B.OAK_LOG) : B.OAK_LOG;
                  const leafId = jungle ? (B.JUNGLE_LEAVES || B.OAK_LEAVES) : spruce ? (B.SPRUCE_LEAVES || B.OAK_LEAVES) : birch ? (B.BIRCH_LEAVES || B.OAK_LEAVES) : B.OAK_LEAVES;
                  const trunkH = (jungle ? 7 : spruce ? 6 : 4) + Math.floor(hash2(wx, wz, 7) * 3);
                  for (let ty = 1; ty <= trunkH; ty++) setLocal(lx, h + ty, lz, logId);
                  const canopy = jungle ? 3 : 2;
                  for (let dx = -canopy; dx <= canopy; dx++) for (let dz = -canopy; dz <= canopy; dz++) {
                    for (let dy = trunkH - 1; dy <= trunkH + 1; dy++) {
                      if (Math.abs(dx) === canopy && Math.abs(dz) === canopy && dy === trunkH + 1) continue;
                      if (dx === 0 && dz === 0 && dy <= trunkH) continue;
                      setLocal(lx + dx, h + dy, lz + dz, leafId);
                    }
                  }
                } else if (treeNoise > 0.94) setLocal(lx, h + 1, lz, treeNoise > 0.97 ? B.POPPY : B.DANDELION);
              }
            } else if (this.dimension === "nether") {
              setLocal(lx, 0, lz, B.BEDROCK);
              setLocal(lx, 46, lz, B.BEDROCK);
              const floorH = Math.floor(14 + fbm2D(wx, wz, this.seed + 3) * 14);
              for (let y = 1; y <= floorH; y++) {
                const r = hash2(wx * 11 + y, wz * 19, this.seed);
                const oreRoll = hash2(wx * 31 + y * 7, wz * 17 - y, this.seed + 712);
                if (y >= 5 && y <= 22 && oreRoll < 0.0018) setLocal(lx, y, lz, B.ANCIENT_DEBRIS);
                else if (y < floorH && r < 0.04) setLocal(lx, y, lz, B.QUARTZ_ORE);
                else if (y < floorH && oreRoll < 0.010) setLocal(lx, y, lz, B.NETHER_GOLD_ORE);
                else if (y === floorH && floorH < 18 && hash2(wx, wz, this.seed + 81) < 0.45) setLocal(lx, y, lz, B.SOUL_SOIL);
                else setLocal(lx, y, lz, (y === floorH && floorH < 18) ? B.SOUL_SAND : B.NETHERRACK);
              }
              if (hash2(wx, wz, this.seed + 991) < 0.018) setLocal(lx, floorH, lz, B.BASALT);
              if (hash2(wx, wz, this.seed + 992) < 0.012) setLocal(lx, floorH, lz, B.BLACKSTONE);
              for (let y = floorH + 1; y <= 16; y++) setLocal(lx, y, lz, B.LAVA);
              for (let y = 38; y < 46; y++) setLocal(lx, y, lz, B.NETHERRACK);
              if (hash2(wx, wz, 404) < 0.025) setLocal(lx, 37, lz, B.GLOWSTONE);
            } else if (this.dimension === "end") {
              const dist = Math.hypot(wx, wz);
              const islandNoise = hash2(Math.floor(wx / 6), Math.floor(wz / 6), this.seed + 1907);
              const onMainIsland = dist < 34;
              const onOuterIsland = dist > 48 && dist < 155 && islandNoise > 0.28;
              if (onMainIsland || onOuterIsland) {
                const localDist = onMainIsland ? dist : Math.hypot((wx % 38) - 19, (wz % 38) - 19);
                const topY = 32 - Math.floor(Math.min(localDist, 32) * 0.12);
                const botY = 22 + Math.floor(Math.min(localDist, 32) * 0.25);
                for (let y = botY; y <= topY; y++) setLocal(lx, y, lz, B.END_STONE);
              }
            }
          }
        }

        const mods = this.modifications[this.dimension];
        for (let lx = 0; lx < CHUNK_SIZE; lx++) {
          for (let lz = 0; lz < CHUNK_SIZE; lz++) {
            const wx = cx * CHUNK_SIZE + lx;
            const wz = cz * CHUNK_SIZE + lz;
            for (let y = 0; y < WORLD_HEIGHT; y++) {
              const key = `${wx},${y},${wz}`;
              if (mods.has(key)) setLocal(lx, y, lz, mods.get(key));
            }
          }
        }
        return data;
      }

      getChunk(cx, cz) {
        const key = this.chunkKey(cx, cz);
        if (!this.chunks.has(key)) this.chunks.set(key, this.generateChunkData(cx, cz));
        return this.chunks.get(key);
      }

      getBlock(x, y, z) {
        const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
        if (iy < 0 || iy >= WORLD_HEIGHT) return B.AIR;
        const cx = Math.floor(ix / CHUNK_SIZE);
        const cz = Math.floor(iz / CHUNK_SIZE);
        const lx = ((ix % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const lz = ((iz % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const chunk = this.getChunk(cx, cz);
        return chunk[lx + lz * CHUNK_SIZE + iy * CHUNK_SIZE * CHUNK_SIZE];
      }

      enqueueChunkRebuild(cx, cz, priority = false) {
        const key = this.chunkKey(cx, cz);
        if (this.meshQueueSet.has(key)) return;
        this.meshQueueSet.add(key);
        if (priority) this.meshQueue.unshift({ cx, cz, key });
        else this.meshQueue.push({ cx, cz, key });
      }

      setBlock(x, y, z, id, broadcast = false) {
        const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
        if (iy < 0 || iy >= WORLD_HEIGHT) return;
        const cx = Math.floor(ix / CHUNK_SIZE);
        const cz = Math.floor(iz / CHUNK_SIZE);
        const lx = ((ix % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const lz = ((iz % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const chunk = this.getChunk(cx, cz);
        chunk[lx + lz * CHUNK_SIZE + iy * CHUNK_SIZE * CHUNK_SIZE] = id;
        this.modifications[this.dimension].set(`${ix},${iy},${iz}`, id);

        if (broadcast && MP.active && fbDb && MP.roomId) {
          push(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/blocks`), {
            dim: this.dimension, x: ix, y: iy, z: iz, id, by: MP.playerId
          });
        }

        // Immediate rebuild for direct player/local changes
        this.rebuildChunkMesh(cx, cz);
        if (lx === 0) this.rebuildChunkMesh(cx - 1, cz);
        if (lx === CHUNK_SIZE - 1) this.rebuildChunkMesh(cx + 1, cz);
        if (lz === 0) this.rebuildChunkMesh(cx, cz - 1);
        if (lz === CHUNK_SIZE - 1) this.rebuildChunkMesh(cx, cz + 1);
      }

      // Silent block write during structure generation (rebuilds once at the end)
      setBlockRaw(x, y, z, id) {
        const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
        if (iy < 0 || iy >= WORLD_HEIGHT) return;
        const cx = Math.floor(ix / CHUNK_SIZE);
        const cz = Math.floor(iz / CHUNK_SIZE);
        const lx = ((ix % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const lz = ((iz % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const chunk = this.getChunk(cx, cz);
        chunk[lx + lz * CHUNK_SIZE + iy * CHUNK_SIZE * CHUNK_SIZE] = id;
        this.modifications[this.dimension].set(`${ix},${iy},${iz}`, id);
      }

      // Build a full Village with houses, farms, Fletcher & Blacksmith Villagers
      buildVillageAt(vx, vz, biome = this.getBiome(vx, vz)) {
        const vy = Math.max(27, this.getSurfaceHeight(vx, vz));
        const villagePlanks = biome === "Тайга" || biome === "Снежная тайга" ? (B.SPRUCE_PLANKS || B.OAK_PLANKS) :
          biome === "Джунгли" ? (B.JUNGLE_PLANKS || B.OAK_PLANKS) :
          biome === "Саванна" ? (B.ACACIA_PLANKS || B.OAK_PLANKS) :
          biome === "Тёмный лес" ? (B.DARK_OAK_PLANKS || B.OAK_PLANKS) : B.OAK_PLANKS;
        const villageLog = biome === "Тайга" || biome === "Снежная тайга" ? (B.SPRUCE_LOG || B.OAK_LOG) :
          biome === "Джунгли" ? (B.JUNGLE_LOG || B.OAK_LOG) :
          biome === "Саванна" ? (B.ACACIA_LOG || B.OAK_LOG) : B.OAK_LOG;
        const villageBase = biome === "Пустыня" || biome === "Бесплодные земли" ? (B.SANDSTONE || B.COBBLESTONE) :
          biome === "Снежная тайга" || biome === "Ледяные пики" ? (B.SNOW_BLOCK || B.COBBLESTONE) :
          biome === "Джунгли" || biome === "Болото" ? (B.MOSSY_COBBLESTONE || B.COBBLESTONE) : B.COBBLESTONE;
        this.structures.villages.push({ x: vx, y: vy, z: vz, biome });

        // House 1: biome-themed blacksmith / Fletcher workshop
        for (let dx = -4; dx <= 4; dx++) {
          for (let dz = -4; dz <= 4; dz++) {
            this.setBlockRaw(vx + dx, vy, vz + dz, villageBase);
            for (let dy = 1; dy <= 4; dy++) this.setBlockRaw(vx + dx, vy + dy, vz + dz, B.AIR);
          }
        }
        for (let dx = -3; dx <= 3; dx++) {
          for (let dz = -3; dz <= 3; dz++) {
            this.setBlockRaw(vx + dx, vy + 4, vz + dz, villagePlanks);
            if (Math.abs(dx) === 3 || Math.abs(dz) === 3) {
              for (let dy = 1; dy <= 3; dy++) this.setBlockRaw(vx + dx, vy + dy, vz + dz, villageBase);
            }
          }
        }
        this.setBlockRaw(vx, vy + 1, vz - 3, B.AIR);
        this.setBlockRaw(vx, vy + 2, vz - 3, B.AIR);
        this.setBlockRaw(vx + 2, vy + 1, vz + 2, B.FURNACE);
        this.setBlockRaw(vx - 2, vy + 1, vz + 2, B.CRAFTING_TABLE);
        this.setBlockRaw(vx, vy + 1, vz + 2, B.CHEST);

        const vChest = new Array(27).fill(null);
        vChest[0] = { id: "emerald", count: 4 };
        vChest[1] = { id: "iron_ingot", count: 5 };
        vChest[2] = { id: "bread", count: 6 };
        vChest[3] = { id: "stick", count: 16 };
        vChest[4] = { id: "carrot", count: 3 };
        vChest[5] = { id: "potato", count: 4 };
        vChest[6] = { id: "beetroot", count: 3 };
        vChest[7] = { id: "melon_slice", count: 4 };
        vChest[8] = { id: "pumpkin", count: 2 };
        vChest[9] = { id: "egg", count: 3 };
        vChest[10] = { id: "red_mushroom", count: 2 };
        vChest[11] = { id: "brown_mushroom", count: 2 };
        vChest[12] = { id: "sugar", count: 3 };
        vChest[13] = { id: "bowl", count: 2 };
        vChest[14] = { id: "cocoa_beans", count: 3 };
        vChest[15] = { id: "melon", count: 2 };
        this.chests.set(`overworld:${vx},${vy + 1},${vz + 2}`, vChest);

        // House 2: Oak Cottage
        const hx = vx - 10, hz = vz + 2;
        const hy = Math.max(27, this.getSurfaceHeight(hx, hz));
        for (let dx = -3; dx <= 3; dx++) {
          for (let dz = -3; dz <= 3; dz++) {
            this.setBlockRaw(hx + dx, hy, hz + dz, villageBase);
            for (let dy = 1; dy <= 4; dy++) this.setBlockRaw(hx + dx, hy + dy, hz + dz, B.AIR);
            this.setBlockRaw(hx + dx, hy + 4, hz + dz, villageLog);
            if (Math.abs(dx) === 3 || Math.abs(dz) === 3) {
              for (let dy = 1; dy <= 3; dy++) this.setBlockRaw(hx + dx, hy + dy, hz + dz, villagePlanks);
            }
          }
        }
        this.setBlockRaw(hx, hy + 1, hz - 3, B.AIR);
        this.setBlockRaw(hx, hy + 2, hz - 3, B.AIR);
        this.setBlockRaw(hx + 1, hy + 1, hz + 1, B.BED_FOOT);
        this.setBlockRaw(hx + 1, hy + 1, hz + 2, B.BED_HEAD);

        // Wheat Farm
        for (let fx = 0; fx < 5; fx++) {
          for (let fz = 0; fz < 4; fz++) {
            this.setBlockRaw(vx + 6 + fx, vy, vz + fz, fx === 2 ? B.WATER : B.FARMLAND);
            if (fx !== 2) this.setBlockRaw(vx + 6 + fx, vy + 1, vz + fz, B.WHEAT_7);
          }
        }
      }

      // Build Desert Pyramid with Underground Treasure Chamber & 4 Chests
      buildPyramidAt(px, pz) {
        const py = Math.max(27, this.getSurfaceHeight(px, pz));
        this.structures.pyramids.push({ x: px, y: py, z: pz });

        for (let level = 0; level <= 7; level++) {
          const r = 7 - level;
          for (let dx = -r; dx <= r; dx++) {
            for (let dz = -r; dz <= r; dz++) {
              const isShell = Math.abs(dx) === r || Math.abs(dz) === r || level === 7;
              this.setBlockRaw(px + dx, py + level, pz + dz, isShell ? B.SANDSTONE : B.AIR);
            }
          }
        }
        // Entrance
        this.setBlockRaw(px, py + 1, pz - 7, B.AIR);
        this.setBlockRaw(px, py + 2, pz - 7, B.AIR);
        this.setBlockRaw(px, py + 1, pz - 6, B.AIR);
        this.setBlockRaw(px, py + 2, pz - 6, B.AIR);

        // Secret Treasure Pit below center
        for (let y = py - 6; y < py; y++) {
          for (let dx = -2; dx <= 2; dx++) {
            for (let dz = -2; dz <= 2; dz++) {
              const wall = Math.abs(dx) === 2 || Math.abs(dz) === 2 || y === py - 6;
              this.setBlockRaw(px + dx, y, pz + dz, wall ? B.SANDSTONE : B.AIR);
            }
          }
        }
        const chestOffsets = [[-1, 0], [1, 0], [0, -1], [0, 1]];
        chestOffsets.forEach(([ox, oz], idx) => {
          this.setBlockRaw(px + ox, py - 5, pz + oz, B.CHEST);
          const loot = new Array(27).fill(null);
          loot[0] = { id: "diamond", count: 1 + (idx % 2) };
          loot[1] = { id: "emerald", count: 2 + idx };
          loot[2] = { id: "gold_ingot", count: 4 };
          loot[3] = { id: "ender_pearl", count: 1 };
          if (idx === 1) loot[5] = { id: "enchanted_golden_apple", count: 1 };
          if (idx === 0) loot[4] = { id: "golden_apple", count: 1 };
          this.chests.set(`overworld:${px + ox},${py - 5},${pz + oz}`, loot);
        });
      }

      // Build Ruined Nether Portal
      buildRuinedPortalAt(rx, rz) {
        const ry = Math.max(27, this.getSurfaceHeight(rx, rz));
        this.structures.ruinedPortals.push({ x: rx, y: ry, z: rz });
        for (let dx = -2; dx <= 2; dx++) {
          for (let dz = -2; dz <= 2; dz++) {
            this.setBlockRaw(rx + dx, ry, rz + dz, (dx + dz) % 2 === 0 ? B.NETHERRACK : B.STONE_BRICKS);
          }
        }
        for (let dy = 1; dy <= 4; dy++) {
          this.setBlockRaw(rx - 1, ry + dy, rz, dy === 3 ? B.CRYING_OBSIDIAN : B.OBSIDIAN);
          if (dy <= 3) this.setBlockRaw(rx + 2, ry + dy, rz, B.OBSIDIAN);
        }
        this.setBlockRaw(rx, ry + 5, rz, B.GOLD_BLOCK);
        this.setBlockRaw(rx - 2, ry + 1, rz + 1, B.CHEST);
        const loot = new Array(27).fill(null);
        loot[0] = { id: B.OBSIDIAN, count: 4 };
        loot[1] = { id: "flint_and_steel", count: 1 };
        loot[2] = { id: "gold_ingot", count: 3 };
        this.chests.set(`overworld:${rx - 2},${ry + 1},${rz + 1}`, loot);
      }

      // Build Multi-Room Underground Stronghold with End Portal Room!
      buildStronghold() {
        const { x: sx, y: sy, z: sz } = this.structures.stronghold;

        // 1. Portal Room (11x6x11)
        for (let dx = -5; dx <= 5; dx++) {
          for (let dz = -5; dz <= 5; dz++) {
            for (let dy = -1; dy <= 5; dy++) {
              const isShell = Math.abs(dx) === 5 || Math.abs(dz) === 5 || dy === -1 || dy === 5;
              this.setBlockRaw(sx + dx, sy + dy, sz + dz, isShell ? B.STONE_BRICKS : B.AIR);
            }
          }
        }
        this.setBlockRaw(sx + 4, sy + 1, sz + 4, B.TORCH);
        this.setBlockRaw(sx - 4, sy + 1, sz - 4, B.TORCH);
        this.setBlockRaw(sx + 4, sy + 1, sz - 4, B.TORCH);
        this.setBlockRaw(sx - 4, sy + 1, sz + 4, B.TORCH);

        // Lava pool beneath End Portal
        for (let dx = -1; dx <= 1; dx++) {
          for (let dz = -1; dz <= 1; dz++) this.setBlockRaw(sx + dx, sy, sz + dz, B.LAVA);
        }

        // 12-Block End Portal Frame Ring (2 pre-filled with Eyes, 10 empty)
        let frameIdx = 0;
        for (let i = -1; i <= 1; i++) {
          this.setBlockRaw(sx + i, sy + 1, sz - 2, frameIdx++ < 2 ? B.END_PORTAL_FRAME_EYE : B.END_PORTAL_FRAME);
          this.setBlockRaw(sx + i, sy + 1, sz + 2, B.END_PORTAL_FRAME);
          this.setBlockRaw(sx - 2, sy + 1, sz + i, B.END_PORTAL_FRAME);
          this.setBlockRaw(sx + 2, sy + 1, sz + i, B.END_PORTAL_FRAME);
        }

        // 2. Corridor + Library Room (to the North: sz - 12)
        for (let dz = -9; dz <= -5; dz++) {
          for (let dx = -1; dx <= 1; dx++) {
            for (let dy = 0; dy <= 3; dy++) {
              const wall = Math.abs(dx) === 1 || dy === 0 || dy === 3;
              this.setBlockRaw(sx + dx, sy + dy, sz + dz, wall ? B.STONE_BRICKS : B.AIR);
            }
          }
        }
        const lz = sz - 14;
        for (let dx = -4; dx <= 4; dx++) {
          for (let dz = -4; dz <= 4; dz++) {
            for (let dy = 0; dy <= 4; dy++) {
              const wall = Math.abs(dx) === 4 || Math.abs(dz) === 4 || dy === 0 || dy === 4;
              this.setBlockRaw(sx + dx, sy + dy, lz + dz, wall ? B.STONE_BRICKS : B.AIR);
            }
          }
        }
        this.setBlockRaw(sx, sy + 1, lz + 4, B.AIR);
        this.setBlockRaw(sx, sy + 2, lz + 4, B.AIR);
        for (let dx = -3; dx <= 3; dx += 2) {
          this.setBlockRaw(sx + dx, sy + 1, lz - 3, B.BOOKSHELF);
          this.setBlockRaw(sx + dx, sy + 2, lz - 3, B.BOOKSHELF);
        }
        this.setBlockRaw(sx, sy + 1, lz - 2, B.CHEST);
        const libLoot = new Array(27).fill(null);
        libLoot[0] = { id: "ender_eye", count: 3 };
        libLoot[1] = { id: "diamond", count: 3 };
        libLoot[2] = { id: "emerald", count: 5 };
        this.chests.set(`overworld:${sx},${sy + 1},${lz - 2}`, libLoot);

        // 3. Surface Stone Brick Tower Beacon above Stronghold so players can also spot it
        const surfY = this.getSurfaceHeight(sx, sz);
        for (let y = sy + 5; y <= surfY + 3; y++) {
          for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
              const isLadderShaft = dx === 0 && dz === 0;
              this.setBlockRaw(sx + dx, y, sz + dz, isLadderShaft ? B.AIR : B.STONE_BRICKS);
            }
          }
        }
      }

      // Check and activate 3x3 End Portal ring anywhere in the world!
      checkAndActivateEndPortalAround(bx, by, bz) {
        // Test all possible 3x3 centers within 2 blocks of (bx, bz)
        for (let cx = bx - 2; cx <= bx + 2; cx++) {
          for (let cz = bz - 2; cz <= bz + 2; cz++) {
            let all12Filled = true;
            for (let i = -1; i <= 1; i++) {
              if (this.getBlock(cx + i, by, cz - 2) !== B.END_PORTAL_FRAME_EYE) all12Filled = false;
              if (this.getBlock(cx + i, by, cz + 2) !== B.END_PORTAL_FRAME_EYE) all12Filled = false;
              if (this.getBlock(cx - 2, by, cz + i) !== B.END_PORTAL_FRAME_EYE) all12Filled = false;
              if (this.getBlock(cx + 2, by, cz + i) !== B.END_PORTAL_FRAME_EYE) all12Filled = false;
            }
            if (all12Filled) {
              for (let dx = -1; dx <= 1; dx++) {
                for (let dz = -1; dz <= 1; dz++) {
                  this.setBlock(cx + dx, by, cz + dz, B.END_PORTAL, true);
                }
              }
              SFX.levelUp();
              showBanner("ПОРТАЛ В КРАЙ ОТКРЫТ! Прыгайте в портал!");
              return true;
            }
          }
        }
        return false;
      }

      buildStructures() {
        // Structures are generated as the player explores distant regions.
        this.buildStronghold();
      }

      buildEndCityAt(cx, cz) {
        const baseY = 31;
        for (let dx = -6; dx <= 6; dx++) for (let dz = -6; dz <= 6; dz++) {
          this.setBlockRaw(cx + dx, baseY, cz + dz, B.END_STONE);
        }
        for (let y = baseY + 1; y <= baseY + 17; y++) {
          for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
            const edge = Math.abs(dx) === 2 || Math.abs(dz) === 2;
            if (edge || y === baseY + 17) this.setBlockRaw(cx + dx, y, cz + dz, B.OBSIDIAN);
          }
        }
        for (let y = baseY + 4; y <= baseY + 12; y += 4) {
          for (let dx = -4; dx <= 4; dx++) this.setBlockRaw(cx + dx, y, cz + 3, B.END_STONE);
          for (let dz = -4; dz <= 4; dz++) this.setBlockRaw(cx + 3, y, cz + dz, B.END_STONE);
        }
        this.setBlockRaw(cx, baseY + 18, cz, B.CHEST);
        const loot = new Array(27).fill(null);
        loot[0] = { id: "diamond", count: 4 };
        loot[1] = { id: "netherite_scrap", count: 2 };
        loot[2] = { id: "elytra", count: 1 };
        this.chests.set(`end:${cx},${baseY + 18},${cz}`, loot);
      }

      buildBiomeStructureAt(x, z, kind) {
        const y = Math.max(27, this.getSurfaceHeight(x, z));
        this.structures.biomeStructures.push({ x, y, z, kind, biome: this.getBiome(x, z) });
        const floor = kind === "igloo" ? (B.SNOW_BLOCK || B.QUARTZ_BLOCK || B.STONE) : kind === "witch_hut" ? (B.SPRUCE_PLANKS || B.OAK_PLANKS) : (B.MOSSY_COBBLESTONE || B.COBBLESTONE);
        const wall = kind === "igloo" ? floor : kind === "witch_hut" ? (B.SPRUCE_LOG || B.OAK_LOG) : (B.MOSSY_COBBLESTONE || B.COBBLESTONE);
        const radius = kind === "jungle_temple" ? 4 : 3;
        for (let dx = -radius; dx <= radius; dx++) for (let dz = -radius; dz <= radius; dz++) {
          this.setBlockRaw(x + dx, y, z + dz, floor);
          for (let dy = 1; dy <= (kind === "igloo" ? 2 : 4); dy++) {
            const edge = Math.abs(dx) === radius || Math.abs(dz) === radius;
            if (edge) this.setBlockRaw(x + dx, y + dy, z + dz, wall);
          }
        }
        for (let dy = 1; dy <= 2; dy++) this.setBlockRaw(x, y + dy, z - radius, B.AIR);
        const chestX = x + radius - 1, chestZ = z + radius - 1;
        this.setBlockRaw(chestX, y + 1, chestZ, B.CHEST);
        const loot = new Array(27).fill(null);
        loot[0] = { id: kind === "igloo" ? "golden_apple" : kind === "witch_hut" ? "mushroom_stew" : "arrow", count: 2 };
        loot[1] = { id: "bread", count: 3 };
        loot[2] = { id: "sweet_berries", count: 4 };
        loot[3] = { id: "chorus_fruit", count: 1 };
        loot[4] = { id: "poisonous_potato", count: 1 };
        this.chests.set(`overworld:${chestX},${y + 1},${chestZ}`, loot);
      }

      ensureStructuresInRegion(wx, wz) {
        if (this.dimension === "end") {
          const rx = Math.floor(wx / 96), rz = Math.floor(wz / 96);
          const key = "end:" + rx + "," + rz;
          if (this.generatedRegions.has(key)) return;
          this.generatedRegions.add(key);
          const h = hash2(rx, rz, this.seed + 4501);
          if ((rx !== 0 || rz !== 0) && h > 0.52) {
            this.buildEndCityAt(rx * 96 + 54, rz * 96 + 54);
          }
          return;
        }
        if (this.dimension !== "overworld") return;
        const rx = Math.floor(wx / 320);
        const rz = Math.floor(wz / 320);
        const rKey = `${rx},${rz}`;
        if (this.generatedRegions.has(rKey)) return;
        this.generatedRegions.add(rKey);
        if (rx === 0 && rz === 0) return;

        const h = hash2(rx, rz, this.seed + 707);
        const cx = rx * 320 + 150;
        const cz = rz * 320 + 150;
        const biome = this.getBiome(cx, cz);
        if (biome === "Пустыня" || biome === "Бесплодные земли") {
          if (h < 0.76) this.buildPyramidAt(cx, cz);
          else this.buildRuinedPortalAt(cx, cz);
        } else if (biome === "Снежная тайга" || biome === "Ледяные пики") this.buildBiomeStructureAt(cx, cz, "igloo");
        else if (biome === "Болото") this.buildBiomeStructureAt(cx, cz, "witch_hut");
        else if (biome === "Джунгли") this.buildBiomeStructureAt(cx, cz, "jungle_temple");
        this.buildVillageAt(cx, cz, biome);
        const vy = Math.max(27, this.getSurfaceHeight(cx, cz));
        spawnMob("villager_farmer", cx + 1, vy + 1, cz - 1);
        spawnMob("villager_fletcher", cx - 1, vy + 1, cz + 1);
        spawnMob("villager_blacksmith", cx + 2, vy + 1, cz + 2);
      }

      spawnBonusChestNear(px, pz) {
        const cx = Math.floor(px) + 2;
        const cz = Math.floor(pz);
        const cy = this.getSurfaceHeight(cx, cz) + 1;
        this.setBlock(cx, cy - 1, cz, B.GRASS);
        this.setBlock(cx, cy, cz, B.CHEST);
        for (const [tx, tz] of [[cx + 1, cz], [cx - 1, cz], [cx, cz + 1], [cx, cz - 1]]) {
          const ty = this.getSurfaceHeight(tx, tz) + 1;
          if (this.getBlock(tx, ty, tz) === B.AIR) this.setBlock(tx, ty, tz, B.TORCH);
        }
        const loot = new Array(27).fill(null);
        loot[0] = { id: "wood_pickaxe", count: 1 };
        loot[1] = { id: "wood_axe", count: 1 };
        loot[2] = { id: B.OAK_PLANKS, count: 16 };
        loot[3] = { id: "stick", count: 16 };
        loot[4] = { id: "apple", count: 4 };
        loot[5] = { id: "bread", count: 4 };
        this.chests.set(`${this.dimension}:${cx},${cy},${cz}`, loot);
      }

      rebuildChunkMesh(cx, cz) {
        const key = this.chunkKey(cx, cz);
        if (this.meshes.has(key)) {
          const oldGroup = this.meshes.get(key);
          scene.remove(oldGroup);
          oldGroup.traverse(obj => { if (obj.geometry) obj.geometry.dispose(); });
          this.meshes.delete(key);
        }

        const group = new THREE.Group();
        const buckets = new Map();
        const crossBuckets = new Map();
        const dirToFaceIdx = { px: 0, nx: 1, py: 2, ny: 3, pz: 4, nz: 5 };

        const pushFace = (bId, x, y, z, dir, hTop = 1.0) => {
          const fIdx = dirToFaceIdx[dir];
          const bKey = `${bId}_${fIdx}`;
          if (!buckets.has(bKey)) buckets.set(bKey, { bId, fIdx, pos: [], norm: [], uv: [], idx: [] });
          const b = buckets.get(bKey);
          const v0 = b.pos.length / 3;
          const faces = {
            px: [[1,0,1],[1,0,0],[1,hTop,0],[1,hTop,1], [1,0,0]],
            nx: [[0,0,0],[0,0,1],[0,hTop,1],[0,hTop,0], [-1,0,0]],
            py: [[0,hTop,1],[1,hTop,1],[1,hTop,0],[0,hTop,0], [0,1,0]],
            ny: [[0,0,0],[1,0,0],[1,0,1],[0,0,1], [0,-1,0]],
            pz: [[0,0,1],[1,0,1],[1,hTop,1],[0,hTop,1], [0,0,1]],
            nz: [[1,0,0],[0,0,0],[0,hTop,0],[1,hTop,0], [0,0,-1]]
          };
          const f = faces[dir];
          for (let i = 0; i < 4; i++) {
            b.pos.push(x + f[i][0], y + f[i][1], z + f[i][2]);
            b.norm.push(f[4][0], f[4][1], f[4][2]);
          }
          b.uv.push(0,0, 1,0, 1,1, 0,1);
          b.idx.push(v0, v0 + 1, v0 + 2, v0, v0 + 2, v0 + 3);
        };

        const pushCross = (bId, x, y, z) => {
          if (!crossBuckets.has(bId)) crossBuckets.set(bId, { bId, fIdx: 0, pos: [], norm: [], uv: [], idx: [] });
          const b = crossBuckets.get(bId);
          const planes = [
            [[x+0.15,y,z+0.15],[x+0.85,y,z+0.85],[x+0.85,y+0.85,z+0.85],[x+0.15,y+0.85,z+0.15]],
            [[x+0.85,y,z+0.15],[x+0.15,y,z+0.85],[x+0.15,y+0.85,z+0.85],[x+0.85,y+0.85,z+0.15]]
          ];
          for (const p of planes) {
            const v0 = b.pos.length / 3;
            for (const pt of p) {
              b.pos.push(pt[0], pt[1], pt[2]);
              b.norm.push(0, 1, 0);
            }
            b.uv.push(0,0, 1,0, 1,1, 0,1);
            b.idx.push(v0, v0 + 1, v0 + 2, v0, v0 + 2, v0 + 3);
          }
        };

        const isOpaque=(id)=>id!==B.AIR&&!BLOCK_PROPS[id]?.transparent&&id!==B.BED_FOOT&&id!==B.BED_HEAD;
        // Cache centre and four edge-neighbour arrays instead of repeated getBlock Map lookups.
        const centerData=this.getChunk(cx,cz),westData=this.getChunk(cx-1,cz),eastData=this.getChunk(cx+1,cz);
        const northData=this.getChunk(cx,cz-1),southData=this.getChunk(cx,cz+1),stride=CHUNK_SIZE*CHUNK_SIZE;
        const readNeighbor=(lx,y,lz,dx,dy,dz)=>{
          const ny=y+dy;if(ny<0||ny>=WORLD_HEIGHT)return B.AIR;const row=ny*stride;
          if(dx===1)return(lx<CHUNK_SIZE-1?centerData:eastData)[row+(lx<CHUNK_SIZE-1?lx+1:0)+lz*CHUNK_SIZE];
          if(dx===-1)return(lx>0?centerData:westData)[row+(lx>0?lx-1:CHUNK_SIZE-1)+lz*CHUNK_SIZE];
          if(dz===1)return(lz<CHUNK_SIZE-1?centerData:southData)[row+lx+(lz<CHUNK_SIZE-1?lz+1:0)*CHUNK_SIZE];
          if(dz===-1)return(lz>0?centerData:northData)[row+lx+(lz>0?lz-1:CHUNK_SIZE-1)*CHUNK_SIZE];
          return centerData[row+lx+lz*CHUNK_SIZE];
        };
        const visibleNeighbor=(id,lx,y,lz,dx,dy,dz)=>{const nb=readNeighbor(lx,y,lz,dx,dy,dz);if(nb===id&&id===B.WATER)return false;return!isOpaque(nb);};
        for(let lx=0;lx<CHUNK_SIZE;lx++)for(let lz=0;lz<CHUNK_SIZE;lz++){
          const wx=cx*CHUNK_SIZE+lx,wz=cz*CHUNK_SIZE+lz,column=lx+lz*CHUNK_SIZE;
          for(let y=0;y<WORLD_HEIGHT;y++){
            const id=centerData[column+y*stride];if(id===B.AIR)continue;
            const props=BLOCK_PROPS[id];if(props?.cross||id===B.TORCH){pushCross(id,wx,y,wz);continue;}
            const hTop=(id===B.BED_FOOT||id===B.BED_HEAD)?0.56:1;
            if(visibleNeighbor(id,lx,y,lz,1,0,0))pushFace(id,wx,y,wz,"px",hTop);
            if(visibleNeighbor(id,lx,y,lz,-1,0,0))pushFace(id,wx,y,wz,"nx",hTop);
            if(hTop<1||visibleNeighbor(id,lx,y,lz,0,1,0))pushFace(id,wx,y,wz,"py",hTop);
            if(visibleNeighbor(id,lx,y,lz,0,-1,0))pushFace(id,wx,y,wz,"ny",hTop);
            if(visibleNeighbor(id,lx,y,lz,0,0,1))pushFace(id,wx,y,wz,"pz",hTop);
            if(visibleNeighbor(id,lx,y,lz,0,0,-1))pushFace(id,wx,y,wz,"nz",hTop);
          }
        }

        const buildMeshFromBucket = (data) => {
          if (data.pos.length === 0) return;
          const geo = new THREE.BufferGeometry();
          geo.setAttribute("position", new THREE.Float32BufferAttribute(data.pos, 3));
          geo.setAttribute("normal", new THREE.Float32BufferAttribute(data.norm, 3));
          geo.setAttribute("uv", new THREE.Float32BufferAttribute(data.uv, 2));
          geo.setIndex(data.idx);
          const m = ATLAS.materials[data.bId];
          const useMat = Array.isArray(m) ? m[data.fIdx] : m;
          const mesh = new THREE.Mesh(geo, useMat);
          mesh.receiveShadow = false;
          mesh.castShadow = false;
          group.add(mesh);
        };

        for (const data of buckets.values()) buildMeshFromBucket(data);
        for (const data of crossBuckets.values()) buildMeshFromBucket(data);

        scene.add(group);
        this.meshes.set(key, group);
      }

      clearAllMeshes() {
        for (const g of this.meshes.values()) scene.remove(g);
        this.meshes.clear();
        this.meshQueue.length = 0;
        this.meshQueueSet.clear();
      }
    }

    // =========================================================================
    // 7. DETAILED MULTI-PART 3D CHARACTER RIGS & MOBS (VILLAGERS, WITHER SKELETONS, BLAZES)
    // =========================================================================
    const SKIN_PRESETS = {
      steve: { name: "Классический Стив", skin: 0xb58665, hair: 0x3b2818, shirt: 0x268c8c, pants: 0x38388c },
      alex: { name: "Алекс", skin: 0xc99c7a, hair: 0x9c5a2b, shirt: 0x527a32, pants: 0x473829 },
      herobrine: { name: "Херобрин", skin: 0xb58665, hair: 0x3b2818, shirt: 0x268c8c, pants: 0x38388c, whiteEyes: true },
      knight: { name: "Рыцарь", skin: 0x969696, hair: 0x545454, shirt: 0x7a7a7a, pants: 0x595959 }
    };

    function makeNameSprite(text) {
      const c = document.createElement("canvas");
      c.width = 256; c.height = 48;
      const ctx = c.getContext("2d");
      ctx.fillStyle = "rgba(18,18,18,0.62)";
      ctx.fillRect(14, 6, 228, 34);
      ctx.font = "25px VT323, monospace";
      ctx.fillStyle = "#e0e0e0";
      ctx.textAlign = "center";
      ctx.fillText(text, 128, 30);
      const tex = new THREE.CanvasTexture(c);
      const mat = new THREE.SpriteMaterial({ map: tex, depthTest: false });
      const sp = new THREE.Sprite(mat);
      sp.scale.set(2.1, 0.38, 1);
      sp.position.y = 2.18;
      return sp;
    }

    function applySkinAtlasToRig(rig, dataUrl) {
      if (!rig || !dataUrl) return;
      const image = new Image();
      image.onload = () => {
        const makeFace = (rect) => {
          const canvas = document.createElement("canvas");
          canvas.width = 32; canvas.height = 32;
          const ctx = canvas.getContext("2d");
          ctx.imageSmoothingEnabled = false;
          ctx.clearRect(0, 0, 32, 32);
          ctx.drawImage(image, rect[0], rect[1], rect[2], rect[3], 0, 0, 32, 32);
          const tex = new THREE.CanvasTexture(canvas);
          tex.colorSpace = THREE.SRGBColorSpace;
          tex.magFilter = THREE.NearestFilter;
          tex.minFilter = THREE.NearestFilter;
          tex.generateMipmaps = false;
          return new THREE.MeshLambertMaterial({ map: tex, transparent: true });
        };
        const apply = (mesh, faces) => {
          if (!mesh) return;
          if (Array.isArray(mesh.material)) mesh.material.forEach(m => m.map?.dispose());
          else mesh.material?.map?.dispose();
          mesh.material = faces.map(makeFace);
        };
        // Three.js BoxGeometry material order: +X, -X, +Y, -Y, +Z(front), -Z(back).
        apply(rig.headMesh, [[0,8,8,8],[16,8,8,8],[8,0,8,8],[16,0,8,8],[8,8,8,8],[24,8,8,8]]);
        apply(rig.torsoMesh, [[16,20,4,12],[28,20,4,12],[20,16,8,4],[28,16,8,4],[20,20,8,12],[32,20,8,12]]);
        apply(rig.armRMesh, [[44,20,4,12],[48,20,4,12],[44,16,4,4],[48,16,4,4],[40,20,4,12],[52,20,4,12]]);
        apply(rig.armLMesh, [[36,52,4,12],[40,52,4,12],[36,48,4,4],[40,48,4,4],[32,52,4,12],[44,52,4,12]]);
        apply(rig.legRMesh, [[0,20,4,12],[8,20,4,12],[4,16,4,4],[8,16,4,4],[4,20,4,12],[12,20,4,12]]);
        apply(rig.legLMesh, [[16,52,4,12],[24,52,4,12],[20,48,4,4],[24,48,4,4],[20,52,4,12],[28,52,4,12]]);
      };
      image.onerror = () => console.warn("Minecraft skin texture could not be decoded");
      image.src = dataUrl;
    }

    function createHumanoidRig(skinKey = "steve", nametag = null, skinDataUrl = null) {
      const cfg = SKIN_PRESETS[skinKey] || SKIN_PRESETS.steve;
      const root = new THREE.Group();

      const headPivot = new THREE.Group();
      headPivot.position.y = 1.42;
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.48, 0.48), new THREE.MeshLambertMaterial({ color: cfg.skin }));
      head.position.y = 0.24;
      const hair = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.5), new THREE.MeshLambertMaterial({ color: cfg.hair }));
      hair.position.y = 0.44;
      const eyeMat = new THREE.MeshBasicMaterial({ color: cfg.whiteEyes ? 0xe6e6e6 : 0x2b2459 });
      const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.05, 0.02), eyeMat);
      eyeL.position.set(-0.11, 0.25, 0.245);
      const eyeR = eyeL.clone(); eyeR.position.x = 0.11;
      headPivot.add(head, hair, eyeL, eyeR);

      const torso = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.72, 0.24), new THREE.MeshLambertMaterial({ color: cfg.shirt }));
      torso.position.y = 1.06;

      const legL = new THREE.Group(); legL.position.set(-0.12, 0.7, 0);
      const legLMesh = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.7, 0.22), new THREE.MeshLambertMaterial({ color: cfg.pants }));
      legLMesh.position.y = -0.35; legL.add(legLMesh);

      const legR = new THREE.Group(); legR.position.set(0.12, 0.7, 0);
      const legRMesh = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.7, 0.22), new THREE.MeshLambertMaterial({ color: cfg.pants }));
      legRMesh.position.y = -0.35; legR.add(legRMesh);

      const armL = new THREE.Group(); armL.position.set(-0.35, 1.38, 0);
      const armLMesh = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.68, 0.2), new THREE.MeshLambertMaterial({ color: cfg.skin }));
      armLMesh.position.y = -0.32; armL.add(armLMesh);

      const offShield = create3DShieldMesh();
      offShield.position.set(-0.12, -0.46, 0.1);
      offShield.visible = false;
      armL.add(offShield);

      const armR = new THREE.Group(); armR.position.set(0.35, 1.38, 0);
      const armRMesh = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.68, 0.2), new THREE.MeshLambertMaterial({ color: cfg.skin }));
      armRMesh.position.y = -0.32; armR.add(armRMesh);

      const armorParts = {
        head: new THREE.Mesh(new THREE.BoxGeometry(0.54,0.54,0.54), new THREE.MeshLambertMaterial({color:0x9da6ad})),
        chest: new THREE.Mesh(new THREE.BoxGeometry(0.54,0.76,0.30), new THREE.MeshLambertMaterial({color:0x9da6ad})),
        legs: new THREE.Mesh(new THREE.BoxGeometry(0.52,0.68,0.28), new THREE.MeshLambertMaterial({color:0x9da6ad})),
        feet: new THREE.Mesh(new THREE.BoxGeometry(0.52,0.20,0.28), new THREE.MeshLambertMaterial({color:0x9da6ad}))
      };
      armorParts.head.position.y = 1.66;
      armorParts.chest.position.y = 1.06;
      armorParts.legs.position.y = 0.38;
      armorParts.feet.position.y = 0.10;
      Object.values(armorParts).forEach(m => { m.visible = false; root.add(m); });
      root.add(headPivot, torso, legL, legR, armL, armR);
      if (nametag) root.add(makeNameSprite(nametag));
      scene.add(root);

      const rig = { root, headPivot, headMesh: head, torso, torsoMesh: torso, legL, legR, legLMesh, legRMesh, armL, armR, armLMesh, armRMesh, offShield, armorParts, phase: 0 };
      applySkinAtlasToRig(rig, skinDataUrl || (skinKey === "custom" ? GAME.customSkinDataUrl : null));
      return rig;
    }

    function animateHumanoidRig(rig, dt, state) {
      if (!rig) return;
      const speed = state.moving ? (state.sprinting ? 13 : 8) : 0;
      if (speed > 0) rig.phase += dt * speed;
      else rig.phase = 0;

      const swing = Math.sin(rig.phase) * (state.sprinting ? 0.85 : 0.55);
      if (rig.armorParts) {
        const armorIds = state.armor || {};
        for (const [slot, mesh] of Object.entries(rig.armorParts)) {
          const armorId = armorIds[slot];
          mesh.visible = !!armorId;
          if (armorId) {
            const tier = String(armorId).split("_")[0];
            const colors = { leather: 0x98633b, chainmail: 0x9da6ad, gold: 0xe6c13d, iron: 0xbfc7cc, diamond: 0x48c8b6, netherite: 0x51464d };
            mesh.material.color.setHex(colors[tier] || 0x9da6ad);
          }
        }
      }
      rig.legL.rotation.x = swing;
      rig.legR.rotation.x = -swing;

      if (rig.offShield) rig.offShield.visible = !!state.hasOffShield;
      if (state.blocking) {
        rig.armL.rotation.x = -0.9;
        rig.armL.rotation.z = -0.3;
      } else {
        rig.armL.rotation.x = -swing;
        rig.armL.rotation.z = 0;
      }

      if (state.swinging) {
        rig.armR.rotation.x = -1.6 + Math.sin(performance.now() * 0.025) * 0.7;
      } else if (state.aimingBow) {
        rig.armR.rotation.x = -1.45;
        rig.armL.rotation.x = -1.35;
      } else {
        rig.armR.rotation.x = swing;
      }

      if (state.sneaking) {
        rig.torso.rotation.x = 0.35;
        rig.headPivot.position.y = 1.32;
      } else {
        rig.torso.rotation.x = 0;
        rig.headPivot.position.y = 1.42;
      }
      rig.headPivot.rotation.x = -(state.pitch || 0);
    }

    // Small 16x16 pixel-art skins: each mob gets its own palette and blocky noise pattern.
    const MOB_PIXEL_TEXTURES = new Map();
    function getMobPixelTexture(type) {
      if (MOB_PIXEL_TEXTURES.has(type)) return MOB_PIXEL_TEXTURES.get(type);
      const palettes = {
        zombie:["#397878","#4b783c","#263f42"], skeleton:["#c7c7c7","#eeeeea","#777b80"],
        wither_skeleton:["#262626","#454545","#111111"], enderman:["#181818","#34233f","#b852d9"],
        creeper:["#488c38","#70ad4d","#285c2b"], cow:["#543924","#cfcfcf","#3a2418"],
        pig:["#d48a94","#f0b0b7","#a95f6b"], sheep:["#d6d6d6","#f4f0e8","#bfa38e"],
        chicken:["#dedede","#d49b28","#b52b2b"], rabbit:["#b69a7b","#e2d0b7","#80644d"],
        blaze:["#d99b26","#f6d34c","#a94c1c"], dragon:["#1b1724","#3a294c","#c952c9"],
        villager_fletcher:["#593d28","#b58665","#87613e"], villager_farmer:["#72502e","#b58665","#4f7133"],
        villager_blacksmith:["#454545","#b58665","#777777"], villager_cleric:["#6d3e82","#b58665","#d6c4e3"]
      };
      const p = palettes[type] || ["#777777","#aaaaaa","#444444"];
      const canvas = document.createElement("canvas"); canvas.width = 16; canvas.height = 16;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = p[0]; ctx.fillRect(0,0,16,16);
      let seed = [...type].reduce((n,c)=>((n*31+c.charCodeAt(0))>>>0),17);
      for (let y=0;y<16;y++) for (let x=0;x<16;x++) {
        seed = (seed * 1664525 + 1013904223) >>> 0;
        const v = seed / 4294967296;
        if (v > 0.62) { ctx.fillStyle = v > 0.91 ? p[2] : p[1]; ctx.fillRect(x,y,1,1); }
      }
      ctx.fillStyle = p[2]; for(let y=0;y<16;y+=4) ctx.fillRect(0,y,16,1);
      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace; tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter; tex.generateMipmaps = false; tex.needsUpdate = true;
      MOB_PIXEL_TEXTURES.set(type,tex);
      return tex;
    }

    // Calm, vanilla-inspired species-specific pixel coats for passive animals.
    const ANIMAL_PIXEL_TEXTURES=new Map();
    function getAnimalPixelTexture(type){
      if(ANIMAL_PIXEL_TEXTURES.has(type))return ANIMAL_PIXEL_TEXTURES.get(type);
      const c=document.createElement("canvas");c.width=16;c.height=16;const ctx=c.getContext("2d");
      const px=(x,y,color,w=1,h=1)=>{ctx.fillStyle=color;ctx.fillRect(x,y,w,h);};
      if(type==="cow"){
        ctx.fillStyle="#e8e1d0";ctx.fillRect(0,0,16,16);
        px(1,1,"#5b3928",4,3);px(2,3,"#5b3928",3,2);px(10,2,"#4a3024",4,3);px(11,4,"#4a3024",3,2);
        px(5,9,"#5b3928",4,3);px(4,11,"#5b3928",3,2);px(12,11,"#4a3024",3,3);px(0,14,"#c8bda8",3,2);
      }else if(type==="pig"){
        ctx.fillStyle="#e5a0a3";ctx.fillRect(0,0,16,16);
        [[1,2],[5,1],[10,3],[13,1],[3,7],[8,6],[12,9],[1,12],[6,14],[14,14]].forEach(([x,y])=>px(x,y,"#efb7b4"));
        [[4,4],[11,6],[2,10],[9,12],[14,4]].forEach(([x,y])=>px(x,y,"#ce858b"));
      }else if(type==="sheep"){
        ctx.fillStyle="#e9e6dc";ctx.fillRect(0,0,16,16);
        for(let y=0;y<16;y+=4)for(let x=(y%8?2:0);x<16;x+=4){px(x,y,"#f5f2e9",2,2);px(x+2,y+2,"#d7d2c7");}
      }else if(type==="chicken"){
        ctx.fillStyle="#eee9dc";ctx.fillRect(0,0,16,16);
        [[1,2],[5,1],[9,3],[13,1],[3,7],[8,6],[12,9],[2,12],[7,14],[14,13]].forEach(([x,y])=>px(x,y,"#d8d0bd"));
        px(4,4,"#f8f5ec",3,2);px(10,11,"#f8f5ec",3,2);
      }else{
        ctx.fillStyle="#b69a78";ctx.fillRect(0,0,16,16);
        [[1,1],[2,2],[7,1],[8,2],[12,1],[13,2],[3,7],[4,8],[9,6],[10,7],[13,11],[14,12]].forEach(([x,y])=>px(x,y,"#d3b995"));
        [[5,4],[11,4],[1,12],[7,13],[12,14]].forEach(([x,y])=>px(x,y,"#8c7258"));
      }
      const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;tex.magFilter=THREE.NearestFilter;
      tex.minFilter=THREE.NearestMipmapNearestFilter;tex.generateMipmaps=true;tex.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());tex.needsUpdate=true;
      ANIMAL_PIXEL_TEXTURES.set(type,tex);return tex;
    }

    function buildDetailedMobModel(type) {
      const g = new THREE.Group();
      const parts = { legs: [], wings: [], rods: [], head: null, body: null };

      const makeQuadruped = (bodyCol, bodySize, headCol, headSize, legH, extraFn) => {
        const coat = ["cow","pig","sheep","chicken","rabbit"].includes(type) ? new THREE.MeshLambertMaterial({ map: getAnimalPixelTexture(type) }) : null;
        const body = new THREE.Mesh(new THREE.BoxGeometry(...bodySize), coat || new THREE.MeshLambertMaterial({ color: bodyCol }));
        body.position.y = legH + bodySize[1] / 2;
        g.add(body);
        parts.body = body;

        const head = new THREE.Group();
        head.position.set(0, legH + bodySize[1] * 0.7, bodySize[2] / 2 + headSize[2] * 0.35);
        const hMesh = new THREE.Mesh(new THREE.BoxGeometry(...headSize), coat || new THREE.MeshLambertMaterial({ color: headCol }));
        head.add(hMesh);
        g.add(head);
        parts.head = head;

        const lx = bodySize[0] * 0.3, lz = bodySize[2] * 0.35;
        for (const [sx, sz] of [[-lx, lz], [lx, lz], [-lx, -lz], [lx, -lz]]) {
          const legPivot = new THREE.Group();
          legPivot.position.set(sx, legH, sz);
          const legM = new THREE.Mesh(new THREE.BoxGeometry(0.18, legH, 0.18), coat || new THREE.MeshLambertMaterial({ color: headCol }));
          legM.position.y = -legH / 2;
          legPivot.add(legM);
          g.add(legPivot);
          parts.legs.push(legPivot);
        }
        if (extraFn) extraFn(head, body);
      };

      const addAnimalEyes=(head,headSize,spacing=0.12)=>{
        const eyeMat=new THREE.MeshBasicMaterial({color:0x241a16}),glintMat=new THREE.MeshBasicMaterial({color:0xf4eadb});
        for(const side of [-1,1]){
          const eye=new THREE.Mesh(new THREE.BoxGeometry(0.055,0.055,0.025),eyeMat);eye.position.set(side*spacing,0.055,headSize[2]/2+0.012);head.add(eye);
          const glint=new THREE.Mesh(new THREE.BoxGeometry(0.018,0.018,0.012),glintMat);glint.position.set(side*spacing-0.008,0.068,headSize[2]/2+0.028);head.add(glint);
        }
      };

      if (type.startsWith("villager_")) {
        const profKey = type.replace("villager_", "");
        const prof = VILLAGER_PROFESSIONS[profKey] || VILLAGER_PROFESSIONS.fletcher;
        const robe = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.15, 0.32), referenceMaterial(referenceCanvas16(ctx => { ctx.fillStyle = prof.hatColor ? "#" + prof.hatColor.toString(16).padStart(6,"0") : "#75604a"; ctx.fillRect(0,0,16,16); for(let y=2;y<16;y+=4){ctx.fillStyle="rgba(0,0,0,0.18)";ctx.fillRect(0,y,16,1);} })));
        robe.position.y = 0.72;
        const head = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.56, 0.46), referenceMaterial(getReferenceMobTexture("villager_skin")));
        head.position.y = 1.56;
        const nose = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.22, 0.14), new THREE.MeshLambertMaterial({ color: 0x9c6e4e }));
        nose.position.set(0, -0.08, 0.27);
        const hat = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.14, 0.56), new THREE.MeshLambertMaterial({ color: prof.hatColor }));
        hat.position.set(0, 0.26, 0);
        head.add(nose, hat);
        const foldedArms = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.22, 0.24), new THREE.MeshLambertMaterial({ color: 0x472f1e }));
        foldedArms.position.set(0, 1.05, 0.16);
        g.add(robe, head, foldedArms, makeNameSprite(prof.title));
        parts.head = head;
      } else if (type === "cow") {
        makeQuadruped(0x543924, [0.75, 0.68, 1.15], 0x4a311e, [0.46, 0.46, 0.44], 0.55, (head, body) => {
          // The dedicated cow coat texture already contains the dark patches.
          const snout = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.2, 0.1), new THREE.MeshLambertMaterial({ color: 0xb89c8a }));
          snout.position.set(0, -0.1, 0.24);
          const hornL = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.18, 0.07), new THREE.MeshLambertMaterial({ color: 0xd4d0c5 }));
          hornL.position.set(-0.24, 0.24, 0);
          const hornR = hornL.clone(); hornR.position.x = 0.24;
          addAnimalEyes(head,[0.46,0.46,0.44],0.13);head.add(snout,hornL,hornR);
        });
      } else if (type === "pig") {
        makeQuadruped(0xd48a94, [0.68, 0.56, 1.0], 0xdb959f, [0.46, 0.44, 0.44], 0.42, (head) => {
          const snout = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.16, 0.12), new THREE.MeshLambertMaterial({ color: 0xc2727d }));
          snout.position.set(0, -0.06, 0.25);
          addAnimalEyes(head,[0.46,0.44,0.44],0.13);head.add(snout);
        });
      } else if (type === "sheep") {
        makeQuadruped(0xd6d6d6, [0.78, 0.68, 1.1], 0xbfa38e, [0.42, 0.42, 0.44], 0.5, (head) => {
          const woolCap = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.16, 0.46), new THREE.MeshLambertMaterial({ color: 0xd6d6d6 }));
          woolCap.position.y = 0.2;
          addAnimalEyes(head,[0.42,0.42,0.44],0.11);head.add(woolCap);
        });
      } else if (type === "chicken") {
        makeQuadruped(0xdedede, [0.42, 0.38, 0.52], 0xdedede, [0.26, 0.32, 0.26], 0.28, (head, body) => {
          const beak = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.08, 0.14), new THREE.MeshLambertMaterial({ color: 0xd49b28 }));
          beak.position.set(0, 0, 0.18);
          const wattle = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.12, 0.08), new THREE.MeshLambertMaterial({ color: 0xb52b2b }));
          wattle.position.set(0, -0.09, 0.15);
          const wingL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.24, 0.38), new THREE.MeshLambertMaterial({ color: 0xc7c7c7 }));
          wingL.position.set(-0.24, 0, 0);
          const wingR = wingL.clone(); wingR.position.x = 0.24;
          addAnimalEyes(head,[0.26,0.32,0.26],0.075);head.add(beak,wattle);
          body.add(wingL, wingR);
          parts.wings.push(wingL, wingR);
        });
      } else if (type === "rabbit") {
        makeQuadruped(0xb69a78,[0.38,0.36,0.48],0xb69a78,[0.28,0.3,0.3],0.22,(head)=>{
          const earMat=new THREE.MeshLambertMaterial({color:0xb69a78});
          for(const side of [-1,1]){const ear=new THREE.Mesh(new THREE.BoxGeometry(0.09,0.38,0.1),earMat);ear.position.set(side*0.09,0.28,0);head.add(ear);}
          addAnimalEyes(head,[0.28,0.3,0.3],0.085);
        });
      } else if (type === "zombie" || type === "skeleton" || type === "wither_skeleton" || type === "enderman") {
        const isEnd = type === "enderman";
        const isWither = type === "wither_skeleton";
        const isSkel = type === "skeleton" || isWither;
        const bodyCol = isEnd ? 0x181818 : isWither ? 0x262626 : isSkel ? 0xc7c7c7 : 0x397878;
        const headCol = isEnd ? 0x181818 : isWither ? 0x2b2b2b : isSkel ? 0xd4d4d4 : 0x4b783c;
        const legH = isEnd ? 1.35 : isWither ? 0.92 : 0.72;
        const torsoH = isWither ? 0.85 : 0.72;
        const limbW = (isEnd || isSkel) ? 0.11 : 0.2;

        const torso = new THREE.Mesh(new THREE.BoxGeometry(0.48, torsoH, 0.24), new THREE.MeshLambertMaterial({ color: bodyCol }));
        torso.position.y = legH + torsoH / 2;
        const head = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.46, 0.46), new THREE.MeshLambertMaterial({ color: headCol }));
        head.position.y = legH + torsoH + 0.23;
        if (isEnd) {
          const eyeMat = new THREE.MeshBasicMaterial({ color: 0xb852d9 });
          const eL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.04, 0.02), eyeMat); eL.position.set(-0.12, 0, 0.235);
          const eR = eL.clone(); eR.position.x = 0.12;
          head.add(eL, eR);
        }
        g.add(torso, head);
        parts.head = head;

        for (const sx of [-0.13, 0.13]) {
          const lp = new THREE.Group(); lp.position.set(sx, legH, 0);
          const lm = new THREE.Mesh(new THREE.BoxGeometry(limbW, legH, limbW), new THREE.MeshLambertMaterial({ color: isEnd ? 0x181818 : isWither ? 0x262626 : isSkel ? 0xc7c7c7 : 0x383878 }));
          lm.position.y = -legH / 2; lp.add(lm); g.add(lp); parts.legs.push(lp);
        }
        for (const sx of [-0.34, 0.34]) {
          const ap = new THREE.Group(); ap.position.set(sx, legH + torsoH - 0.04, 0);
          const armLen = isEnd ? 1.3 : isWither ? 0.82 : 0.68;
          const am = new THREE.Mesh(new THREE.BoxGeometry(limbW, armLen, limbW), new THREE.MeshLambertMaterial({ color: headCol }));
          am.position.y = -armLen / 2;
          ap.add(am);
          if (type === "zombie") ap.rotation.x = -1.35;
          if (isWither && sx > 0) {
            const sword = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.75, 0.12), new THREE.MeshLambertMaterial({ color: 0x6e6e6e }));
            sword.position.set(0, -armLen, 0.28);
            sword.rotation.x = Math.PI / 2;
            ap.add(sword);
            ap.rotation.x = -0.9;
          }
          g.add(ap);
        }
      } else if (type === "creeper") {
        const col = 0x488c38;
        const body = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.85, 0.26), new THREE.MeshLambertMaterial({ color: col }));
        body.position.y = 0.42 + 0.425;
        const head = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.48, 0.48), new THREE.MeshLambertMaterial({ color: col }));
        head.position.y = 0.42 + 0.85 + 0.24;
        const faceMat = new THREE.MeshBasicMaterial({ color: 0x182614 });
        const f1 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.02), faceMat); f1.position.set(-0.11, 0.06, 0.245);
        const f2 = f1.clone(); f2.position.x = 0.11;
        const f3 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.14, 0.02), faceMat); f3.position.set(0, -0.09, 0.245);
        head.add(f1, f2, f3);
        g.add(body, head);
        parts.head = head;
        for (const [sx, sz] of [[-0.14, 0.18], [0.14, 0.18], [-0.14, -0.18], [0.14, -0.18]]) {
          const lp = new THREE.Group(); lp.position.set(sx, 0.42, sz);
          const lm = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.42, 0.2), new THREE.MeshLambertMaterial({ color: col }));
          lm.position.y = -0.21; lp.add(lm); g.add(lp); parts.legs.push(lp);
        }
      } else if (type === "blaze") {
        const head = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.46, 0.46), new THREE.MeshLambertMaterial({ color: 0xd99b26 }));
        head.position.y = 1.2;
        g.add(head);
        for (let i = 0; i < 6; i++) {
          const rod = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.55, 0.1), new THREE.MeshBasicMaterial({ color: 0xe3b838 }));
          const ang = (i / 6) * Math.PI * 2;
          rod.position.set(Math.cos(ang) * 0.55, 0.85 + (i % 2) * 0.25, Math.sin(ang) * 0.55);
          g.add(rod);
          parts.rods.push({ mesh: rod, ang });
        }
      } else if (type === "crystal") {
        const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.65), new THREE.MeshBasicMaterial({ color: 0xc952c9 }));
        core.position.y = 0.8;
        const frame = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(1.1, 1.1, 1.1)), new THREE.LineBasicMaterial({ color: 0xe0e0e0 }));
        frame.position.y = 0.8;
        g.add(core, frame);
      } else if (type === "dragon") {
        const body = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.2, 3.6), new THREE.MeshLambertMaterial({ color: 0x1b1724 }));
        const head = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.9, 1.3), new THREE.MeshLambertMaterial({ color: 0x221d2e }));
        head.position.set(0, 0.3, 2.3);
        const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.1, 0.05), new THREE.MeshBasicMaterial({ color: 0xc952c9 }));
        eyeL.position.set(-0.3, 0.1, 0.66);
        const eyeR = eyeL.clone(); eyeR.position.x = 0.3;
        head.add(eyeL, eyeR);

        const wingL = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.12, 1.8), new THREE.MeshLambertMaterial({ color: 0x2b2438 }));
        wingL.position.set(-2.3, 0.3, 0.2);
        const wingR = wingL.clone(); wingR.position.x = 2.3;
        const tail = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 2.6), new THREE.MeshLambertMaterial({ color: 0x1b1724 }));
        tail.position.set(0, 0.1, -2.9);

        g.add(body, head, wingL, wingR, tail);
        parts.wings.push(wingL, wingR);
      }

      // Passive animals already have dedicated species textures applied by makeQuadruped.
      // Never overwrite them with the generic noisy mob skin.
      const hasDedicatedAnimalSkin = ["cow", "pig", "sheep", "chicken", "rabbit"].includes(type);
      if (type !== "crystal" && !hasDedicatedAnimalSkin) {
        const skin = getMobPixelTexture(type);
        g.traverse(o => {
          if (!o.isMesh || !o.material || !o.material.isMeshLambertMaterial) return;
          o.material = o.material.clone();
          o.material.map = skin;
          o.material.color.setHex(0xffffff);
          o.material.needsUpdate = true;
        });
      }
      // Apply the reference 16x16 species skin to every substantial body mesh.
      // Tiny facial details (eyes, nose, beak) keep their own vanilla colours.
      const mobSkin = getReferenceMobTexture(type);
      if (!type.startsWith("villager_")) g.traverse(o => {
        if (!o.isMesh || !o.material || !o.material.isMeshLambertMaterial) return;
        const box = new THREE.Box3().setFromObject(o);
        const size = new THREE.Vector3(); box.getSize(size);
        if (Math.max(size.x,size.y,size.z) < 0.14) return;
        o.material = o.material.clone();
        o.material.map = mobSkin;
        o.material.color.setHex(0xffffff);
        o.material.needsUpdate = true;
      });
      return { group: g, parts };
    }

    // =========================================================================
    // 8. GAME STATE, RULES, OFF-HAND & SHIELD/BOW COMBAT STATE
    // =========================================================================
    type GameMode = "survival" | "creative" | "spectator";
type Difficulty = "peaceful" | "easy" | "normal" | "hard";

interface WorldConfig {
  name: string;
  seedInput: string;
  gamemode: GameMode;
  difficulty: Difficulty;
  bonusChest: boolean;
  keepInventory: boolean;
  allowCheats: boolean;
  doDaylightCycle: boolean;
}

// The original game logic is intentionally kept intact during the JS → TypeScript
// migration. The legacy systems will receive stricter types incrementally.
const WORLD_CONFIG: WorldConfig = {
      name: "Новый мир",
      seedInput: "",
      gamemode: "survival",
      difficulty: "normal",
      bonusChest: false,
      keepInventory: false,
      allowCheats: true,
      doDaylightCycle: true
    };

    const GAME = {
      state: "menu",
      gamemode: "survival",
      difficulty: "normal",
      keepInventory: false,
      allowCheats: true,
      doDaylightCycle: true,
      weather: "clear",
      renderDist: 6,
      fov: 75,
      mouseSens: 1.0,
      graphicsQuality: "medium",
      world: null,
      timeOfDay: 1800,
      dayCount: 1,
      portalTimer: 0,
      swingTimer: 0,
      fishing: null,
      equipAnim: 0,
      cameraMode: 0,
      skin: "steve",
      customSkinDataUrl: null
    };
    try {
      GAME.customSkinDataUrl = localStorage.getItem("minecraft-custom-skin-v1") || null;
      if (GAME.customSkinDataUrl) GAME.skin = "custom";
    } catch (_) {}

    const PLAYER = {
      pos: new THREE.Vector3(8.5, 36, 8.5),
      vel: new THREE.Vector3(0, 0, 0),
      yaw: 0,
      pitch: 0,
      onGround: false,
      inWater: false,
      inLava: false,
      flying: false,
      sprinting: false,
      sneaking: false,
      blockingShield: false,
      bowPullTime: 0,
      isPullingBow: false,
      health: 20,
      maxHealth: 20,
      hunger: 20,
      hungerTick: 0,
      regenTick: 0,
      air: 300,
      fireTicks: 0,
      xp: 0,
      level: 0,
      fallStartY: null,
      spawnPos: { dim: "overworld", x: 8.5, y: 36, z: 8.5 },
      hotbarIdx: 0,
      inv: new Array(36).fill(null),
      offhand: null,
      armor: { head: null, chest: null, legs: null, feet: null },
      effects: { speed: 0, jump: 0, strength: 0, night_vision: 0 },
      eatTimer: 0,
      eatTimer: 0,
      bobTimer: 0,
      stepDist: 0,
      invulnTimer: 0,
      rig: null
    };

    const rainDrops = [];
    const rainGeo = new THREE.BoxGeometry(0.03, 0.45, 0.03);
    const rainMat = new THREE.MeshBasicMaterial({ color: 0x628ec9, transparent: true, opacity: 0.6 });
    for (let i = 0; i < 120; i++) {
      const m = new THREE.Mesh(rainGeo, rainMat);
      m.visible = false;
      scene.add(m);
      rainDrops.push(m);
    }

    // =========================================================================
    // 9. MOBS, THROWN EYES OF ENDER, ARROWS, DROPS & BOSS
    // =========================================================================
    const entities = [];

    function clearAllEntities() {
      for (const e of entities) scene.remove(e.mesh);
      entities.length = 0;
      document.getElementById("boss-bar-wrap").classList.add("hidden");
    }

    function spawnDrop(x, y, z, id, count = 1, networkId = null, fromNetwork = false) {
      if (!id || count <= 0) return;
      if (typeof id !== "number") ensureItemIcon(id);
      const isBlock = typeof id === "number" && ATLAS.materials[id];
      const mat = isBlock
        ? (Array.isArray(ATLAS.materials[id]) ? ATLAS.materials[id][0] : ATLAS.materials[id])
        : new THREE.MeshBasicMaterial({ map: ATLAS.itemTextures[id], transparent: true, alphaTest: 0.4, side: THREE.DoubleSide });
      const mesh = new THREE.Mesh(
        isBlock ? new THREE.BoxGeometry(0.28, 0.28, 0.28) : new THREE.PlaneGeometry(0.36, 0.36),
        mat
      );
      mesh.position.set(x, y, z);
      scene.add(mesh);
      let netId = networkId;
      if (!fromNetwork && MP.active && fbDb && MP.roomId && GAME.world) {
        const dropRef = push(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/drops`));
        netId = dropRef.key;
        set(dropRef, { id, count, x, y, z, dim: GAME.world.dimension, by: MP.playerId, createdAt: Date.now() }).catch(err => console.warn("Drop sync failed:", err));
      }
      entities.push({
        type: "drop",
        id,
        count,
        mesh,
        netId,
        fromNetwork,
        dim: GAME.world?.dimension || "overworld",
        vel: new THREE.Vector3((Math.random() - 0.5) * 2, 2.8, (Math.random() - 0.5) * 2),
        age: 0,
        baseY: y,
        floatPhase: Math.random() * Math.PI * 2
      });
    }

    // Physical Flying Eye of Ender entity leading toward Stronghold
    function launchEyeOfEnder() {
      const origin = getEyePos();
      const sh = GAME.world.structures.stronghold;
      const toSh = new THREE.Vector3(sh.x - origin.x, 0, sh.z - origin.z);
      const dist = toSh.length();
      if (dist > 0.1) toSh.normalize();
      else toSh.set(0, 0, -1);

      const mesh = new THREE.Mesh(
        new THREE.PlaneGeometry(0.45, 0.45),
        new THREE.MeshBasicMaterial({ map: ATLAS.itemTextures.ender_eye, transparent: true, alphaTest: 0.4, side: THREE.DoubleSide })
      );
      mesh.position.copy(origin).addScaledVector(toSh, 0.8);
      scene.add(mesh);

      SFX.eyeLaunch();
      consumeHeld(1);
      showBanner(`Око Края летит к Крепости (расстояние ~${Math.round(dist)} блоков)...`);

      entities.push({
        type: "thrown_eye",
        mesh,
        target: mesh.position.clone().addScaledVector(toSh, Math.min(15, dist)).add(new THREE.Vector3(0, 4.5, 0)),
        life: 2.2
      });
    }

    // Physical Arrow shot from Bow
    function shootArrow(chargeRatio) {
      const origin = getEyePos();
      const dir = getLookDir();
      const speed = 12 + chargeRatio * 26;
      const mesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.08, 0.08, 0.75),
        new THREE.MeshLambertMaterial({ color: 0x785329 })
      );
      mesh.position.copy(origin).addScaledVector(dir, 0.7);
      mesh.lookAt(mesh.position.clone().add(dir));
      scene.add(mesh);

      SFX.bowShoot();
      entities.push({
        type: "arrow",
        mesh,
        vel: dir.clone().multiplyScalar(speed),
        dmg: Math.round(3 + chargeRatio * 7),
        life: 4.0
      });
    }

    function spawnMob(type, x, y, z) {
      const configs = {
        villager_fletcher: { name: "Лучник", hp: 20, passiveVillager: "fletcher", w: 0.65, h: 1.9 },
        villager_farmer: { name: "Фермер", hp: 20, passiveVillager: "farmer", w: 0.65, h: 1.9 },
        villager_blacksmith: { name: "Оружейник", hp: 20, passiveVillager: "blacksmith", w: 0.65, h: 1.9 },
        villager_cleric: { name: "Священник", hp: 20, passiveVillager: "cleric", w: 0.65, h: 1.9 },
        cow: { name: "Корова", hp: 10, hostile: false, w: 0.85, h: 1.25, drop: "raw_beef", dropExtra: "leather" },
        pig: { name: "Свинья", hp: 10, hostile: false, w: 0.75, h: 0.95, drop: "porkchop" },
        sheep: { name: "Овца", hp: 8, hostile: false, w: 0.8, h: 1.2, drop: "mutton", dropExtra: B.WOOL_WHITE },
        chicken: { name: "Курица", hp: 4, hostile: false, w: 0.5, h: 0.7, drop: "raw_chicken", dropExtra: "feather" },
        rabbit: { name: "Кролик", hp: 6, hostile: false, w: 0.45, h: 0.55, drop: "rabbit", dropExtra: "rabbit_hide" },
        zombie: { name: "Зомби", hp: 20, hostile: true, w: 0.65, h: 1.85, dmg: 3, drop: "rotten_flesh" },
        skeleton: { name: "Скелет", hp: 20, hostile: true, w: 0.65, h: 1.85, dmg: 3, drop: "bone" },
        wither_skeleton: { name: "Визер-скелет", hp: 24, hostile: true, w: 0.7, h: 2.2, dmg: 5, drop: "wither_skull" },
        creeper: { name: "Крипер", hp: 20, hostile: true, w: 0.65, h: 1.75, dmg: 8, drop: "gunpowder" },
        enderman: { name: "Эндермен", hp: 30, hostile: true, w: 0.65, h: 2.6, dmg: 5, drop: "ender_pearl" },
        blaze: { name: "Ифрит", hp: 20, hostile: true, w: 0.75, h: 1.7, dmg: 4, drop: "blaze_rod" },
        crystal: { name: "Кристалл Края", hp: 1, hostile: false, w: 1.2, h: 1.4 },
        dragon: { name: "Дракон Края", hp: 120, maxHp: 120, hostile: true, w: 3.6, h: 2.2, dmg: 6 }
      };
      const cfg = configs[type];
      if (!cfg) return;
      if (cfg.hostile && GAME.difficulty === "peaceful") return;

      const built = buildDetailedMobModel(type);
      built.group.position.set(x, y, z);
      scene.add(built.group);

      const ent = {
        type,
        cfg,
        hp: cfg.hp,
        maxHp: cfg.maxHp || cfg.hp,
        mesh: built.group,
        parts: built.parts,
        vel: new THREE.Vector3(),
        timer: Math.random() * 4,
        walkPhase: Math.random() * 6,
        hurtTimer: 0
      };
      entities.push(ent);

      if (type === "dragon") {
        document.getElementById("boss-bar-wrap").classList.remove("hidden");
        document.getElementById("boss-bar-fill").style.width = "100%";
      }
      return ent;
    }

    function damageEntity(ent, dmg) {
      ent.hp -= dmg;
      ent.hurtTimer = 0.25;
      ent.mesh.traverse(o => { if (o.isMesh && o.material?.emissive) o.material.emissive.setHex(0x661111); });
      const mobVoice = { cow:95, pig:145, sheep:125, chicken:520, rabbit:390, zombie:82, skeleton:210, wither_skeleton:68, creeper:105, enderman:260, blaze:430, dragon:54, crystal:760 };
      const voice = mobVoice[ent.type] || 180;
      SFX.tone(voice, ent.type === "chicken" || ent.type === "blaze" ? "triangle" : "sawtooth", 0.14, 0.09, voice * 0.62);
      SFX.hurt();

      if (ent.type === "dragon") {
        document.getElementById("boss-bar-fill").style.width = `${Math.max(0, (ent.hp / ent.maxHp) * 100)}%`;
      }

      if (ent.hp <= 0) {
        if (ent.type === "crystal") {
          SFX.explode();
          showBanner("Кристалл Края уничтожен!");
        } else if (ent.type === "dragon") {
          SFX.explode();
          document.getElementById("boss-bar-wrap").classList.add("hidden");
          GAME.world.setBlock(0, 33, 0, B.DRAGON_EGG);
          PLAYER.xp += 120;
          updateXP();
          GAME.state = "victory";
          document.exitPointerLock?.();
          document.getElementById("end-poem-screen").classList.remove("hidden");
        } else if (ent.cfg.drop) {
          if (ent.type === "wither_skeleton" && Math.random() > 0.35) {
            spawnDrop(ent.mesh.position.x, ent.mesh.position.y + 0.5, ent.mesh.position.z, "coal", 2);
          } else {
            spawnDrop(ent.mesh.position.x, ent.mesh.position.y + 0.5, ent.mesh.position.z, ent.cfg.drop, 1);
          }
          if (ent.cfg.dropExtra) spawnDrop(ent.mesh.position.x + 0.2, ent.mesh.position.y + 0.5, ent.mesh.position.z, ent.cfg.dropExtra, 1);
          if (ent.type === "chicken" && Math.random() < 0.65) spawnDrop(ent.mesh.position.x + 0.35, ent.mesh.position.y + 0.5, ent.mesh.position.z, "egg", 1);
          PLAYER.xp += 18;
          updateXP();
        }
        scene.remove(ent.mesh);
        const idx = entities.indexOf(ent);
        if (idx >= 0) entities.splice(idx, 1);
      }
    }

    function launchHostileProjectile(source, kind = "fireball") {
      const start = source.mesh.position.clone().add(new THREE.Vector3(0, 0.8, 0));
      const target = PLAYER.pos.clone().add(new THREE.Vector3(0, 1.0, 0));
      const direction = target.sub(start).normalize();
      const color = kind === "dragon_breath" ? 0x9b42d6 : kind === "skeleton_arrow" ? 0xb99a62 : 0xff8a24;
      const geometry = kind === "skeleton_arrow" ? new THREE.BoxGeometry(0.07, 0.07, 0.62) : new THREE.SphereGeometry(kind === "dragon_breath" ? 0.34 : 0.22, 8, 8);
      const mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.92 }));
      mesh.position.copy(start);
      scene.add(mesh);
      entities.push({
        type: "hostile_projectile", kind, mesh,
        vel: direction.multiplyScalar(kind === "dragon_breath" ? 8 : kind === "skeleton_arrow" ? 15 : 10),
        life: kind === "dragon_breath" ? 5 : 4,
        damage: kind === "dragon_breath" ? 5 : kind === "skeleton_arrow" ? 3 : 4
      });
    }

    function launchEnderPearl() {
      const start = getEyePos().add(getLookDir().multiplyScalar(0.7));
      const velocity = getLookDir().multiplyScalar(15);
      velocity.y += 2.0;
      const mesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.16, 8, 8),
        new THREE.MeshBasicMaterial({ color: 0x287d70 })
      );
      mesh.position.copy(start);
      scene.add(mesh);
      entities.push({ type: "thrown_pearl", mesh, vel: velocity, life: 3.5 });
      consumeHeld(1);
      SFX.eyeLaunch();
    }

    function moveMobWithCollision(entity, dx, dz) {
      const width = entity.cfg?.w || 0.6;
      const height = entity.cfg?.h || 1.8;
      const canOccupy = (x, z) => {
        const minX = Math.floor(x - width * 0.35);
        const maxX = Math.floor(x + width * 0.35);
        const minZ = Math.floor(z - width * 0.35);
        const maxZ = Math.floor(z + width * 0.35);
        const minY = Math.floor(entity.mesh.position.y + 0.05);
        const maxY = Math.floor(entity.mesh.position.y + height - 0.05);
        for (let bx = minX; bx <= maxX; bx++) {
          for (let by = minY; by <= maxY; by++) {
            for (let bz = minZ; bz <= maxZ; bz++) {
              if (BLOCK_PROPS[GAME.world.getBlock(bx, by, bz)]?.solid) return false;
            }
          }
        }
        return true;
      };
      const nextX = entity.mesh.position.x + dx;
      if (canOccupy(nextX, entity.mesh.position.z)) entity.mesh.position.x = nextX;
      const nextZ = entity.mesh.position.z + dz;
      if (canOccupy(entity.mesh.position.x, nextZ)) entity.mesh.position.z = nextZ;
    }

    function tickEntities(dt) {
      for (let i = entities.length - 1; i >= 0; i--) {
        const e = entities[i];
        if (e.type === "drop") {
          e.age += dt;
          e.floatPhase = (e.floatPhase || 0) + dt * 3.2;
          e.mesh.rotation.y += dt * 2.5;
          e.mesh.position.y = (e.baseY ?? e.mesh.position.y) + Math.sin(e.floatPhase) * 0.08;
          const bBelow = GAME.world.getBlock(e.mesh.position.x, e.mesh.position.y - 0.2, e.mesh.position.z);
          if (!BLOCK_PROPS[bBelow]?.solid) {
            e.vel.y -= 16 * dt;
            e.mesh.position.addScaledVector(e.vel, dt);
          }
          const dist = e.mesh.position.distanceTo(PLAYER.pos.clone().add(new THREE.Vector3(0, 0.8, 0)));
          if (dist < 2.2 && e.age > 0.35) {
            e.mesh.position.lerp(PLAYER.pos.clone().add(new THREE.Vector3(0, 0.8, 0)), dt * 10);
            if (dist < 0.75 && !e.pickupPending && canAcceptDrop(e.id, e.count)) {
              if (e.netId && MP.active && fbDb && MP.roomId) {
                e.pickupPending = true;
                const dropRef = ref(fbDb, `minecraft_game/rooms/${MP.roomId}/drops/${e.netId}`);
                runTransaction(dropRef, current => current ? null : undefined).then(result => {
                  if (result.committed && giveItem(e.id, e.count)) {
                    SFX.pickup();
                    scene.remove(e.mesh);
                    const at = entities.indexOf(e);
                    if (at >= 0) entities.splice(at, 1);
                  } else {
                    e.pickupPending = false;
                  }
                }).catch(() => { e.pickupPending = false; });
              } else if (giveItem(e.id, e.count)) {
                SFX.pickup();
                scene.remove(e.mesh);
                entities.splice(i, 1);
                continue;
              }
            }
          }
          continue;
        }

        if (e.type === "thrown_eye") {
          e.life -= dt;
          e.mesh.position.lerp(e.target, dt * 2.2);
          e.mesh.lookAt(camera.position);
          if (Math.random() < 0.5) spawnParticles(e.mesh.position.x, e.mesh.position.y, e.mesh.position.z, 0x9b4fd4, 1);
          if (e.life <= 0) {
            if (Math.random() < 0.8) spawnDrop(e.mesh.position.x, e.mesh.position.y, e.mesh.position.z, "ender_eye", 1);
            else {
              SFX.breakBlock("stone");
              spawnParticles(e.mesh.position.x, e.mesh.position.y, e.mesh.position.z, 0x48ba7b, 10);
            }
            scene.remove(e.mesh);
            entities.splice(i, 1);
          }
          continue;
        }

        if (e.type === "thrown_pearl") {
          e.life -= dt;
          e.vel.y -= 12 * dt;
          e.mesh.position.addScaledVector(e.vel, dt);
          const pearlBlock = GAME.world.getBlock(e.mesh.position.x, e.mesh.position.y, e.mesh.position.z);
          if (BLOCK_PROPS[pearlBlock]?.solid || e.life <= 0) {
            const safe = e.mesh.position.clone();
            safe.y = Math.max(2, safe.y);
            if (!collidesAt(safe)) {
              PLAYER.pos.copy(safe);
              PLAYER.vel.set(0, 0, 0);
              damagePlayer(2, "Телепортация жемчугом Эндера", true);
              updateChunksAroundPlayer(true);
              resolveStuckInBlocks();
            }
            scene.remove(e.mesh);
            entities.splice(i, 1);
          }
          continue;
        }

        if (e.type === "thrown_snowball") {
          e.life -= dt; e.vel.y -= 8 * dt; e.mesh.position.addScaledVector(e.vel, dt);
          const hitBlock = BLOCK_PROPS[GAME.world.getBlock(e.mesh.position.x,e.mesh.position.y,e.mesh.position.z)]?.solid;
          let hitMob = false;
          for (const target of entities) {
            if (!target.cfg || target.type === "thrown_snowball") continue;
            const center = target.mesh.position.clone().add(new THREE.Vector3(0,(target.cfg.h||1)*0.5,0));
            if (center.distanceTo(e.mesh.position) < Math.max(0.65,(target.cfg.w||0.6)*0.75)) {
              if (target.type === "blaze") { damageEntity(target, 3); spawnParticles(e.mesh.position.x,e.mesh.position.y,e.mesh.position.z,0xc9eaff,7); SFX.tone(320,"triangle",0.12,0.12,150); }
              else spawnParticles(e.mesh.position.x,e.mesh.position.y,e.mesh.position.z,0xe8f5ff,3);
              hitMob = true; break;
            }
          }
          if (hitBlock || hitMob || e.life <= 0) { scene.remove(e.mesh); entities.splice(i,1); }
          continue;
        }
        if (e.type === "hostile_projectile") {
          e.life -= dt;
          e.mesh.position.addScaledVector(e.vel, dt);
          e.mesh.rotation.x += dt * 4;
          const blockAt = GAME.world.getBlock(e.mesh.position.x, e.mesh.position.y, e.mesh.position.z);
          const hitPlayer = e.mesh.position.distanceTo(PLAYER.pos.clone().add(new THREE.Vector3(0, 0.9, 0))) < 0.85;
          if (hitPlayer) damagePlayer(e.damage, e.kind === "dragon_breath" ? "Дыхание Дракона" : e.kind === "skeleton_arrow" ? "Стрела скелета" : "Огненный шар Ифрита");
          if (hitPlayer || BLOCK_PROPS[blockAt]?.solid || e.life <= 0) {
            if (e.kind === "dragon_breath" && hitPlayer) PLAYER.fireTicks = Math.max(PLAYER.fireTicks, 2.5);
            scene.remove(e.mesh);
            entities.splice(i, 1);
          }
          continue;
        }

        if (e.type === "arrow") {
          e.life -= dt;
          e.vel.y -= 18 * dt;
          e.mesh.position.addScaledVector(e.vel, dt);
          e.mesh.lookAt(e.mesh.position.clone().add(e.vel));
          const hitBlock = BLOCK_PROPS[GAME.world.getBlock(e.mesh.position.x, e.mesh.position.y, e.mesh.position.z)]?.solid;
          let hitMob = false;
          for (const target of entities) {
            if (target === e || target.type === "drop" || target.type === "arrow" || target.type === "thrown_eye") continue;
            // Endermen dodge ordinary arrows: the projectile passes straight through.
            if (target.type === "enderman") continue;
            const c = target.mesh.position.clone().add(new THREE.Vector3(0, target.cfg.h * 0.5, 0));
            if (c.distanceTo(e.mesh.position) < Math.max(0.8, target.cfg.w * 0.7)) {
              damageEntity(target, e.dmg);
              hitMob = true;
              break;
            }
          }
          if (hitBlock || hitMob || e.life <= 0) {
            scene.remove(e.mesh);
            entities.splice(i, 1);
          }
          continue;
        }

        if (e.attackSoundCooldown > 0) e.attackSoundCooldown = Math.max(0, e.attackSoundCooldown - dt);
        if (e.hurtTimer > 0) {
          e.hurtTimer -= dt;
          if (e.hurtTimer <= 0) {
            e.mesh.traverse(o => { if (o.isMesh && o.material?.emissive) o.material.emissive.setHex(0x000000); });
          }
        }

        if (e.type === "crystal") {
          e.mesh.rotation.y += dt * 1.5;
          continue;
        }

        if (e.type === "skeleton") {
          e.shootCooldown = (e.shootCooldown || 1.4) - dt;
          if (dist > 4 && dist < 15 && e.shootCooldown <= 0 && GAME.gamemode === "survival") {
            launchHostileProjectile(e, "skeleton_arrow");
            e.shootCooldown = 2.0 + Math.random() * 1.2;
          }
        }

        if (e.type === "blaze") {
          e.walkPhase += dt * 3;
          e.parts.rods.forEach((r) => {
            const a = r.ang + e.walkPhase;
            r.mesh.position.x = Math.cos(a) * 0.55;
            r.mesh.position.z = Math.sin(a) * 0.55;
          });
          e.shootCooldown = (e.shootCooldown || 1.2) - dt;
          const blazeDistance = e.mesh.position.distanceTo(PLAYER.pos);
          if (blazeDistance < 18 && blazeDistance > 3 && e.shootCooldown <= 0 && GAME.gamemode === "survival") {
            launchHostileProjectile(e, "fireball");
            e.shootCooldown = 2.8 + Math.random() * 1.4;
          }
        }

        if (e.type === "dragon") {
          e.timer += dt * 0.7;
          const hasCrystal = entities.some(x => x.type === "crystal");
          if (hasCrystal && e.hp < e.maxHp) e.hp = Math.min(e.maxHp, e.hp + dt * 2.5);
          document.getElementById("boss-bar-fill").style.width = `${Math.max(0, (e.hp / e.maxHp) * 100)}%`;

          const orbitX = Math.cos(e.timer) * 16;
          const orbitZ = Math.sin(e.timer) * 16;
          const targetX = PLAYER.pos.x * 0.28 + orbitX;
          const targetZ = PLAYER.pos.z * 0.28 + orbitZ;
          const ty = Math.max(28, Math.min(48, PLAYER.pos.y + 14 + Math.sin(e.timer * 2.2) * 4));
          e.mesh.position.lerp(new THREE.Vector3(targetX, ty, targetZ), dt * 1.5);
          e.mesh.rotation.y = -e.timer;
          if (e.parts.wings.length === 2) {
            const flap = Math.sin(e.timer * 8) * 0.45;
            e.parts.wings[0].rotation.z = flap;
            e.parts.wings[1].rotation.z = -flap;
          }
          e.breathCooldown = (e.breathCooldown || 3) - dt;
          if (e.breathCooldown <= 0 && e.mesh.position.distanceTo(PLAYER.pos) < 30 && GAME.gamemode === "survival") {
            launchHostileProjectile(e, "dragon_breath");
            e.breathCooldown = 4.5;
          }
          if (e.mesh.position.distanceTo(PLAYER.pos) < 4.5 && Math.random() < dt * 1.5) {
            damagePlayer(4, "Убит Драконом Края");
          }
          continue;
        }

        if (e.cfg.hostile && GAME.difficulty === "peaceful") {
          scene.remove(e.mesh);
          entities.splice(i, 1);
          continue;
        }

        const toPlayer = PLAYER.pos.clone().sub(e.mesh.position);
        toPlayer.y = 0;
        const dist = toPlayer.length();
        let moving = false;

        // Individual vanilla-inspired traits for every mob currently implemented.
        if (e.type === "zombie" && GAME.world.dimension === "overworld" && GAME.timeOfDay < 12000 && GAME.weather !== "rain") {
          const bx = Math.floor(e.mesh.position.x), by = Math.floor(e.mesh.position.y + e.cfg.h + 0.2), bz = Math.floor(e.mesh.position.z);
          const exposedToSky = GAME.world.getBlock(bx, by, bz) === B.AIR;
          e.sunBurnCooldown = (e.sunBurnCooldown || 0) - dt;
          if (exposedToSky && e.sunBurnCooldown <= 0) {
            damageEntity(e, 1);
            e.sunBurnCooldown = 1;
            spawnParticles(e.mesh.position.x,e.mesh.position.y+1.4,e.mesh.position.z,0xffa33a,2);
            if (e.hp <= 0) continue;
          }
        }

        if (e.type === "wither_skeleton" && dist < 1.8 && GAME.gamemode === "survival") {
          e.witherCooldown = (e.witherCooldown || 0) - dt;
          if (e.witherCooldown <= 0) {
            damagePlayer(2, "Иссушение от визер-скелета");
            e.witherCooldown = 1.25;
            spawnParticles(PLAYER.pos.x,PLAYER.pos.y+1,PLAYER.pos.z,0x292329,5);
          }
        }

        if (e.type === "blaze") {
          const bx=Math.floor(e.mesh.position.x), by=Math.floor(e.mesh.position.y), bz=Math.floor(e.mesh.position.z);
          const inWater=[GAME.world.getBlock(bx,by,bz),GAME.world.getBlock(bx,by+1,bz)].includes(B.WATER);
          if (inWater) {
            e.waterCooldown=(e.waterCooldown||0)-dt;
            if(e.waterCooldown<=0){damageEntity(e,2);e.waterCooldown=1;}
          }
          e.mesh.position.y += Math.sin((e.walkPhase||0)*0.4)*dt*0.35;
        }

        if (e.type === "chicken") {
          e.eggTimer = (e.eggTimer ?? (18 + Math.random()*12)) - dt;
          if (e.eggTimer <= 0) {
            spawnDrop(e.mesh.position.x,e.mesh.position.y+0.25,e.mesh.position.z,"egg",1);
            e.eggTimer = 24 + Math.random()*12;
            SFX.tone(760,"sine",0.08,0.035,680);
          }
        }

        if (e.type === "rabbit") {
          e.hopCooldown = (e.hopCooldown || Math.random()*1.5) - dt;
          if (e.hopCooldown <= 0) {
            e.hopVisual = 0.35;
            e.hopCooldown = 1.1 + Math.random()*0.8;
            e.wandAng = Math.atan2(e.mesh.position.x-PLAYER.pos.x,e.mesh.position.z-PLAYER.pos.z) + (Math.random()-0.5)*0.9;
          }
        }

        if (e.type === "sheep") {
          e.grazeCooldown = (e.grazeCooldown || 0) - dt;
          if (e.grazeCooldown <= 0) {
            const gx=Math.floor(e.mesh.position.x), gy=Math.floor(e.mesh.position.y-0.15), gz=Math.floor(e.mesh.position.z);
            if (GAME.world.getBlock(gx,gy,gz) === B.GRASS) {
              GAME.world.setBlock(gx,gy,gz,B.DIRT,true);
              spawnParticles(gx+0.5,gy+0.8,gz+0.5,0x6b9c42,4);
              e.grazeCooldown=18;
            } else e.grazeCooldown=4;
          }
        }

        if (e.cfg.passiveVillager) {
          let danger = null, dangerDist = 7;
          for (const other of entities) {
            if (!other.cfg?.hostile) continue;
            const d=other.mesh.position.distanceTo(e.mesh.position);
            if(d<dangerDist){danger=other;dangerDist=d;}
          }
          if(danger){
            const flee=new THREE.Vector3(e.mesh.position.x-danger.mesh.position.x,0,e.mesh.position.z-danger.mesh.position.z).normalize();
            e.wandAng=Math.atan2(flee.z,flee.x);
            e.timer=0.3;
            e.fleeing=true;
            moving=true;
            moveMobWithCollision(e,flee.x*2.8*dt,flee.z*2.8*dt);
          }
        }

        if (e.type === "pig") {
          const heldId=PLAYER.inv[PLAYER.hotbarIdx]?.id;
          e.luredByPlayer=["carrot","potato","beetroot"].includes(heldId) && dist<9;
          if(e.luredByPlayer){
            const lure=PLAYER.pos.clone().sub(e.mesh.position); lure.y=0;
            if(lure.lengthSq()>0.01){lure.normalize();moveMobWithCollision(e,lure.x*0.8*dt,lure.z*0.8*dt);e.mesh.rotation.y=Math.atan2(lure.x,lure.z);moving=true;}
          }
        }

        if (e.type === "creeper" && (dist < 3.2 || e.ignited) && GAME.gamemode !== "creative" && GAME.gamemode !== "spectator") {
          e.fuse = (e.fuse || 0) + dt;
          const pulse = 1 + Math.sin(e.fuse * 24) * 0.07;
          e.mesh.scale.setScalar(pulse);
          const flash = Math.sin(e.fuse * 38) > 0 ? 0xffffff : 0x8f8f8f;
          e.mesh.traverse(o => { if (o.isMesh && o.material?.color) o.material.color.setHex(flash); });
          e.hissCooldown = (e.hissCooldown || 0) - dt;
          if (e.hissCooldown <= 0) { SFX.tone(125,"sawtooth",0.16,0.045,65); e.hissCooldown = 0.32; }
          if (e.fuse >= 1.45) {
            triggerExplosion(e.mesh.position.x, e.mesh.position.y, e.mesh.position.z, 4, "Взорвался крипер");
            scene.remove(e.mesh);
            entities.splice(i, 1);
            continue;
          }
        } else if (e.type === "creeper") {
          e.fuse = 0;
          e.mesh.scale.setScalar(1);
          e.mesh.traverse(o => { if (o.isMesh && o.material?.color) o.material.color.setHex(0xffffff); });
        }
        // Endermen aggro when the player looks at their face, then teleport away.
        if (e.type === "enderman" && dist < 18 && GAME.gamemode !== "creative" && GAME.gamemode !== "spectator") {
          const eyeToMob = e.mesh.position.clone().add(new THREE.Vector3(0, 1.9, 0)).sub(getEyePos()).normalize();
          e.gazedAt = getLookDir().dot(eyeToMob) > 0.965;
          e.teleportCooldown = Math.max(0, (e.teleportCooldown || 0) - dt);
          if (e.gazedAt && e.teleportCooldown <= 0) {
            const away = PLAYER.pos.clone().sub(e.mesh.position); away.y = 0;
            if (away.lengthSq() > 0.001) away.normalize();
            const tx = e.mesh.position.x + away.x * (5 + Math.random() * 5) + (Math.random() - 0.5) * 3;
            const tz = e.mesh.position.z + away.z * (5 + Math.random() * 5) + (Math.random() - 0.5) * 3;
            const ty = GAME.world.dimension === "overworld" ? GAME.world.getSurfaceHeight(tx, tz) + 1 : e.mesh.position.y;
            spawnParticles(e.mesh.position.x, e.mesh.position.y + 1, e.mesh.position.z, 0x9b4fd4, 12);
            e.mesh.position.set(tx, ty, tz);
            spawnParticles(tx, ty + 1, tz, 0x9b4fd4, 12);
            e.teleportCooldown = 2.2 + Math.random() * 1.8;
            showBanner("Эндермен телепортировался! Не смотри ему в глаза!");
          }
        }

        if (e.cfg.hostile && dist < 18 && GAME.gamemode !== "creative" && GAME.gamemode !== "spectator") {
          toPlayer.normalize();
          const chaseSpeed = e.type === "enderman" ? (e.gazedAt ? 3.8 : 3.0) : e.type === "zombie" ? 2.15 : 2.4;
          moveMobWithCollision(e, toPlayer.x * chaseSpeed * dt, toPlayer.z * chaseSpeed * dt);
          e.mesh.rotation.y = Math.atan2(toPlayer.x, toPlayer.z);
          moving = true;
          if (dist < 1.45 && Math.random() < dt * 1.4) {
            const mult = GAME.difficulty === "hard" ? 1.5 : GAME.difficulty === "easy" ? 0.6 : 1;
            damagePlayer(Math.ceil(e.cfg.dmg * mult), `Убит мобом: ${e.cfg.name}`);
            if ((e.attackSoundCooldown || 0) <= 0) {
              const pitch = { zombie:90, skeleton:240, wither_skeleton:65, enderman:300, blaze:520, dragon:58, creeper:130 }[e.type] || 160;
              SFX.tone(pitch, "sawtooth", 0.12, 0.07, pitch * 0.7); e.attackSoundCooldown = 0.85;
            }
          }
        } else {
          if (e.cfg.passiveVillager && e.fleeing) {
            e.fleeing = false;
            moving = true;
          } else if (e.type === "pig" && e.luredByPlayer) {
            moving = true;
          } else {
            e.timer -= dt;
            if (e.timer <= 0) {
              e.timer = 2 + Math.random() * 3;
              e.wandAng = Math.random() * Math.PI * 2;
            }
            const vx = Math.cos(e.wandAng || 0) * (e.cfg.passiveVillager ? 0.5 : 0.9);
            const vz = Math.sin(e.wandAng || 0) * (e.cfg.passiveVillager ? 0.5 : 0.9);
            moveMobWithCollision(e, vx * dt, vz * dt);
            e.mesh.rotation.y = Math.atan2(vx, vz);
            moving = true;
          }
        }

        if (moving && e.parts.legs.length >= 2) {
          e.walkPhase += dt * 7;
          const s = Math.sin(e.walkPhase) * 0.55;
          e.parts.legs[0].rotation.x = s;
          e.parts.legs[1].rotation.x = -s;
          if (e.parts.legs[2]) e.parts.legs[2].rotation.x = -s;
          if (e.parts.legs[3]) e.parts.legs[3].rotation.x = s;
        }

        // Endermen take damage from water and repeatedly blink toward nearby dry ground.
        if (e.type === "enderman") {
          const mx = Math.floor(e.mesh.position.x), my = Math.floor(e.mesh.position.y + 0.5), mz = Math.floor(e.mesh.position.z);
          const wet = [GAME.world.getBlock(mx,my,mz), GAME.world.getBlock(mx,my+1,mz)].includes(B.WATER);
          if (wet) {
            e.waterDamageCooldown = (e.waterDamageCooldown || 0) - dt;
            e.waterEscapeCooldown = (e.waterEscapeCooldown || 0) - dt;
            if (e.waterDamageCooldown <= 0) { damageEntity(e, 1); e.waterDamageCooldown = 1; }
            if (e.waterEscapeCooldown <= 0) {
              for (let attempt=0; attempt<8; attempt++) {
                const tx = e.mesh.position.x + (Math.random()-0.5)*12;
                const tz = e.mesh.position.z + (Math.random()-0.5)*12;
                const ty = GAME.world.dimension === "overworld" ? GAME.world.getSurfaceHeight(tx,tz)+1 : e.mesh.position.y;
                if (GAME.world.getBlock(Math.floor(tx),Math.floor(ty),Math.floor(tz)) !== B.WATER) {
                  spawnParticles(e.mesh.position.x,e.mesh.position.y+1,e.mesh.position.z,0x9b4fd4,8);
                  e.mesh.position.set(tx,ty,tz);
                  spawnParticles(tx,ty+1,tz,0x9b4fd4,8);
                  break;
                }
              }
              e.waterEscapeCooldown = 1.2;
            }
          } else { e.waterDamageCooldown = 0; }
        }

        if (GAME.world.dimension === "overworld") {
          const surfY = GAME.world.getSurfaceHeight(e.mesh.position.x, e.mesh.position.z);
          if (surfY > 0) {
            if (e.type === "rabbit" && e.hopVisual > 0) {
              e.hopVisual = Math.max(0,e.hopVisual-dt);
              e.mesh.position.y = surfY + 1 + Math.sin((1-e.hopVisual/0.35)*Math.PI)*0.48;
            } else e.mesh.position.y = surfY + 1;
          }
        }
      }
    }

    // =========================================================================
    // 10. INVENTORY, OFF-HAND ('F'), CREATIVE CATALOG, CRAFTING & VILLAGER TRADE
    // =========================================================================
    const generatedItemIcons = new Set();
    function ensureItemIcon(id) {
      if (ATLAS.icons[id] && ATLAS.itemTextures[id]) return;
      const t = String(id).toLowerCase();
      const colors = t.includes("diamond") ? ['#4ec9ba','#1e877b','#9ef7ec'] : t.includes("gold") ? ['#e3c22b','#9c7c14','#fff28c'] : t.includes("wood") ? ['#8f7042','#5c4524','#b38f59'] : ['#c9c9c9','#858585','#f0f0f0'];
      const type = t.includes("sword") ? "sword" : t.includes("pickaxe") ? "pickaxe" : t.includes("axe") ? "axe" : t.includes("shovel") ? "shovel" : t.includes("hoe") ? "hoe" : t.includes("bow") ? "bow" : t.includes("arrow") ? "arrow" : t.includes("shield") ? "shield" : t.includes("apple") ? "apple" : t.includes("bread") ? "bread" : t.includes("beef") ? "steak" : t.includes("pork") ? "porkchop" : t.includes("chicken") ? "chicken_food" : t.includes("carrot") ? "carrot" : t.includes("potato") ? "potato" : "gem";
      const canvas = makeReferenceItemCanvas(type,...colors);
      const tex = new THREE.CanvasTexture(canvas); tex.colorSpace=THREE.SRGBColorSpace; tex.magFilter=THREE.NearestFilter; tex.minFilter=THREE.NearestMipmapNearestFilter; tex.generateMipmaps=true;
      ATLAS.icons[id]=canvas.toDataURL("image/png"); ATLAS.itemTextures[id]=tex;
    }
    function getItemInfo(id) {
      if (typeof id === "number") return { name: BLOCK_PROPS[id]?.name || "Блок", icon: ATLAS.icons[id], stack: 64 };
      ensureItemIcon(id);
      return { name: ITEMS[id]?.name || id, icon: ATLAS.icons[id], stack: ITEMS[id]?.stack || 64 };
    }

    function canAcceptDrop(id, count = 1) {
      const stackMax = getItemInfo(id).stack;
      let remaining = count;
      for (const slot of PLAYER.inv) {
        if (slot && slot.id === id) remaining -= Math.max(0, stackMax - slot.count);
        if (remaining <= 0) return true;
      }
      const emptySlots = PLAYER.inv.filter(slot => !slot).length;
      return remaining <= emptySlots * stackMax;
    }

    function giveItem(id, count = 1) {
      const info = getItemInfo(id);
      for (let i = 0; i < 36; i++) {
        const s = PLAYER.inv[i];
        if (s && s.id === id && s.count < info.stack) {
          const add = Math.min(count, info.stack - s.count);
          s.count += add;
          count -= add;
          if (count <= 0) { updateHotbarUI(); return true; }
        }
      }
      for (let i = 0; i < 36; i++) {
        if (!PLAYER.inv[i]) {
          const add = Math.min(count, info.stack);
          PLAYER.inv[i] = { id, count: add };
          count -= add;
          if (count <= 0) { updateHotbarUI(); return true; }
        }
      }
      updateHotbarUI();
      return count === 0;
    }

    function consumeHeld(amount = 1) {
      if (GAME.gamemode === "creative") return;
      const s = PLAYER.inv[PLAYER.hotbarIdx];
      if (!s) return;
      s.count -= amount;
      if (s.count <= 0) PLAYER.inv[PLAYER.hotbarIdx] = null;
      updateHotbarUI();
    }

    function swapOffhandItem() {
      const tmp = PLAYER.inv[PLAYER.hotbarIdx];
      PLAYER.inv[PLAYER.hotbarIdx] = PLAYER.offhand;
      PLAYER.offhand = tmp;
      GAME.equipAnim = 1.0;
      SFX.click();
      updateHotbarUI();
      if (GAME.state === "gui") refreshGuiGrids();
    }

    function renderSlot(slotEl, stack) {
      slotEl.innerHTML = "";
      if (!stack) return;
      const info = getItemInfo(stack.id);
      slotEl.title = `${info.name} (${stack.count})`;
      if (info.icon) {
        const img = document.createElement("img");
        img.src = info.icon;
        img.style.width = "28px";
        img.style.height = "28px";
        slotEl.appendChild(img);
      }
      if (stack.count > 1) {
        const cnt = document.createElement("span");
        cnt.className = "slot-count";
        cnt.textContent = stack.count;
        slotEl.appendChild(cnt);
      }
    }

    function updateHotbarUI() {
      const hb = document.getElementById("hotbar");
      hb.innerHTML = "";
      for (let i = 0; i < 9; i++) {
        const sl = document.createElement("div");
        sl.className = "inv-slot" + (i === PLAYER.hotbarIdx ? " active" : "");
        renderSlot(sl, PLAYER.inv[i]);
        hb.appendChild(sl);
      }
      renderSlot(document.getElementById("offhand-hud-slot"), PLAYER.offhand);

      const held = PLAYER.inv[PLAYER.hotbarIdx];
      document.getElementById("held-item-label").textContent = held ? getItemInfo(held.id).name : "";
    }

    // Creative Catalog
    let creativeCategory = "all";
    function buildCreativeCatalogList() {
      const allEntries = [];
      for (const [idStr, props] of Object.entries(BLOCK_PROPS)) {
        const id = Number(idStr);
        if ([B.AIR, B.NETHER_PORTAL, B.END_PORTAL, B.WHEAT_1, B.BED_FOOT, B.BED_HEAD].includes(id)) continue;
        allEntries.push({ id, name: props.name, cat: "blocks" });
      }
      for (const [id, info] of Object.entries(ITEMS)) {
        allEntries.push({ id, name: info.name, cat: info.cat || "misc" });
      }
      return allEntries;
    }

    function renderCreativeCatalog() {
      const grid = document.getElementById("creative-catalog-grid");
      const query = document.getElementById("creative-search").value.trim().toLowerCase();
      grid.innerHTML = "";
      const list = buildCreativeCatalogList().filter(item => {
        if (creativeCategory !== "all" && item.cat !== creativeCategory) return false;
        if (query && !item.name.toLowerCase().includes(query) && !String(item.id).toLowerCase().includes(query)) return false;
        return true;
      });
      for (const item of list) {
        const sl = document.createElement("div");
        sl.className = "inv-slot";
        const stackAmt = getItemInfo(item.id).stack;
        renderSlot(sl, { id: item.id, count: 1 });
        sl.title = `${item.name} (Клик: взять x${stackAmt})`;
        sl.onclick = e => {
          giveItem(item.id, e.shiftKey ? stackAmt : 1);
          SFX.click();
          refreshGuiGrids();
        };
        grid.appendChild(sl);
      }
    }

    let currentGuiType = null;
    let activeChestKey = null;

    function openGUI(type, contextKey = null) {
      currentGuiType = type;
      activeChestKey = contextKey;
      GAME.state = "gui";
      miningState.active = false;
      PLAYER.blockingShield = false;
      PLAYER.isPullingBow = false;
      document.exitPointerLock?.();
      document.getElementById("gui-screen").classList.remove("hidden");

      const creativePanel = document.getElementById("creative-panel");
      const survivalRow = document.getElementById("survival-gui-row");

      if (type === "inventory" && GAME.gamemode === "creative") {
        document.getElementById("gui-title").textContent = "Творческий режим — Все блоки и предметы";
        creativePanel.classList.remove("hidden");
        survivalRow.classList.add("hidden");
        renderCreativeCatalog();
        refreshGuiGrids();
        return;
      }

      creativePanel.classList.add("hidden");
      survivalRow.classList.remove("hidden");

      const titles = {
        inventory: "Инвентарь и Крафт",
        crafting: "Верстак (3x3)",
        furnace: "Печь",
        chest: "Сундук",
        trade: VILLAGER_PROFESSIONS[contextKey]?.title || "Торговля с жителем"
      };
      document.getElementById("gui-title").textContent = titles[type] || "Инвентарь";

      const mainArea = document.getElementById("gui-main-area");
      mainArea.innerHTML = "";
      const recipePanel = document.getElementById("gui-recipe-panel");

      if (type === "inventory" || type === "crafting") {
        recipePanel.classList.remove("hidden");
        const rGrid = document.getElementById("recipe-book-grid");
        rGrid.innerHTML = "";
        for (const rec of RECIPES) {
          const btn = document.createElement("div");
          btn.className = "inv-slot";
          renderSlot(btn, rec.out);
          const reqNames = Object.entries(rec.req).map(([k, v]) => `${getItemInfo(isNaN(k) ? k : Number(k)).name} x${v}`).join(", ");
          btn.title = `${getItemInfo(rec.out.id).name} x${rec.out.count}\nНужно: ${reqNames}`;
          btn.onclick = () => {
            const counts = {};
            PLAYER.inv.forEach(s => { if (s) counts[s.id] = (counts[s.id] || 0) + s.count; });
            for (const [reqId, reqCnt] of Object.entries(rec.req)) {
              if ((counts[reqId] || 0) < reqCnt) {
                SFX.hurt();
                showBanner(`Не хватает: ${reqNames}`);
                return;
              }
            }
            for (const [reqId, reqCnt] of Object.entries(rec.req)) {
              let left = reqCnt;
              for (let i = 0; i < 36 && left > 0; i++) {
                const s = PLAYER.inv[i];
                if (s && String(s.id) === String(reqId)) {
                  const take = Math.min(left, s.count);
                  s.count -= take;
                  left -= take;
                  if (s.count <= 0) PLAYER.inv[i] = null;
                }
              }
            }
            giveItem(rec.out.id, rec.out.count);
            SFX.click();
            refreshGuiGrids();
          };
          rGrid.appendChild(btn);
        }
      } else {
        recipePanel.classList.add("hidden");
      }

      if (type === "trade" && VILLAGER_PROFESSIONS[contextKey]) {
        const prof = VILLAGER_PROFESSIONS[contextKey];
        const tList = document.createElement("div");
        tList.className = "trade-list";
        for (const tr of prof.trades) {
          const row = document.createElement("div");
          row.className = "trade-row";
          const giveInfo = getItemInfo(tr.give.id);
          const getInfo = getItemInfo(tr.get.id);

          const left = document.createElement("div");
          left.style.display = "flex";
          left.style.alignItems = "center";
          left.style.gap = "8px";
          left.innerHTML = `<img src="${giveInfo.icon}" style="width:24px;height:24px;"> <span>${giveInfo.name} x${tr.give.count}</span> <b>→</b> <img src="${getInfo.icon}" style="width:24px;height:24px;"> <span>${getInfo.name} x${tr.get.count}</span>`;

          const btn = document.createElement("button");
          btn.className = "mc-btn";
          btn.style.padding = "2px 10px";
          btn.style.fontSize = "18px";
          btn.textContent = "Обменять";
          btn.onclick = () => {
            let have = 0;
            PLAYER.inv.forEach(s => { if (s && s.id === tr.give.id) have += s.count; });
            if (have < tr.give.count) {
              SFX.hurt();
              showBanner(`Нужно: ${giveInfo.name} x${tr.give.count}`);
              return;
            }
            let leftToTake = tr.give.count;
            for (let i = 0; i < 36 && leftToTake > 0; i++) {
              const s = PLAYER.inv[i];
              if (s && s.id === tr.give.id) {
                const take = Math.min(leftToTake, s.count);
                s.count -= take;
                leftToTake -= take;
                if (s.count <= 0) PLAYER.inv[i] = null;
              }
            }
            giveItem(tr.get.id, tr.get.count);
            PLAYER.xp += 10;
            updateXP();
            SFX.pickup();
            refreshGuiGrids();
          };
          row.append(left, btn);
          tList.appendChild(row);
        }
        mainArea.appendChild(tList);
      } else if (type === "furnace") {
        const box = document.createElement("div");
        box.style.display = "flex";
        box.style.flexDirection = "column";
        box.style.gap = "6px";
        box.innerHTML = `<div style="font-size:18px;">Переплавка руд, песка и булыжника при наличии угля или досок:</div>`;
        const smeltBtn = document.createElement("button");
        smeltBtn.className = "mc-btn";
        smeltBtn.textContent = "Переплавить 1 предмет из инвентаря";
        smeltBtn.onclick = () => {
          const fuelIdx = PLAYER.inv.findIndex(s => s && (s.id === "coal" || s.id === B.OAK_PLANKS || s.id === B.OAK_LOG));
          const oreIdx = PLAYER.inv.findIndex(s => s && SMELT_MAP[s.id] !== undefined);
          if (fuelIdx === -1 || oreIdx === -1) {
            showBanner("Нужно сырьё (руда/булыжник/песок) и топливо (уголь/доски)!");
            return;
          }
          const outId = SMELT_MAP[PLAYER.inv[oreIdx].id];
          PLAYER.inv[oreIdx].count--;
          if (PLAYER.inv[oreIdx].count <= 0) PLAYER.inv[oreIdx] = null;
          PLAYER.inv[fuelIdx].count--;
          if (PLAYER.inv[fuelIdx].count <= 0) PLAYER.inv[fuelIdx] = null;
          giveItem(outId, 1);
          PLAYER.xp += 8;
          updateXP();
          SFX.pickup();
          refreshGuiGrids();
        };
        box.appendChild(smeltBtn);
        mainArea.appendChild(box);
      } else if (type === "chest" && contextKey) {
        if (!GAME.world.chests.has(contextKey)) GAME.world.chests.set(contextKey, new Array(27).fill(null));
        const chestArr = GAME.world.chests.get(contextKey);
        const grid = document.createElement("div");
        grid.className = "gui-grid-9";
        for (let i = 0; i < 27; i++) {
          const sl = document.createElement("div");
          sl.className = "inv-slot";
          renderSlot(sl, chestArr[i]);
          bindInventoryCursor(sl, () => chestArr[i], value => { chestArr[i] = value; });
          grid.appendChild(sl);
        }
        mainArea.appendChild(grid);
      }

      refreshGuiGrids();
    }

    let carriedStack = null, rightDragActive = false, rightDragVisited = new Set(), leftDragState = null;
    function renderCarriedStack() {
      const el=document.getElementById("inventory-cursor-stack"); if(!el)return;
      el.innerHTML="";
      if(!carriedStack||GAME.state!=="gui"){el.style.display="none";return;}
      const info=getItemInfo(carriedStack.id);
      if(info.icon){const img=document.createElement("img");img.src=info.icon;el.appendChild(img);}
      if(carriedStack.count>1){const n=document.createElement("span");n.className="slot-count";n.textContent=carriedStack.count;el.appendChild(n);}
      el.style.display="flex";
    }
    window.addEventListener("mousemove",e=>{const el=document.getElementById("inventory-cursor-stack");if(el&&carriedStack&&GAME.state==="gui"){el.style.left=e.clientX+"px";el.style.top=e.clientY+"px";}});
    function refreshAfterInventoryClick(){if(currentGuiType==="chest"&&activeChestKey)openGUI("chest",activeChestKey);else refreshGuiGrids();updateHotbarUI();renderCarriedStack();}
    function applyInventorySlotClick(readStack,writeStack,button=0){
      const target=readStack();
      if(button===2){
        if(!carriedStack){if(!target)return;const take=Math.ceil(target.count/2);carriedStack={id:target.id,count:take};target.count-=take;writeStack(target.count>0?target:null);}
        else if(!target){writeStack({id:carriedStack.id,count:1});carriedStack.count--;if(carriedStack.count<=0)carriedStack=null;}
        else if(String(target.id)===String(carriedStack.id)&&target.count<getItemInfo(target.id).stack){target.count++;carriedStack.count--;if(carriedStack.count<=0)carriedStack=null;writeStack(target);}else return;
      }else{
        if(!carriedStack){if(!target)return;carriedStack={id:target.id,count:target.count};writeStack(null);}
        else if(!target){writeStack(carriedStack);carriedStack=null;}
        else if(String(target.id)===String(carriedStack.id)){const cap=getItemInfo(target.id).stack||64;const moved=Math.min(carriedStack.count,Math.max(0,cap-target.count));if(!moved)return;target.count+=moved;carriedStack.count-=moved;writeStack(target);if(carriedStack.count<=0)carriedStack=null;}
        else{writeStack(carriedStack);carriedStack={id:target.id,count:target.count};}
      }
      SFX.click();refreshAfterInventoryClick();
    }
    function bindInventoryCursor(el,readStack,writeStack){
      el.draggable=false;
      const placeOne=(refresh=true)=>{if(!carriedStack)return false;const target=readStack();if(!target)writeStack({id:carriedStack.id,count:1});else if(String(target.id)===String(carriedStack.id)&&target.count<getItemInfo(target.id).stack){target.count++;writeStack(target);}else return false;carriedStack.count--;if(carriedStack.count<=0)carriedStack=null;if(refresh)refreshAfterInventoryClick();return true;};
      el.addEventListener("mousedown",e=>{
        if(e.button!==0&&e.button!==2)return;
        e.preventDefault();e.stopPropagation();
        if(e.button===0&&e.detail>=2&&carriedStack){
          const wanted=carriedStack.id,cap=getItemInfo(wanted).stack||64;
          let space=Math.max(0,cap-carriedStack.count);
          for(let i=0;i<PLAYER.inv.length&&space>0;i++){
            const stack=PLAYER.inv[i];
            if(!stack||String(stack.id)!==String(wanted))continue;
            const moved=Math.min(space,stack.count);stack.count-=moved;space-=moved;carriedStack.count+=moved;
            if(stack.count<=0)PLAYER.inv[i]=null;
          }
          if(currentGuiType==="chest"&&activeChestKey){
            const chest=GAME.world.chests.get(activeChestKey);
            if(chest)for(let i=0;i<chest.length&&space>0;i++){
              const stack=chest[i];if(!stack||String(stack.id)!==String(wanted))continue;
              const moved=Math.min(space,stack.count);stack.count-=moved;space-=moved;carriedStack.count+=moved;
              if(stack.count<=0)chest[i]=null;
            }
          }
          SFX.click();refreshAfterInventoryClick();return;
        }
        if(e.button===2&&carriedStack){rightDragActive=true;rightDragVisited=new Set([el]);placeOne(false);}
        else if(e.button===0&&carriedStack){
          rightDragActive=false;
          leftDragState={source:el,moved:false,visited:new Set([el]),commit:()=>applyInventorySlotClick(readStack,writeStack,0),placeOne};
        } else {rightDragActive=false;leftDragState=null;applyInventorySlotClick(readStack,writeStack,e.button);}
      });
      el.addEventListener("mouseenter",e=>{
        if(rightDragActive&&(e.buttons&2)&&!rightDragVisited.has(el)){rightDragVisited.add(el);placeOne(false);}
        if(leftDragState&&(e.buttons&1)&&el!==leftDragState.source&&!leftDragState.visited.has(el)){
          leftDragState.visited.add(el);
          if(!leftDragState.moved){leftDragState.placeOne(false);leftDragState.moved=true;}
          placeOne(false);
          renderCarriedStack();
        }
      });
      el.addEventListener("contextmenu",e=>e.preventDefault());
;
    }
    window.addEventListener("mouseup",e=>{
      if(e.button===2){const wasDragging=rightDragActive;rightDragActive=false;rightDragVisited.clear();if(wasDragging)refreshAfterInventoryClick();}
      if(e.button===0&&leftDragState){
        const state=leftDragState;leftDragState=null;
        if(!state.moved)state.commit();
        else refreshAfterInventoryClick();
      }
    });

    function bindArmorCursor(el, key) {
      el.addEventListener("mousedown", e => {
        if (e.button !== 0 && e.button !== 2) return;
        e.preventDefault(); e.stopPropagation();
        const current = PLAYER.armor[key];
        const canEquip = item => !!ITEMS[item?.id] && ITEMS[item.id].equip === key;
        if (!carriedStack) {
          if (!current) return;
          carriedStack = current; PLAYER.armor[key] = null;
        } else if (!current) {
          if (!canEquip(carriedStack)) return;
          PLAYER.armor[key] = carriedStack; carriedStack = null;
        } else if (canEquip(carriedStack)) {
          PLAYER.armor[key] = carriedStack; carriedStack = current;
        } else return;
        refreshGuiGrids(); renderCarriedStack(); updateHUD();
      });
      el.addEventListener("contextmenu", e => e.preventDefault());
    }

    function refreshGuiGrids() {
      const bp = document.getElementById("gui-backpack");
      const hb = document.getElementById("gui-hotbar");
      const oldOffSlot = document.getElementById("gui-offhand-slot");
      const offSlot = oldOffSlot.cloneNode(false);
      oldOffSlot.replaceWith(offSlot);
      bp.innerHTML = "";
      hb.innerHTML = "";
      renderSlot(offSlot, PLAYER.offhand);
      bindInventoryCursor(offSlot, () => PLAYER.offhand, value => { PLAYER.offhand = value; });
      for (const key of ["head", "chest", "legs", "feet"]) {
        const oldSlot = document.getElementById("armor-" + key + "-slot");
        const slot = oldSlot.cloneNode(false);
        oldSlot.replaceWith(slot);
        renderSlot(slot, PLAYER.armor[key]);
        bindArmorCursor(slot, key);
      }

      const makeInvSlot = (idx) => {
        const sl = document.createElement("div");
        sl.className = "inv-slot";
        renderSlot(sl, PLAYER.inv[idx]);
        bindInventoryCursor(sl, () => PLAYER.inv[idx], value => { PLAYER.inv[idx] = value; });
        return sl;
      };

      for (let i = 9; i < 36; i++) bp.appendChild(makeInvSlot(i));
      for (let i = 0; i < 9; i++) hb.appendChild(makeInvSlot(i));
    }

    function closeGUI() {
      if (carriedStack) {
        let left = carriedStack.count;
        const cap = getItemInfo(carriedStack.id).stack || 64;
        for (let i = 0; i < 36 && left > 0; i++) {
          const s = PLAYER.inv[i];
          if (s && String(s.id) === String(carriedStack.id) && s.count < cap) {
            const moved = Math.min(left, cap - s.count); s.count += moved; left -= moved;
          }
        }
        for (let i = 0; i < 36 && left > 0; i++) if (!PLAYER.inv[i]) {
          const moved = Math.min(left, cap); PLAYER.inv[i] = { id: carriedStack.id, count: moved }; left -= moved;
        }
        if (left > 0) { carriedStack.count = left; showBanner("Освободи место в инвентаре, чтобы убрать предмет с курсора!"); return; }
        carriedStack = null; updateHotbarUI();
      }
      document.getElementById("gui-screen").classList.add("hidden");
      GAME.state = "playing";
      renderCarriedStack();
      requestLock();
    }

    // =========================================================================
    // 11. RAYCASTING, MINING, PLACING, BEDS, PORTALS & VILLAGER INTERACTION
    // =========================================================================
    let targetBlock = null;
    const miningState = { active: false, x: 0, y: 0, z: 0, progress: 0 };

    function getEyePos() {
      return new THREE.Vector3(PLAYER.pos.x, PLAYER.pos.y + (PLAYER.sneaking ? 1.32 : 1.62), PLAYER.pos.z);
    }

    function getLookDir() {
      const euler = new THREE.Euler(PLAYER.pitch, PLAYER.yaw, 0, "YXZ");
      return new THREE.Vector3(0, 0, -1).applyEuler(euler).normalize();
    }

    function findEntityUnderCrosshair(maxRange = 4.5) {
      const origin = getEyePos();
      const dir = getLookDir();
      for (const e of entities) {
        if (e.type === "drop" || e.type === "arrow" || e.type === "thrown_eye") continue;
        const center = e.mesh.position.clone().add(new THREE.Vector3(0, e.cfg.h * 0.5, 0));
        const toEnt = center.sub(origin);
        const proj = toEnt.dot(dir);
        if (proj > 0 && proj < maxRange) {
          const perp = toEnt.clone().addScaledVector(dir, -proj).length();
          if (perp < Math.max(e.cfg.w, e.cfg.h * 0.65)) return e;
        }
      }
      return null;
    }

    function updateRaycast() {
      const origin = getEyePos();
      const dir = getLookDir();
      const maxDist = GAME.gamemode === "creative" ? 6.0 : 4.8;
      let prevX = Math.floor(origin.x), prevY = Math.floor(origin.y), prevZ = Math.floor(origin.z);

      targetBlock = null;
      for (let t = 0; t <= maxDist; t += 0.05) {
        const p = origin.clone().addScaledVector(dir, t);
        const bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z);
        const id = GAME.world.getBlock(bx, by, bz);
        if (id !== B.AIR && id !== B.WATER && id !== B.LAVA) {
          targetBlock = { x: bx, y: by, z: bz, id, px: prevX, py: prevY, pz: prevZ };
          highlightBox.position.set(bx + 0.5, by + 0.5, bz + 0.5);
          highlightBox.visible = true;
          return;
        }
        prevX = bx; prevY = by; prevZ = bz;
      }
      highlightBox.visible = false;
    }

    function performLeftClickAction() {
      GAME.swingTimer = 0.24;
      const hitEnt = findEntityUnderCrosshair(4.5);
      if (hitEnt) {
        const held = PLAYER.inv[PLAYER.hotbarIdx];
        let dmg = (held && ITEMS[held.id]?.damage) ? ITEMS[held.id].damage : 2;
        if (PLAYER.effects.strength > 0) dmg += 4;
        damageEntity(hitEnt, dmg);
      }
    }

    function tickMining(dt) {
      if (!miningState.active || !targetBlock || GAME.state !== "playing") {
        miningState.progress = 0;
        updateCrackStage(0);
        return;
      }
      if (GAME.gamemode === "adventure" || GAME.gamemode === "spectator") return;

      const b = targetBlock;
      if (miningState.x !== b.x || miningState.y !== b.y || miningState.z !== b.z) {
        miningState.x = b.x; miningState.y = b.y; miningState.z = b.z;
        miningState.progress = 0;
      }

      const props = BLOCK_PROPS[b.id];
      if (!props || props.hardness < 0) return;

      if (GAME.gamemode === "creative") {
        spawnParticles(b.x + 0.5, b.y + 0.5, b.z + 0.5, b.id, 8);
        GAME.world.setBlock(b.x, b.y, b.z, B.AIR, true);
        SFX.breakBlock(props.mat);
        miningState.progress = 0;
        return;
      }

      const held = PLAYER.inv[PLAYER.hotbarIdx];
      const toolInfo = held ? ITEMS[held.id] : null;
      let speedMult = 1.0;
      if (props.tool && toolInfo?.tool === props.tool) speedMult = toolInfo.speed;
      else if (props.mat === "wood" && toolInfo?.tool === "axe") speedMult = toolInfo.speed;

      const breakTime = Math.max(0.08, (props.hardness * 1.35) / speedMult);
      miningState.progress += dt / breakTime;
      GAME.swingTimer = 0.2;
      crackMesh.position.set(b.x + 0.5, b.y + 0.5, b.z + 0.5);
      updateCrackStage(Math.min(10, Math.floor(miningState.progress * 10)));

      if (miningState.progress >= 1.0) {
        SFX.breakBlock(props.mat);
        spawnParticles(b.x + 0.5, b.y + 0.5, b.z + 0.5, b.id, 8);
        GAME.world.setBlock(b.x, b.y, b.z, B.AIR, true);
        miningState.progress = 0;
        updateCrackStage(0);

        const canHarvest = !props.minTier || (toolInfo?.tool === props.tool && toolInfo.tier >= props.minTier);
        if (canHarvest && props.drop) {
          if (props.drop === "apple_chance") {
            if (Math.random() < 0.22) spawnDrop(b.x + 0.5, b.y + 0.5, b.z + 0.5, "apple", 1);
          } else {
            spawnDrop(b.x + 0.5, b.y + 0.5, b.z + 0.5, props.drop, 1);
          }
        }
      }
    }

    function triggerExplosion(cx, cy, cz, radius = 4, reason = "Взорвался") {
      SFX.explode();
      spawnParticles(cx, cy + 1, cz, 0xd96826, 28);
      for (let dx = -radius; dx <= radius; dx++) {
        for (let dy = -radius; dy <= radius; dy++) {
          for (let dz = -radius; dz <= radius; dz++) {
            if (dx * dx + dy * dy + dz * dz <= radius * radius) {
              const id = GAME.world.getBlock(cx + dx, cy + dy, cz + dz);
              if (id !== B.AIR && id !== B.BEDROCK && (BLOCK_PROPS[id]?.blastResistance || 0) < radius * 10) {
                GAME.world.setBlock(cx + dx, cy + dy, cz + dz, B.AIR, true);
              }
            }
          }
        }
      }
      const dist = PLAYER.pos.distanceTo(new THREE.Vector3(cx, cy, cz));
      if (dist < radius + 3) {
        damagePlayer(Math.max(4, Math.round((radius + 3 - dist) * 4)), reason, true);
      }
    }

    function useBedAt(bx, by, bz) {
      if (GAME.world.dimension !== "overworld") {
        triggerExplosion(bx, by, bz, 5, "Убит [Преднамеренным игровым дизайном]");
        return;
      }
      PLAYER.spawnPos = { dim: "overworld", x: bx + 0.5, y: by + 1.05, z: bz + 0.5 };
      showBanner("Точка возрождения установлена!");
      addChatLine("Точка возрождения установлена.", "#c8c4a0");

      const isNight = GAME.timeOfDay >= 12000 && GAME.timeOfDay <= 23500;
      if (isNight) {
        const fade = document.getElementById("sleep-fade");
        fade.style.opacity = "0.95";
        setTimeout(() => {
          GAME.timeOfDay = 500;
          GAME.dayCount++;
          GAME.weather = "clear";
          PLAYER.health = Math.min(20, PLAYER.health + 4);
          updateEnvironment(0);
          updateHUD();
          fade.style.opacity = "0";
          showBanner("Доброе утро! Наступил новый день.");
        }, 650);
      }
    }

    function tryIgniteNetherPortal(x, y, z) {
      for (const axis of ["x", "z"]) {
        let minY = y;
        while (minY > 1 && GAME.world.getBlock(x, minY - 1, z) === B.AIR) minY--;
        if (GAME.world.getBlock(x, minY - 1, z) === B.OBSIDIAN && GAME.world.getBlock(x, minY + 3, z) === B.OBSIDIAN) {
          for (let dy = 0; dy < 3; dy++) {
            GAME.world.setBlock(x, minY + dy, z, B.NETHER_PORTAL, true);
            if (axis === "x" && GAME.world.getBlock(x + 1, minY + dy, z) === B.AIR) GAME.world.setBlock(x + 1, minY + dy, z, B.NETHER_PORTAL, true);
            if (axis === "z" && GAME.world.getBlock(x, minY + dy, z + 1) === B.AIR) GAME.world.setBlock(x, minY + dy, z + 1, B.NETHER_PORTAL, true);
          }
          SFX.levelUp();
          showBanner("Портал в Нижний мир активирован!");
          return true;
        }
      }
      return false;
    }

    function performRightClickDown() {
      const held = PLAYER.inv[PLAYER.hotbarIdx];
      const off = PLAYER.offhand;

      // 1. Villager trading and milking cows.
      const hitEnt = findEntityUnderCrosshair(4.2);
      // Flint and steel can prime a creeper directly, just like lighting TNT.
      if (held?.id === "snowball") {
        const start = getEyePos().add(getLookDir().multiplyScalar(0.7));
        const velocity = getLookDir().multiplyScalar(17); velocity.y += 1.2;
        const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), new THREE.MeshBasicMaterial({ color: 0xf2fbff }));
        mesh.position.copy(start); scene.add(mesh);
        entities.push({ type: "thrown_snowball", mesh, vel: velocity, life: 2.2 });
        if (GAME.gamemode !== "creative") consumeHeld(1);
        SFX.tone(690, "sine", 0.06, 0.07, 430); return;
      }
      if (hitEnt?.type === "creeper" && held?.id === "flint_and_steel") {
        hitEnt.ignited = true;
        hitEnt.fuse = Math.max(hitEnt.fuse || 0, 1.0);
        showBanner("Крипер подожжён! Беги!");
        SFX.tone(520, "square", 0.12, 0.18, 180);
        return;
      }
      // Spawn eggs place the matching mob on the targeted surface.
      if (held && ITEMS[held.id] && ITEMS[held.id].spawnMob) {
        const mobType = ITEMS[held.id].spawnMob;
        const dir = getLookDir();
        const sx = targetBlock ? targetBlock.x + 0.5 : PLAYER.pos.x + dir.x * 2.5;
        const sz = targetBlock ? targetBlock.z + 0.5 : PLAYER.pos.z + dir.z * 2.5;
        const sy = targetBlock ? targetBlock.y + 1 : Math.max(1, GAME.world.getSurfaceHeight(sx, sz) + 1);
        const spawned = spawnMob(mobType, sx, sy, sz);
        if (spawned) {
          if (GAME.gamemode !== "creative") consumeHeld(1);
          showBanner("Появился моб: " + spawned.cfg.name);
          SFX.pickup();
        } else showBanner("Это существо нельзя призвать в текущем режиме");
        return;
      }
      if (hitEnt?.type === "cow" && held?.id === "bucket") {
        giveItem("milk_bucket", 1);
        if (GAME.gamemode !== "creative") consumeHeld(1);
        showBanner("Ты надоил ведро молока!");
        SFX.pickup();
        return;
      }
      if (hitEnt && hitEnt.cfg.passiveVillager) {
        openGUI("trade", hitEnt.cfg.passiveVillager);
        return;
      }

      // Right-click equips armor directly from the selected hotbar slot.
      if (held && ITEMS[held.id]?.equip) {
        const slot = ITEMS[held.id].equip;
        const previous = PLAYER.armor[slot];
        PLAYER.armor[slot] = { id: held.id, count: 1 };
        if (previous && !giveItem(previous.id, 1)) spawnDrop(PLAYER.pos.x, PLAYER.pos.y + 1, PLAYER.pos.z, previous.id, 1);
        if (GAME.gamemode !== "creative") consumeHeld(1);
        updateHUD(); SFX.click();
        return;
      }

      // Fishing: cast into real water and reel in only after a bite.
      if (held?.id === "fishing_rod") {
        if (GAME.fishing?.active) {
          const fishing = GAME.fishing;
          if (fishing.bite) {
            const catchTable = ["raw_fish","raw_fish","raw_salmon","clownfish","pufferfish","string","bow"];
            const caught = catchTable[Math.floor(Math.random() * catchTable.length)];
            giveItem(caught, 1);
            showBanner(`Поймано: ${ITEMS[caught]?.name || caught}`);
            SFX.pickup();
          } else showBanner("Рыба сорвалась с крючка!");
          if (fishing.mesh) scene.remove(fishing.mesh);
          GAME.fishing = null;
        } else {
          const dir = getLookDir();
          let waterPoint = null;
          for (let d = 1.5; d <= 12; d += 0.5) {
            const px = PLAYER.pos.x + dir.x * d, py = PLAYER.pos.y + 1.1 + dir.y * d, pz = PLAYER.pos.z + dir.z * d;
            if (GAME.world.getBlock(px, py, pz) === B.WATER) { waterPoint = new THREE.Vector3(px, py, pz); break; }
          }
          if (!waterPoint) { showBanner("Для рыбалки направь удочку в воду!"); return; }
          const bobber = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), new THREE.MeshLambertMaterial({ color: 0xe34b37 }));
          bobber.position.copy(waterPoint).add(new THREE.Vector3(0, 0.12, 0)); scene.add(bobber);
          GAME.fishing = { active: true, bite: false, timer: 2.5 + Math.random() * 5.5, mesh: bobber, point: waterPoint };
          showBanner("Поплавок заброшен... жди поклёвки!");
        }
        return;
      }

      // Main-hand actions take priority over off-hand shield blocking.
      if (held?.id === "ender_pearl") {
        launchEnderPearl();
        return;
      }

      // 3. Bow Drawing
      if (held?.id === "bow") {
        const hasArrows = GAME.gamemode === "creative" || PLAYER.inv.some(s => s && s.id === "arrow") || off?.id === "arrow";
        if (!hasArrows) {
          showBanner("Нет стрел для лука!");
          return;
        }
        PLAYER.isPullingBow = true;
        PLAYER.bowPullTime = 0;
        return;
      }

      // 4. Eating Food
      if (held && ITEMS[held.id]?.food && (PLAYER.hunger < 20 || held.id === "golden_apple")) {
        PLAYER.eatTimer = 0.62;
        GAME.swingTimer = 0.3;
        PLAYER.eatTimer = 0.62;
        GAME.swingTimer = 0.3;
        PLAYER.hunger = Math.min(20, PLAYER.hunger + ITEMS[held.id].food);
        if (held.id === "golden_apple") PLAYER.health = Math.min(20, PLAYER.health + 8);
        consumeHeld(1);
        SFX.pickup();
        updateHUD();
        return;
      }

      // 5. Launch Flying Eye of Ender (unless aiming at an empty End Portal Frame)
      if (held && held.id === "ender_eye" && (!targetBlock || targetBlock.id !== B.END_PORTAL_FRAME)) {
        launchEyeOfEnder();
        return;
      }

      // Shield blocking is only the fallback when the main hand has no usable item.
      if ((!held || held.id === "shield") && (held?.id === "shield" || off?.id === "shield") && (!targetBlock || !BLOCK_PROPS[targetBlock.id]?.interactive)) {
        PLAYER.blockingShield = true;
        return;
      }

      if (!targetBlock) return;
      const b = targetBlock;
      const props = BLOCK_PROPS[b.id];

      // 6. Interactive Blocks (Crafting, Furnace, Chest, Bed)
      if (props?.interactive === "bed") {
        useBedAt(b.x, b.y, b.z);
        return;
      }
      if (props?.interactive && !PLAYER.sneaking) {
        openGUI(props.interactive, `${GAME.world.dimension}:${b.x},${b.y},${b.z}`);
        return;
      }

      // 7. Insert Eye of Ender into End Portal Frame & Check Ring Activation!
      if (b.id === B.END_PORTAL_FRAME && held?.id === "ender_eye") {
        GAME.world.setBlock(b.x, b.y, b.z, B.END_PORTAL_FRAME_EYE, true);
        consumeHeld(1);
        SFX.pickup();
        GAME.world.checkAndActivateEndPortalAround(b.x, b.y, b.z);
        return;
      }

      if (!held) return;

      // 8. Place 2-Block Bed
      if (held.id === "bed") {
        const dir = getLookDir();
        const hx = Math.abs(dir.x) > Math.abs(dir.z) ? Math.sign(dir.x) : 0;
        const hz = Math.abs(dir.z) >= Math.abs(dir.x) ? Math.sign(dir.z) : 0;
        if (GAME.world.getBlock(b.px + hx, b.py, b.pz + hz) === B.AIR) {
          GAME.world.setBlock(b.px, b.py, b.pz, B.BED_FOOT, true);
          GAME.world.setBlock(b.px + hx, b.py, b.pz + hz, B.BED_HEAD, true);
          SFX.placeBlock();
          GAME.swingTimer = 0.2;
          consumeHeld(1);
        }
        return;
      }

      if (ITEMS[held.id]?.tool === "hoe" && (b.id === B.GRASS || b.id === B.DIRT)) {
        GAME.world.setBlock(b.x, b.y, b.z, B.FARMLAND, true);
        SFX.placeBlock();
        return;
      }

      if (held.id === "flint_and_steel") {
        if (b.id === B.TNT) {
          GAME.world.setBlock(b.x, b.y, b.z, B.AIR, true);
          triggerExplosion(b.x, b.y, b.z, 4, "Взорвался блок TNT");
        } else {
          tryIgniteNetherPortal(b.px, b.py, b.pz);
        }
        return;
      }

      if (held.id === "bucket_water") {
        GAME.world.setBlock(b.px, b.py, b.pz, B.WATER, true);
        SFX.placeBlock();
        return;
      }

      if (held.id === "bucket_lava") {
        GAME.world.setBlock(b.px, b.py, b.pz, B.LAVA, true);
        SFX.placeBlock();
        return;
      }

      if (typeof held.id === "number" && GAME.gamemode !== "adventure" && GAME.gamemode !== "spectator") {
        const px = b.px, py = b.py, pz = b.pz;
        const pMinX = PLAYER.pos.x - 0.28, pMaxX = PLAYER.pos.x + 0.28;
        const pMinY = PLAYER.pos.y, pMaxY = PLAYER.pos.y + 1.78;
        const pMinZ = PLAYER.pos.z - 0.28, pMaxZ = PLAYER.pos.z + 0.28;
        const overlapsPlayer = (px + 1 > pMinX && px < pMaxX) && (py + 1 > pMinY && py < pMaxY) && (pz + 1 > pMinZ && pz < pMaxZ);
        if (overlapsPlayer && BLOCK_PROPS[held.id]?.solid) return;

        GAME.world.setBlock(px, py, pz, held.id, true);
        SFX.placeBlock();
        GAME.swingTimer = 0.2;
        consumeHeld(1);

        if (held.id === B.END_PORTAL_FRAME_EYE) {
          GAME.world.checkAndActivateEndPortalAround(px, py, pz);
        }
      }
    }

    function performRightClickUp() {
      PLAYER.blockingShield = false;
      if (PLAYER.isPullingBow) {
        const charge = Math.min(1.0, PLAYER.bowPullTime / 0.85);
        PLAYER.isPullingBow = false;
        PLAYER.bowPullTime = 0;
        if (charge > 0.15) {
          if (GAME.gamemode !== "creative") {
            const arrIdx = PLAYER.inv.findIndex(s => s && s.id === "arrow");
            if (arrIdx !== -1) {
              PLAYER.inv[arrIdx].count--;
              if (PLAYER.inv[arrIdx].count <= 0) PLAYER.inv[arrIdx] = null;
            } else if (PLAYER.offhand?.id === "arrow") {
              PLAYER.offhand.count--;
              if (PLAYER.offhand.count <= 0) PLAYER.offhand = null;
            }
            updateHotbarUI();
          }
          shootArrow(charge);
        }
      }
    }

    // =========================================================================
    // 12. PLAYER PHYSICS, ANTI-STUCK COLLISIONS & DIMENSION SWITCHING
    // =========================================================================
    const keys = {};
    let lastWPress = 0, lastSpacePress = 0, doubleWSprint = false;

    function collidesAt(pos) {
      if (GAME.gamemode === "spectator") return false;
      const hw = 0.28, h = PLAYER.sneaking ? 1.48 : 1.78;
      const minX = Math.floor(pos.x - hw), maxX = Math.floor(pos.x + hw);
      const minY = Math.floor(pos.y + 0.02), maxY = Math.floor(pos.y + h);
      const minZ = Math.floor(pos.z - hw), maxZ = Math.floor(pos.z + hw);
      for (let x = minX; x <= maxX; x++) {
        for (let y = minY; y <= maxY; y++) {
          for (let z = minZ; z <= maxZ; z++) {
            if (BLOCK_PROPS[GAME.world.getBlock(x, y, z)]?.solid) return true;
          }
        }
      }
      return false;
    }

    function resolveStuckInBlocks() {
      if (!GAME.world || GAME.gamemode === "spectator") return;
      if (!collidesAt(PLAYER.pos)) return;
      for (let step = 0.1; step <= 3.0; step += 0.1) {
        const up = PLAYER.pos.clone();
        up.y += step;
        if (!collidesAt(up)) {
          PLAYER.pos.y = up.y;
          PLAYER.vel.y = Math.max(0, PLAYER.vel.y);
          return;
        }
      }
    }

    function damagePlayer(amount, reason = "Получен урон", bypassShield = false) {
      if (GAME.gamemode === "creative" || GAME.gamemode === "spectator") return;
      if (PLAYER.invulnTimer > 0) return;

      if (PLAYER.blockingShield && !bypassShield) {
        PLAYER.invulnTimer = 0.45;
        SFX.shieldBlock();
        showBanner("Удар заблокирован щитом!");
        return;
      }

      const armorValue = Object.values(PLAYER.armor || {}).reduce((sum, stack) => sum + (stack ? (ITEMS[stack.id]?.armor || 0) : 0), 0);
      const toughness = Object.values(PLAYER.armor || {}).reduce((sum, stack) => sum + (stack ? (ITEMS[stack.id]?.toughness || 0) : 0), 0);
      amount *= 1 - Math.min(0.8, armorValue * 0.04 + Math.min(0.12, toughness * 0.015));
      PLAYER.invulnTimer = 0.55;
      PLAYER.health = Math.max(0, PLAYER.health - amount);
      SFX.hurt();
      updateHUD();

      if (PLAYER.health <= 0) {
        GAME.state = "dead";
        PLAYER.blockingShield = false;
        PLAYER.isPullingBow = false;
        document.exitPointerLock?.();
        document.getElementById("death-reason").textContent = reason;
        if (!GAME.keepInventory) {
          for (let i = 0; i < 36; i++) {
            if (PLAYER.inv[i]) {
              spawnDrop(PLAYER.pos.x, PLAYER.pos.y + 0.5, PLAYER.pos.z, PLAYER.inv[i].id, PLAYER.inv[i].count);
              PLAYER.inv[i] = null;
            }
          }
          if (PLAYER.offhand) {
            spawnDrop(PLAYER.pos.x, PLAYER.pos.y + 0.5, PLAYER.pos.z, PLAYER.offhand.id, PLAYER.offhand.count);
            PLAYER.offhand = null;
          }          for (const key of ["head", "chest", "legs", "feet"]) {
            const armorStack = PLAYER.armor[key];
            if (armorStack) {
              spawnDrop(PLAYER.pos.x, PLAYER.pos.y + 0.5, PLAYER.pos.z, armorStack.id, armorStack.count);
              PLAYER.armor[key] = null;
            }
          }
          PLAYER.xp = 0;
          PLAYER.level = 0;
          updateHotbarUI();
          document.getElementById("death-keep-status").textContent = "KeepInventory ВЫКЛ: предметы выпали на месте смерти.";
        } else {
          document.getElementById("death-keep-status").textContent = "KeepInventory ВКЛ: инвентарь и опыт сохранены!";
        }
        document.getElementById("death-screen").classList.remove("hidden");
      }
    }

    function switchDimension(newDim) {
      clearAllEntities();
      GAME.world.clearAllMeshes();
      GAME.world.dimension = newDim;

      if (newDim === "nether") {
        // Safe arrival point; build the fortress roughly 200 blocks away.
        PLAYER.pos.set(0.5, 23, 0.5);
        const fortressX = 200, fortressZ = 0;
        for (let dx = -4; dx <= 4; dx++) {
          for (let dz = -4; dz <= 24; dz++) {
            GAME.world.setBlockRaw(fortressX + dx, 21, fortressZ + dz, B.NETHER_BRICKS);
            for (let dy = 1; dy <= 6; dy++) GAME.world.setBlockRaw(fortressX + dx, 21 + dy, fortressZ + dz, B.AIR);
            if (Math.abs(dx) === 4) GAME.world.setBlockRaw(fortressX + dx, 22, fortressZ + dz, B.NETHER_BRICKS);
          }
        }
        spawnMob("blaze", fortressX + 2, 22, fortressZ + 7);
        spawnMob("blaze", fortressX - 2, 22, fortressZ + 12);
        spawnMob("blaze", fortressX, 22, fortressZ + 18);
        spawnMob("wither_skeleton", fortressX - 2, 22, fortressZ + 8);
        spawnMob("wither_skeleton", fortressX + 2, 22, fortressZ + 14);
        showBanner("Нижний мир! Крепость находится примерно в 200 блоках от портала.");
      } else if (newDim === "end") {
        PLAYER.pos.set(0.5, 34, 14.5);
        for (const [px, pz] of [[22, 0], [-22, 0], [0, 22], [0, -22], [16, 16], [-16, 16], [16, -16], [-16, -16]]) {
          for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
            for (let y = 28; y <= 42; y++) GAME.world.setBlockRaw(px + dx, y, pz + dz, (Math.abs(dx) === 1 || Math.abs(dz) === 1) ? B.OBSIDIAN : B.OBSIDIAN);
          }
          for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) GAME.world.setBlockRaw(px + dx, 43, pz + dz, B.OBSIDIAN);
          spawnMob("crystal", px + 0.5, 44, pz + 0.5);
        }
        spawnMob("dragon", 0, 42, 0);
        showBanner("КРАЙ! Уничтожьте Кристаллы Края на башнях и победите Дракона!");
      } else {
        PLAYER.pos.set(PLAYER.spawnPos.x, PLAYER.spawnPos.y, PLAYER.spawnPos.z);
        showBanner("Верхний мир");
      }
      PLAYER.vel.set(0, 0, 0);
      updateChunksAroundPlayer(true);
      resolveStuckInBlocks();
      updateHUD();
    }

    function tickPlayerPhysics(dt) {
      if (!GAME.world || GAME.state !== "playing") return;
      if (PLAYER.invulnTimer > 0) PLAYER.invulnTimer -= dt;
      if (PLAYER.isPullingBow) PLAYER.bowPullTime += dt;

      resolveStuckInBlocks();

      for (const k of Object.keys(PLAYER.effects)) {
        if (PLAYER.effects[k] > 0) PLAYER.effects[k] = Math.max(0, PLAYER.effects[k] - dt);
      }

      const feetBlock = GAME.world.getBlock(PLAYER.pos.x, PLAYER.pos.y + 0.1, PLAYER.pos.z);
      const headBlock = GAME.world.getBlock(PLAYER.pos.x, PLAYER.pos.y + 1.5, PLAYER.pos.z);
      PLAYER.inWater = feetBlock === B.WATER || headBlock === B.WATER;
      PLAYER.inLava = feetBlock === B.LAVA || headBlock === B.LAVA;

      if (feetBlock === B.NETHER_PORTAL) {
        GAME.portalTimer += dt;
        if (GAME.portalTimer >= 1.5) {
          GAME.portalTimer = 0;
          switchDimension(GAME.world.dimension === "nether" ? "overworld" : "nether");
          return;
        }
      } else if (feetBlock === B.END_PORTAL) {
        GAME.portalTimer = 0;
        switchDimension("end");
        return;
      } else {
        GAME.portalTimer = 0;
      }

      if (headBlock === B.WATER && GAME.gamemode === "survival") {
        PLAYER.air = Math.max(0, PLAYER.air - dt * 30);
        if (PLAYER.air <= 0 && Math.random() < dt * 1.2) damagePlayer(2, "Утонул", true);
      } else {
        PLAYER.air = Math.min(300, PLAYER.air + dt * 90);
      }

      if (PLAYER.inLava) PLAYER.fireTicks = 5;
      if (PLAYER.inWater) PLAYER.fireTicks = 0;
      if (PLAYER.fireTicks > 0) {
        PLAYER.fireTicks -= dt;
        document.getElementById("fire-overlay").classList.remove("hidden");
        if (Math.random() < dt * 1.1) damagePlayer(1, "Сгорел в огне", true);
      } else {
        document.getElementById("fire-overlay").classList.add("hidden");
      }

      if (GAME.difficulty === "peaceful" && PLAYER.health < 20 && Math.random() < dt * 2) {
        PLAYER.health = Math.min(20, PLAYER.health + 1);
      }

      // Survival hunger and natural regeneration.
      if (GAME.gamemode === "survival" && GAME.difficulty !== "peaceful") {
        const moving = keys["KeyW"] || keys["KeyA"] || keys["KeyS"] || keys["KeyD"];
        // Exhaustion: make hunger loss noticeable during normal play.
        PLAYER.hungerTick += dt * (PLAYER.sprinting && moving ? 2.4 : moving ? 0.8 : 0.08);
        if (PLAYER.hungerTick >= 12) {
          PLAYER.hungerTick -= 12;
          PLAYER.hunger = Math.max(0, PLAYER.hunger - 1);
          updateHUD();
        }
        if (PLAYER.hunger >= 18 && PLAYER.health < PLAYER.maxHealth) {
          PLAYER.regenTick += dt;
          if (PLAYER.regenTick >= 4) {
            PLAYER.regenTick = 0;
            PLAYER.health = Math.min(PLAYER.maxHealth, PLAYER.health + 1);
            updateHUD();
          }
        } else if (PLAYER.hunger > 0) {
          PLAYER.regenTick = 0;
        }
        if (PLAYER.hunger <= 0) {
          PLAYER.regenTick += dt;
          if (PLAYER.regenTick >= 4) {
            PLAYER.regenTick = 0;
            if (PLAYER.health > 1) damagePlayer(1, "Истощение", true);
          }
        }
      }

      let forward = 0, strafe = 0;
      if (keys["KeyW"]) forward += 1;
      if (keys["KeyS"]) forward -= 1;
      if (keys["KeyA"]) strafe -= 1;
      if (keys["KeyD"]) strafe += 1;

      if (forward <= 0) doubleWSprint = false;
      PLAYER.sneaking = !!(keys["ShiftLeft"] || keys["ShiftRight"]);
      PLAYER.sprinting = !!((keys["ControlLeft"] || keys["ControlRight"] || doubleWSprint) && forward > 0 && !PLAYER.sneaking && !PLAYER.blockingShield && !PLAYER.isPullingBow);

      let moveSpeed = (PLAYER.sneaking || PLAYER.blockingShield || PLAYER.isPullingBow) ? 2.1 : PLAYER.sprinting ? 6.4 : 4.4;
      if (PLAYER.flying) moveSpeed *= 1.8;
      if (PLAYER.effects.speed > 0) moveSpeed *= 1.45;

      const sin = Math.sin(PLAYER.yaw);
      const cos = Math.cos(PLAYER.yaw);
      const wishX = (-sin * forward + cos * strafe);
      const wishZ = (-cos * forward - sin * strafe);
      const len = Math.hypot(wishX, wishZ);
      const nx = len > 0 ? wishX / len : 0;
      const nz = len > 0 ? wishZ / len : 0;

      PLAYER.vel.x = nx * moveSpeed;
      PLAYER.vel.z = nz * moveSpeed;

      if (PLAYER.flying || GAME.gamemode === "spectator") {
        PLAYER.vel.y = 0;
        if (keys["Space"]) PLAYER.vel.y = 7.5;
        if (PLAYER.sneaking) PLAYER.vel.y = -7.5;
      } else if (PLAYER.inWater) {
        PLAYER.vel.y = Math.max(-3.0, PLAYER.vel.y - 8 * dt);
        if (keys["Space"]) PLAYER.vel.y = 4.2;
      } else {
        const gliding = PLAYER.armor.chest?.id === "elytra" && !PLAYER.onGround && PLAYER.pos.y > 4 && keys["Space"];
        PLAYER.vel.y -= (gliding ? 4.2 : 26) * dt;
        if (gliding) {
          const forward = new THREE.Vector3(-Math.sin(PLAYER.yaw), 0, -Math.cos(PLAYER.yaw));
          PLAYER.vel.x += forward.x * 5.5 * dt;
          PLAYER.vel.z += forward.z * 5.5 * dt;
          PLAYER.vel.y = Math.max(PLAYER.vel.y, -3.2);
        }
        if (keys["Space"] && PLAYER.onGround) {
          PLAYER.vel.y = PLAYER.effects.jump > 0 ? 11.5 : 8.4;
          PLAYER.fallStartY = PLAYER.pos.y;
          PLAYER.onGround = false;
          const under = GAME.world.getBlock(PLAYER.pos.x, PLAYER.pos.y - 0.2, PLAYER.pos.z);
          if (under === B.FARMLAND) {
            GAME.world.setBlock(PLAYER.pos.x, PLAYER.pos.y - 0.2, PLAYER.pos.z, B.DIRT, true);
            SFX.breakBlock("grass");
          }
        }
      }

      const nextX = PLAYER.pos.clone();
      nextX.x += PLAYER.vel.x * dt;
      if (!collidesAt(nextX)) {
        if (!(PLAYER.sneaking && PLAYER.onGround && !PLAYER.flying && !collidesAt(nextX.clone().add(new THREE.Vector3(0, -0.6, 0))))) {
          PLAYER.pos.x = nextX.x;
        }
      }

      const nextZ = PLAYER.pos.clone();
      nextZ.z += PLAYER.vel.z * dt;
      if (!collidesAt(nextZ)) {
        if (!(PLAYER.sneaking && PLAYER.onGround && !PLAYER.flying && !collidesAt(nextZ.clone().add(new THREE.Vector3(0, -0.6, 0))))) {
          PLAYER.pos.z = nextZ.z;
        }
      }

      const prevY = PLAYER.pos.y;
      PLAYER.pos.y += PLAYER.vel.y * dt;
      if (collidesAt(PLAYER.pos)) {
        PLAYER.pos.y = prevY;
        if (PLAYER.vel.y < 0) {
          if (!PLAYER.onGround && PLAYER.fallStartY !== null && !PLAYER.inWater && !PLAYER.flying) {
            const fallDist = Math.max(0, PLAYER.fallStartY - PLAYER.pos.y);
            if (fallDist > 3.0) damagePlayer(Math.max(1, Math.ceil(fallDist - 3.0)), "Разбился насмерть", true);
          }
          PLAYER.onGround = true;
          PLAYER.fallStartY = null;
        }
        PLAYER.vel.y = 0;
      } else {
        // Track the highest point of a fall, including after a jump apex.
        if (PLAYER.vel.y < 0) {
          if (PLAYER.fallStartY === null) PLAYER.fallStartY = PLAYER.pos.y;
          else PLAYER.fallStartY = Math.max(PLAYER.fallStartY, PLAYER.pos.y);
        }
        PLAYER.onGround = false;
      }

      if (PLAYER.pos.y < -15) damagePlayer(20, "Выпал из мира", true);

      const horiz = Math.hypot(PLAYER.vel.x, PLAYER.vel.z);
      if (horiz > 0.2 && PLAYER.onGround) {
        PLAYER.bobTimer += dt * (PLAYER.sprinting ? 13 : 9);
        PLAYER.stepDist += horiz * dt;
        if (PLAYER.stepDist >= 2.3) {
          PLAYER.stepDist = 0;
          const bUnder = GAME.world.getBlock(PLAYER.pos.x, PLAYER.pos.y - 0.2, PLAYER.pos.z);
          SFX.step(BLOCK_PROPS[bUnder]?.mat || "grass");
        }
      }
    }

    // =========================================================================
    // 13. ENVIRONMENT, CAMERA, BOW/SHIELD/TOOL VIEWMODEL ANIMATIONS
    // =========================================================================
    function updateEnvironment(dt) {
      if (GAME.doDaylightCycle && GAME.state === "playing") {
        GAME.timeOfDay = (GAME.timeOfDay + dt * 20) % 24000;
        if (GAME.timeOfDay < dt * 20) GAME.dayCount++;
      }

      cloudGroup.children.forEach(c => {
        c.position.x += dt * 0.8;
        if (c.position.x > 120) c.position.x = -120;
      });

      if (GAME.weather === "rain" && GAME.world?.dimension === "overworld") {
        rainDrops.forEach((drop, idx) => {
          drop.visible = true;
          drop.position.y -= dt * 22;
          if (drop.position.y < PLAYER.pos.y - 4 || drop.position.distanceTo(PLAYER.pos) > 22) {
            drop.position.set(
              PLAYER.pos.x + ((idx * 17) % 26) - 13,
              PLAYER.pos.y + 10 + (idx % 8),
              PLAYER.pos.z + ((idx * 23) % 26) - 13
            );
          }
        });
      } else {
        rainDrops.forEach(d => { d.visible = false; });
      }

      const dim = GAME.world?.dimension || "overworld";
      if (dim === "nether") {
        scene.background.setHex(0x361010);
        scene.fog.color.setHex(0x361010);
        ambientLight.intensity = 0.72;
        sunLight.intensity = 0.35;
        sunMesh.visible = false;
        moonMesh.visible = false;
        return;
      }
      if (dim === "end") {
        scene.background.setHex(0x0c0914);
        scene.fog.color.setHex(0x0c0914);
        ambientLight.intensity = 0.65;
        sunLight.intensity = 0.4;
        sunMesh.visible = false;
        moonMesh.visible = false;
        return;
      }

      const angle = (GAME.timeOfDay / 24000) * Math.PI * 2;
      const sunY = Math.sin(angle);
      const sunX = Math.cos(angle);
      const dayFactor = Math.max(0, Math.min(1, (sunY + 0.25) / 0.65));

      const skyCol = new THREE.Color(0x0e1429).lerp(
        new THREE.Color(GAME.weather === "rain" ? 0x566275 : 0x88aae0),
        dayFactor
      );
      if (Math.abs(sunY) < 0.22 && dayFactor > 0.05) {
        skyCol.lerp(new THREE.Color(0xc97b49), 0.4);
      }

      const headBlock = GAME.world?.getBlock(PLAYER.pos.x, PLAYER.pos.y + 1.5, PLAYER.pos.z);
      if (headBlock === B.WATER) {
        scene.fog.color.setHex(0x234c9e);
        scene.fog.near = 2;
        scene.fog.far = 18;
      } else {
        scene.background.copy(skyCol);
        scene.fog.color.copy(skyCol);
        scene.fog.near = 90000;
        scene.fog.far = 100000;
      }

      ambientLight.intensity = 0.3 + dayFactor * 0.42;
      sunLight.intensity = 0.16 + dayFactor * 0.72;
      sunLight.position.set(PLAYER.pos.x + sunX * 50, PLAYER.pos.y + Math.abs(sunY) * 60 + 20, PLAYER.pos.z + 25);
      sunLight.target.position.copy(PLAYER.pos);

      sunMesh.visible = true;
      moonMesh.visible = true;
      sunMesh.position.set(PLAYER.pos.x + sunX * 90, PLAYER.pos.y + sunY * 90, PLAYER.pos.z - 20);
      sunMesh.lookAt(PLAYER.pos);
      moonMesh.position.set(PLAYER.pos.x - sunX * 90, PLAYER.pos.y - sunY * 90, PLAYER.pos.z - 20);
      moonMesh.lookAt(PLAYER.pos);
    }

    function updateCameraAndViewmodel(dt) {
      camera.rotation.order = "YXZ";
      camera.rotation.z = 0;

      if (GAME.state === "menu") {
        const t = performance.now() * 0.00016;
        camera.position.set(Math.cos(t) * 28, 42, Math.sin(t) * 28);
        camera.lookAt(0, 29, 0);
        camera.rotation.z = 0;
        fpGroup.visible = false;
        return;
      }

      // Dynamic FOV: Sprint widens FOV, Bow pull zooms FOV in!
      const bowCharge = PLAYER.isPullingBow ? Math.min(1.0, PLAYER.bowPullTime / 0.85) : 0;
      const targetFov = PLAYER.isPullingBow ? (GAME.fov - bowCharge * 14) : (PLAYER.sprinting ? GAME.fov + 9 : GAME.fov);
      camera.fov += (targetFov - camera.fov) * dt * 12;
      camera.updateProjectionMatrix();

      const eye = getEyePos();
      const bobY = Math.sin(PLAYER.bobTimer) * 0.04;
      const bobX = Math.cos(PLAYER.bobTimer * 0.5) * 0.025;
      const isMoving = Math.hypot(PLAYER.vel.x, PLAYER.vel.z) > 0.2;
      const isSwinging = miningState.active || GAME.swingTimer > 0;

      if (PLAYER.rig) {
        PLAYER.rig.root.position.copy(PLAYER.pos);
        PLAYER.rig.root.rotation.y = PLAYER.yaw + Math.PI;
        animateHumanoidRig(PLAYER.rig, dt, {
          moving: isMoving,
          sprinting: PLAYER.sprinting,
          sneaking: PLAYER.sneaking,
          swinging: isSwinging,
          blocking: PLAYER.blockingShield,
          aimingBow: PLAYER.isPullingBow,
          hasOffShield: PLAYER.offhand?.id === "shield",
          pitch: PLAYER.pitch,
          armor: Object.fromEntries(Object.entries(PLAYER.armor || {}).map(([slot, stack]) => [slot, stack?.id || null]))
        });
      }

      if (GAME.cameraMode === 0) {
        if (PLAYER.rig) PLAYER.rig.root.visible = false;
        fpGroup.visible = true;
        camera.position.set(eye.x, eye.y + bobY, eye.z);
        camera.rotation.order = "YXZ";
        camera.rotation.y = PLAYER.yaw;
        camera.rotation.x = PLAYER.pitch;
        camera.rotation.z = 0;

        if (GAME.swingTimer > 0) GAME.swingTimer = Math.max(0, GAME.swingTimer - dt);
        if (GAME.equipAnim > 0) GAME.equipAnim = Math.max(0, GAME.equipAnim - dt * 4.5);
        const equipDrop = GAME.equipAnim * 0.25;

        const swingCycle = miningState.active
          ? Math.abs(Math.sin(performance.now() * 0.018))
          : (GAME.swingTimer > 0 ? Math.sin((0.24 - GAME.swingTimer) * 26) : 0);

        // Main Hand (Right)
        const held = PLAYER.inv[PLAYER.hotbarIdx];
        fpArm.visible = true;
        fpHand.visible = true;
        if (PLAYER.eatTimer > 0) PLAYER.eatTimer = Math.max(0, PLAYER.eatTimer - dt);
        const eatPull = PLAYER.eatTimer > 0 ? Math.sin((0.62 - PLAYER.eatTimer) * 18) * 0.18 : 0;
        fpArm.position.set(0.50 + bobX, -0.49 + bobY - equipDrop + eatPull, -0.64 + Math.max(0,eatPull) * 0.8);
        fpArm.rotation.set(0.12 + swingCycle * 0.28 - eatPull * 2.2, -0.22, -0.12 - swingCycle * 0.18);
        fpHand.position.set(0.49 + bobX, -0.77 + bobY - equipDrop + eatPull, -0.72 + Math.max(0,eatPull) * 0.8);
        fpHand.rotation.copy(fpArm.rotation);
        fpBlock.visible = false;
        fpItemSprite.visible = false;
        fpMainShield.visible = false;

        if (held?.id === "shield") {
          fpMainShield.visible = true;
          if (PLAYER.blockingShield) {
            fpMainShield.position.set(0.18, -0.18, -0.52);
            fpMainShield.rotation.set(0.05, -0.25, 0.05);
          } else {
            fpMainShield.position.set(0.45 + bobX, -0.38 + bobY - equipDrop, -0.68);
            fpMainShield.rotation.set(0.1, -0.45, 0.1);
          }
        } else if (held && typeof held.id === "number" && ATLAS.materials[held.id]) {
          fpBlock.visible = true;
          fpBlock.material = ATLAS.materials[held.id];
          fpBlock.position.set(0.46 + bobX - swingCycle * 0.25, -0.38 + bobY - swingCycle * 0.14 - equipDrop, -0.78 - swingCycle * 0.12);
          fpBlock.rotation.set(0.2 + swingCycle * 0.85, 0.6, -swingCycle * 0.45);
        } else if (held && ATLAS.itemTextures[held.id]) {
          fpItemSprite.visible = true;
          fpItemSprite.material.map = ATLAS.itemTextures[held.id];
          fpItemSprite.material.needsUpdate = true;

          if (held.id === "bow" && PLAYER.isPullingBow) {
            const shake = bowCharge > 0.9 ? Math.sin(performance.now() * 0.08) * 0.006 : 0;
            fpItemSprite.position.set(0.28 + shake, -0.22 + shake, -0.58 + bowCharge * 0.12);
            fpItemSprite.rotation.set(0.05, -0.15, 0.05 + bowCharge * 0.15);
            fpItemSprite.scale.set(1 + bowCharge * 0.15, 1 + bowCharge * 0.15, 1);
          } else {
            fpItemSprite.scale.set(1, 1, 1);
            fpItemSprite.position.set(0.45 + bobX - swingCycle * 0.28, -0.32 + bobY - swingCycle * 0.18 - equipDrop, -0.72 - swingCycle * 0.12);
            fpItemSprite.rotation.set(0.1 + swingCycle * 0.95, -0.4, 0.15 - swingCycle * 0.5);
          }
        } else {
          fpArm.position.set(0.50 + bobX - swingCycle * 0.10, -0.49 + bobY - equipDrop, -0.64 - swingCycle * 0.08);
          fpArm.rotation.set(0.12 + swingCycle * 0.28, -0.22, -0.12 - swingCycle * 0.18);
          fpHand.position.set(0.49 + bobX, -0.77 + bobY - equipDrop, -0.72 - swingCycle * 0.08);
          fpHand.rotation.copy(fpArm.rotation);
        }

        // Off-Hand (Left)
        const off = PLAYER.offhand;
        fpOffBlock.visible = false;
        fpOffSprite.visible = false;
        fpOffShield.visible = false;

        if (off?.id === "shield") {
          fpOffShield.visible = true;
          if (PLAYER.blockingShield) {
            fpOffShield.position.set(-0.18, -0.18, -0.52);
            fpOffShield.rotation.set(0.05, 0.25, -0.05);
          } else {
            fpOffShield.position.set(-0.46 - bobX, -0.4 + bobY, -0.68);
            fpOffShield.rotation.set(0.1, 0.45, -0.1);
          }
        } else if (off && typeof off.id === "number" && ATLAS.materials[off.id]) {
          fpOffBlock.visible = true;
          fpOffBlock.material = ATLAS.materials[off.id];
          fpOffBlock.position.set(-0.48 - bobX, -0.4 + bobY, -0.76);
          fpOffBlock.rotation.set(0.2, -0.6, 0);
        } else if (off && ATLAS.itemTextures[off.id]) {
          fpOffSprite.visible = true;
          fpOffSprite.material.map = ATLAS.itemTextures[off.id];
          fpOffSprite.material.needsUpdate = true;
          fpOffSprite.position.set(-0.46 - bobX, -0.36 + bobY, -0.72);
          fpOffSprite.rotation.set(0.1, 0.4, -0.15);
        }
      } else {
        if (PLAYER.rig) PLAYER.rig.root.visible = true;
        fpGroup.visible = false;
        const dir = getLookDir();
        const mult = GAME.cameraMode === 1 ? -3.6 : 3.6;
        camera.position.copy(eye.clone().addScaledVector(dir, mult)).add(new THREE.Vector3(0, 0.35, 0));
        camera.lookAt(eye);
        camera.rotation.z = 0;
      }
    }

    // =========================================================================
    // 14. FIREBASE MULTIPLAYER SYNC, COMMAND LOGS & TAB PLAYER LIST
    // =========================================================================
    async function refreshRoomList() {
      const box = document.getElementById("mp-room-list");
      if (!fbDb) {
        box.innerHTML = `<div style="color:#b88080;">База Firebase недоступна.</div>`;
        return;
      }
      box.innerHTML = `<div style="color:#9a9a9a;">Обновление списка комнат...</div>`;
      try {
        const snap = await get(ref(fbDb, "minecraft_game/rooms"));
        const val = snap.val();
        box.innerHTML = "";
        if (!val) {
          box.innerHTML = `<div style="color:#9a9a9a;">Пока нет активных комнат. Создайте свою!</div>`;
          return;
        }
        let count = 0;
        for (const [rId, room] of Object.entries(val)) {
          const playersCount = room.players ? Object.keys(room.players).length : 0;
          if (playersCount === 0) continue;
          count++;
          const row = document.createElement("div");
          row.className = "room-item";
          row.innerHTML = `<span>Комната: <b>${rId}</b> • Игроков: ${playersCount}</span>`;
          const btn = document.createElement("button");
          btn.className = "mc-btn";
          btn.style.padding = "2px 10px";
          btn.style.fontSize = "18px";
          btn.textContent = "Присоединиться";
          btn.onclick = () => joinMultiplayerRoom(rId);
          row.appendChild(btn);
          box.appendChild(row);
        }
        if (count === 0) box.innerHTML = `<div style="color:#9a9a9a;">Пока нет активных комнат. Создайте свою!</div>`;
      } catch (e) {
        box.innerHTML = `<div style="color:#b88080;">Ошибка загрузки: ${e.message}</div>`;
      }
    }

    function leaveMultiplayerRoom() {
      MP.unsubs.forEach(u => { try { u(); } catch (_) {} });
      MP.unsubs = [];
      if (MP.sweepTimer) { clearInterval(MP.sweepTimer); MP.sweepTimer = null; }
      if (MP.pingTimer) { clearInterval(MP.pingTimer); MP.pingTimer = null; }
      for (const rp of MP.remotePlayers.values()) scene.remove(rp.rig.root);
      MP.remotePlayers.clear();
      if (MP.active && fbDb && MP.roomId) {
        remove(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/players/${MP.playerId}`));
      }
      MP.active = false;
      MP.isHost = false;
      MP.stateAccum = 0;
      MP.roomId = null;
      document.getElementById("hud-mp-status").classList.add("hidden");
      document.getElementById("btn-copy-room").classList.add("hidden");
      document.getElementById("tab-player-list").classList.add("hidden");
    }

    function applyPlayersSnapshot(allRaw) {
      const all = allRaw || {};
      const now = Date.now();
      const activeIds = [];

      for (const [id, pData] of Object.entries(all)) {
        if (!pData) continue;
        if (pData.skin === "custom" && pData.skinColors) SKIN_PRESETS.custom = pData.skinColors;
        if (id !== MP.playerId && pData.lastSeen && now - pData.lastSeen > 12000) {
          remove(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/players/${id}`)).catch(() => {});
          continue;
        }
        activeIds.push(id);
        if (id === MP.playerId) continue;

        if (!MP.remotePlayers.has(id)) {
          const rig = createHumanoidRig(pData.skin || "steve", pData.name || "Друг", pData.skinDataUrl || null);
          rig.root.position.set(pData.x || 8, pData.y || 32, pData.z || 8);
          MP.remotePlayers.set(id, {
            rig,
            data: pData,
            targetPos: new THREE.Vector3(pData.x || 8, pData.y || 32, pData.z || 8),
            targetYaw: pData.yaw || 0,
            targetPitch: pData.pitch || 0
          });
          addChatLine(`[Сервер] Игрок ${pData.name || "Друг"} присоединился!`, "#b8c9a3");
        } else {
          const rp = MP.remotePlayers.get(id);
          if (pData.skinDataUrl && rp.data.skinDataUrl !== pData.skinDataUrl) applySkinAtlasToRig(rp.rig, pData.skinDataUrl);
          rp.data = pData;
          rp.targetPos.set(pData.x, pData.y, pData.z);
          rp.targetYaw = pData.yaw || 0;
          rp.targetPitch = pData.pitch || 0;
        }
      }

      for (const [id, rp] of MP.remotePlayers.entries()) {
        if (!activeIds.includes(id)) {
          scene.remove(rp.rig.root);
          MP.remotePlayers.delete(id);
          addChatLine(`[Сервер] Игрок ${rp.data.name || id} вышел из игры`, "#b4b4b4");
        }
      }

      document.getElementById("hud-mp-status").textContent = `Комната: ${MP.roomId} • Игроков: ${Math.max(1, activeIds.length)}`;
      if (!document.getElementById("tab-player-list").classList.contains("hidden")) {
        renderTabPlayerList();
      }
    }

    function renderPingBarsHtml(ping) {
      const bars = ping < 65 ? 5 : ping < 120 ? 4 : ping < 200 ? 3 : ping < 320 ? 2 : 1;
      const cls = bars >= 4 ? "on-good" : bars >= 2 ? "on-mid" : "on-bad";
      let html = `<span class="ping-bars">`;
      for (let b = 1; b <= 5; b++) {
        const h = 3 + b * 2;
        html += `<span class="ping-bar ${b <= bars ? cls : ""}" style="height:${h}px;"></span>`;
      }
      html += `</span>`;
      return html;
    }

    function renderTabPlayerList() {
      const header = document.getElementById("tab-list-header");
      const rowsBox = document.getElementById("tab-list-rows");
      const dimLabels = { overworld: "Верхний мир", nether: "Ад", end: "Край" };

      const list = [{
        name: `${MP.nickname} (Вы)`,
        skin: GAME.skin,
        dim: GAME.world?.dimension || "overworld",
        ping: MP.active ? MP.pingMs : 1
      }];

      if (MP.active) {
        for (const rp of MP.remotePlayers.values()) {
          list.push({
            name: rp.data.name || "Друг",
            skin: rp.data.skin || "steve",
            dim: rp.data.dim || "overworld",
            ping: typeof rp.data.ping === "number" ? rp.data.ping : 45
          });
        }
      }

      header.textContent = MP.active
        ? `Комната ${MP.roomId} • Игроков онлайн: ${list.length}`
        : `Одиночный мир • Игроков: 1`;

      rowsBox.innerHTML = "";
      for (const p of list) {
        const skinCfg = SKIN_PRESETS[p.skin] || SKIN_PRESETS.steve;
        const hexCol = "#" + skinCfg.skin.toString(16).padStart(6, "0");
        const row = document.createElement("div");
        row.className = "tab-row";
        row.innerHTML = `
          <div class="tab-player-left">
            <span class="tab-head-icon" style="background:${hexCol};"></span>
            <span>${p.name}</span>
            <span class="tab-dim-badge">${dimLabels[p.dim] || p.dim}</span>
          </div>
          <div class="tab-ping-wrap">
            <span>${p.ping} мс</span>
            ${renderPingBarsHtml(p.ping)}
          </div>
        `;
        rowsBox.appendChild(row);
      }
    }

    async function measureFirebasePing() {
      if (!MP.active || !fbDb || !MP.roomId) return;
      const t0 = performance.now();
      try {
        await update(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/players/${MP.playerId}`), {
          lastSeen: Date.now()
        });
        MP.pingMs = Math.max(8, Math.round(performance.now() - t0));
      } catch (_) {}
    }

    async function joinMultiplayerRoom(roomId, isCreator = false) {
      if (!fbDb) { showBanner("Firebase не подключен!"); return; }
      const normalizedRoomId = String(roomId || "").trim().toUpperCase();
      if (!/^[A-Z0-9]{4,8}$/.test(normalizedRoomId)) {
        showBanner("Код комнаты должен содержать 4–8 латинских букв или цифр.");
        return;
      }

      leaveMultiplayerRoom();
      MP.nickname = document.getElementById("mp-nickname").value.trim().slice(0, 16) || "Steve";
      MP.roomId = normalizedRoomId;
      const roomRef = ref(fbDb, `minecraft_game/rooms/${MP.roomId}`);

      try {
        let roomData;
        if (isCreator) {
          const seedToUse = Math.floor(Math.random() * 2147483646) + 1;
          roomData = {
            schema: 2,
            seed: seedToUse,
            hostId: MP.playerId,
            createdAt: Date.now(),
            config: {
              gamemode: "survival",
              difficulty: "normal",
              bonusChest: false,
              keepInventory: false,
              allowCheats: true,
              doDaylightCycle: true
            },
            state: {
              dimension: "overworld",
              timeOfDay: 1800,
              dayCount: 1,
              weather: "clear",
              gamemode: "survival",
              difficulty: "normal",
              keepInventory: false,
              doDaylightCycle: true
            }
          };
          await set(roomRef, roomData);
          MP.isHost = true;
        } else {
          const snap = await get(roomRef);
          if (!snap.exists()) {
            MP.roomId = null;
            showBanner("Комната не найдена. Проверь код или обнови список.");
            return;
          }
          roomData = snap.val();
          if (!roomData || !Number.isFinite(Number(roomData.seed))) {
            MP.roomId = null;
            showBanner("У комнаты повреждены данные мира.");
            return;
          }
          MP.isHost = roomData.hostId === MP.playerId;
        }

        const cfg = roomData.config || {};
        startNewWorld({
          name: `Сервер ${MP.roomId}`,
          seedInput: String(roomData.seed),
          gamemode: cfg.gamemode || "survival",
          difficulty: cfg.difficulty || "normal",
          bonusChest: !!cfg.bonusChest,
          keepInventory: !!cfg.keepInventory,
          allowCheats: cfg.allowCheats !== false,
          doDaylightCycle: cfg.doDaylightCycle !== false
        });

        MP.active = true;
        document.getElementById("hud-mp-status").classList.remove("hidden");
        document.getElementById("btn-copy-room").classList.remove("hidden");

        const myRef = ref(fbDb, `minecraft_game/rooms/${MP.roomId}/players/${MP.playerId}`);
        await onDisconnect(myRef).remove();
        await set(myRef, {
          name: MP.nickname,
          skin: GAME.skin,
          skinDataUrl: GAME.skin === "custom" ? GAME.customSkinDataUrl : null,
          skinColors: GAME.skin === "custom" ? (GAME.customSkinColors || SKIN_PRESETS.custom || null) : null,
          armor: Object.fromEntries(Object.entries(PLAYER.armor || {}).map(([slot, stack]) => [slot, stack?.id || null])),
          dim: GAME.world.dimension,
          x: Number(PLAYER.pos.x.toFixed(2)),
          y: Number(PLAYER.pos.y.toFixed(2)),
          z: Number(PLAYER.pos.z.toFixed(2)),
          yaw: 0,
          pitch: 0,
          moving: false,
          sprinting: false,
          sneaking: false,
          swinging: false,
          blocking: false,
          aimingBow: false,
          hasOffShield: false,
          ping: MP.pingMs,
          lastSeen: Date.now()
        });

        const unsubPlayers = onValue(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/players`), snap => {
          applyPlayersSnapshot(snap.val());
        });
        MP.unsubs.push(unsubPlayers);

        const unsubRoomState = onValue(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/state`), snap => {
          if (MP.isHost || !snap.exists() || !GAME.world) return;
          const state = snap.val();
          if (state.dimension && state.dimension !== GAME.world.dimension) {
            switchDimension(state.dimension);
          }
          if (Number.isFinite(state.timeOfDay)) GAME.timeOfDay = state.timeOfDay;
          if (Number.isFinite(state.dayCount)) GAME.dayCount = state.dayCount;
          if (state.weather) GAME.weather = state.weather;
          if (state.gamemode) GAME.gamemode = state.gamemode;
          if (state.difficulty) GAME.difficulty = state.difficulty;
          if (typeof state.keepInventory === "boolean") GAME.keepInventory = state.keepInventory;
          if (typeof state.doDaylightCycle === "boolean") GAME.doDaylightCycle = state.doDaylightCycle;
          updateEnvironment(0);
          updateHUD();
        });
        MP.unsubs.push(unsubRoomState);

        MP.sweepTimer = setInterval(async () => {
          if (!MP.active || !fbDb || !MP.roomId) return;
          try {
            const snap = await get(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/players`));
            applyPlayersSnapshot(snap.val());
          } catch (_) {}
        }, 3000);

        measureFirebasePing();
        MP.pingTimer = setInterval(measureFirebasePing, 3000);

        const unsubDrops = onValue(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/drops`), snap => {
          const allDrops = snap.val() || {};
          const activeKeys = new Set();
          for (const [dropKey, drop] of Object.entries(allDrops)) {
            if (!drop || !drop.id || drop.dim !== GAME.world?.dimension) continue;
            activeKeys.add(dropKey);
            const existing = entities.find(entity => entity.type === "drop" && entity.netId === dropKey);
            if (!existing) spawnDrop(Number(drop.x) || 0, Number(drop.y) || 0, Number(drop.z) || 0, drop.id, Math.max(1, Number(drop.count) || 1), dropKey, true);
          }
          for (let idx = entities.length - 1; idx >= 0; idx--) {
            const entity = entities[idx];
            if (entity.type === "drop" && entity.netId && !activeKeys.has(entity.netId)) {
              scene.remove(entity.mesh);
              entities.splice(idx, 1);
            }
          }
        });
        MP.unsubs.push(unsubDrops);
        const unsubBlocks = onChildAdded(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/blocks`), snap => {
          const b = snap.val();
          if (!b || b.by === MP.playerId) return;
          if (GAME.world && b.dim === GAME.world.dimension) {
            GAME.world.setBlock(b.x, b.y, b.z, b.id, false);
          }
        });
        MP.unsubs.push(unsubBlocks);

        const unsubChat = onChildAdded(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/chat`), snap => {
          const msg = snap.val();
          if (!msg || msg.by === MP.playerId) return;
          if (msg.isCmdLog) {
            addChatLine(`[${msg.name}: ${msg.text}]`, "#a4a4a4", true);
          } else {
            addChatLine(`<${msg.name}> ${msg.text}`, "#dcdcdc");
          }
        });
        MP.unsubs.push(unsubChat);

        addChatLine(`[Мультиплеер] ${MP.isHost ? "Вы владелец мира. " : ""}Код комнаты: ${MP.roomId}. Удерживайте TAB для списка игроков и пинга.`, "#d6cf82");
      } catch (err) {
        console.error("Multiplayer join failed:", err);
        leaveMultiplayerRoom();
        showBanner(`Не удалось подключиться: ${err.message || "ошибка сети"}`);
      }
    }

    function tickMultiplayer(dt) {
      if (!MP.active || !fbDb || !MP.roomId) return;

      for (const rp of MP.remotePlayers.values()) {
        rp.rig.root.visible = (rp.data.dim || "overworld") === GAME.world.dimension;
        rp.rig.root.position.lerp(rp.targetPos, Math.min(1, dt * 14));
        rp.rig.root.rotation.y = rp.targetYaw + Math.PI;
        animateHumanoidRig(rp.rig, dt, {
          moving: !!rp.data.moving,
          sprinting: !!rp.data.sprinting,
          sneaking: !!rp.data.sneaking,
          swinging: !!rp.data.swinging,
          blocking: !!rp.data.blocking,
          aimingBow: !!rp.data.aimingBow,
          hasOffShield: !!rp.data.hasOffShield,
          pitch: rp.targetPitch,
          armor: rp.data.armor || {}
        });
      }

      MP.stateAccum += dt;
      if (MP.isHost && MP.stateAccum >= 1) {
        MP.stateAccum = 0;
        update(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/state`), {
          dimension: GAME.world.dimension,
          timeOfDay: Number(GAME.timeOfDay.toFixed(2)),
          dayCount: GAME.dayCount,
          weather: GAME.weather,
          gamemode: GAME.gamemode,
          difficulty: GAME.difficulty,
          keepInventory: GAME.keepInventory,
          doDaylightCycle: GAME.doDaylightCycle
        }).catch(() => {});
      }

      MP.syncAccum += dt;
      if (MP.syncAccum >= 0.06) {
        MP.syncAccum = 0;
        const held = PLAYER.inv[PLAYER.hotbarIdx];
        update(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/players/${MP.playerId}`), {
          name: MP.nickname,
          skin: GAME.skin,
          armor: Object.fromEntries(Object.entries(PLAYER.armor || {}).map(([slot, stack]) => [slot, stack?.id || null])),
          dim: GAME.world.dimension,
          x: Number(PLAYER.pos.x.toFixed(2)),
          y: Number(PLAYER.pos.y.toFixed(2)),
          z: Number(PLAYER.pos.z.toFixed(2)),
          yaw: Number(PLAYER.yaw.toFixed(3)),
          pitch: Number(PLAYER.pitch.toFixed(3)),
          moving: Math.hypot(PLAYER.vel.x, PLAYER.vel.z) > 0.2,
          sprinting: PLAYER.sprinting,
          sneaking: PLAYER.sneaking,
          swinging: miningState.active || GAME.swingTimer > 0,
          blocking: PLAYER.blockingShield,
          aimingBow: PLAYER.isPullingBow,
          hasOffShield: PLAYER.offhand?.id === "shield",
          held: held ? held.id : null,
          ping: MP.pingMs,
          lastSeen: Date.now()
        });
      }
    }

    // =========================================================================
    // 15. COMMAND CONSOLE + BROADCAST LOGS TO ALL PLAYERS IN CHAT
    // =========================================================================
    const ALL_COMMANDS = [
      "/help",
      "/gamerule keepInventory true",
      "/gamerule keepInventory false",
      "/gamerule doDaylightCycle true",
      "/gamerule doDaylightCycle false",
      "/time set day",
      "/time set night",
      "/time set noon",
      "/time set midnight",
      "/gamemode survival",
      "/gamemode creative",
      "/gamemode adventure",
      "/gamemode spectator",
      "/difficulty peaceful",
      "/difficulty easy",
      "/difficulty normal",
      "/difficulty hard",
      "/give diamond_sword 1",
      "/give diamond_pickaxe 1",
      "/give ender_eye 12",
      "/give bow 1",
      "/give arrow 64",
      "/give shield 1",
      "/give bed 1",
      "/give emerald 32",
      "/give obsidian 16",
      "/give flint_and_steel 1",
      "/tp spawn",
      "/tp ~ ~ ~",
      "/teleport 100 70 100",
      "/spawnpoint",
      "/setworldspawn",
      "/summon zombie",
      "/summon skeleton",
      "/summon creeper",
      "/summon enderman",
      "/summon wither_skeleton",
      "/summon blaze",
      "/summon dragon",
      "/summon pig",
      "/summon sheep",
      "/summon chicken",
      "/summon rabbit",
      "/summon cow",
      "/time add 1000",
      "/time query",
      "/xp add 100",
      "/setblock ~ ~-1 ~ stone",
      "/fill ~-2 ~-1 ~-2 ~2 ~-1 ~2 stone",
      "/say Привет!",
      "/kill @e",
      "/heal",
      "/feed",
      "/clear",
      "/kill",
      "/effect speed",
      "/effect jump",
      "/effect strength",
      "/effect clear",
      "/locate village",
      "/locate pyramid",
      "/locate stronghold",
      "/seed",
      "/weather clear",
      "/weather rain"
    ];

    function addChatLine(text, color = "#dcdcdc", isCmdLog = false) {
      const box = document.getElementById("chat-messages");
      const line = document.createElement("div");
      line.className = "chat-line" + (isCmdLog ? " chat-cmd-log" : "");
      line.style.color = color;
      line.textContent = text;
      box.appendChild(line);
      while (box.children.length > 14) box.removeChild(box.firstChild);
      box.scrollTop = box.scrollHeight;
    }

    function logAndBroadcastCommand(actionSummary) {
      addChatLine(`[${MP.nickname}: ${actionSummary}]`, "#a4a4a4", true);
      if (MP.active && fbDb && MP.roomId) {
        push(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/chat`), {
          by: MP.playerId,
          name: MP.nickname,
          text: actionSummary,
          isCmdLog: true
        });
      }
    }

    function executeCommand(raw) {
      const trimmed = raw.trim();
      if (!trimmed) return;
      if (!trimmed.startsWith("/")) {
        addChatLine(`<${MP.nickname}> ${trimmed}`);
        if (MP.active && fbDb && MP.roomId) {
          push(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/chat`), {
            by: MP.playerId, name: MP.nickname, text: trimmed
          });
        }
        return;
      }
      if (!GAME.allowCheats && trimmed !== "/help" && trimmed !== "/seed") {
        addChatLine("[Ошибка] Читы отключены в настройках этого мира!", "#c98b8b");
        return;
      }

      const parts = trimmed.slice(1).split(/\s+/);
      const cmd = parts[0].toLowerCase();
      const a1 = (parts[1] || "").toLowerCase();
      const a2 = (parts[2] || "").toLowerCase();
      const a3 = (parts[3] || "").toLowerCase();

      switch (cmd) {
        case "help":
          addChatLine("=== Доступные команды ===", "#d6cf82");
          addChatLine("/gamerule keepInventory <true|false> • /gamerule doDaylightCycle <true|false>");
          addChatLine("/time set <day|night|noon|midnight|число> • /weather <clear|rain>");
          addChatLine("/gamemode <survival|creative|adventure|spectator|0|1|2|3>");
          addChatLine("/difficulty <peaceful|easy|normal|hard|0|1|2|3>");
          addChatLine("/give <предмет> [кол-во] • /tp <x> <y> <z> | spawn • /spawnpoint");
          addChatLine("/heal • /feed • /clear • /kill • /effect <speed|jump|strength|clear>");
          addChatLine("/time add|query • /xp add <число> • /summon <тип моба>");
          addChatLine("/setblock <x> <y> <z> <блок> • /fill <x1> <y1> <z1> <x2> <y2> <z2> <блок> • /say <текст>");
          addChatLine("/kill @e — удалить мобов");
          addChatLine("/locate <village|pyramid|stronghold> • /seed");
          break;

        case "gamerule":
          if (a1 === "keepinventory") {
            GAME.keepInventory = (a2 === "true" || a2 === "1" || a2 === "вкл");
            updateHUD();
            logAndBroadcastCommand(`Игровое правило keepInventory изменено на ${GAME.keepInventory}`);
          } else if (a1 === "dodaylightcycle") {
            GAME.doDaylightCycle = (a2 === "true" || a2 === "1" || a2 === "вкл");
            logAndBroadcastCommand(`Игровое правило doDaylightCycle изменено на ${GAME.doDaylightCycle}`);
          } else {
            addChatLine("Использование: /gamerule <keepInventory|doDaylightCycle> <true|false>", "#c98b8b");
          }
          break;

        case "time":
          if (a1 === "query") {
            addChatLine(`Время мира: ${Math.floor(GAME.timeOfDay)} тиков; день ${GAME.dayCount}`, "#a8c993");
          } else if (a1 === "add") {
            const amount = Number(a2);
            if (!Number.isFinite(amount)) { addChatLine("Использование: /time add <число>", "#c98b8b"); break; }
            GAME.timeOfDay = ((GAME.timeOfDay + amount) % 24000 + 24000) % 24000;
            updateEnvironment(0);
            logAndBroadcastCommand(`К игровому времени добавлено ${amount}`);
          } else if (a1 === "set") {
            const presets = { day: 1000, noon: 6000, night: 13500, midnight: 18000 };
            if (presets[a2] !== undefined) GAME.timeOfDay = presets[a2];
            else if (!isNaN(Number(a2))) GAME.timeOfDay = Math.max(0, Number(a2)) % 24000;
            else { addChatLine("Укажите day, night, noon, midnight или число", "#c98b8b"); break; }
            updateEnvironment(0);
            logAndBroadcastCommand(`Время установлено на ${Math.round(GAME.timeOfDay)}`);
          }
          break;

        case "gamemode": {
          const map = { "0": "survival", survival: "survival", "1": "creative", creative: "creative", "2": "adventure", adventure: "adventure", "3": "spectator", spectator: "spectator" };
          const mode = map[a1];
          if (!mode) { addChatLine("Режимы: survival (0), creative (1), adventure (2), spectator (3)", "#c98b8b"); break; }
          GAME.gamemode = mode;
          PLAYER.flying = (mode === "creative" || mode === "spectator");
          updateHUD();
          logAndBroadcastCommand(`Собственный игровой режим изменён на ${mode}`);
          break;
        }

        case "difficulty": {
          const map = { "0": "peaceful", peaceful: "peaceful", "1": "easy", easy: "easy", "2": "normal", normal: "normal", "3": "hard", hard: "hard" };
          const diff = map[a1];
          if (!diff) { addChatLine("Сложность: peaceful (0), easy (1), normal (2), hard (3)", "#c98b8b"); break; }
          GAME.difficulty = diff;
          updateHUD();
          logAndBroadcastCommand(`Сложность игры изменена на ${diff}`);
          break;
        }

        case "give": {
          if (!a1) { addChatLine("Использование: /give <item_id> [количество]", "#c98b8b"); break; }
          const count = Math.max(1, Math.min(64, Number(a2) || 1));
          let itemId = null;
          if (ITEMS[a1]) itemId = a1;
          else if (B[a1.toUpperCase()] !== undefined) itemId = B[a1.toUpperCase()];
          else if (!isNaN(Number(a1)) && BLOCK_PROPS[Number(a1)]) itemId = Number(a1);
          if (!itemId) { addChatLine(`Неизвестный предмет: ${a1}`, "#c98b8b"); break; }
          giveItem(itemId, count);
          logAndBroadcastCommand(`Выдано ${getItemInfo(itemId).name} x${count}`);
          break;
        }

        case "tp":
        case "teleport": {
          if (a1 === "spawn") PLAYER.pos.set(PLAYER.spawnPos.x, PLAYER.spawnPos.y, PLAYER.spawnPos.z);
          else {
            const base = [PLAYER.pos.x, PLAYER.pos.y, PLAYER.pos.z];
            const coords = [a1, a2, a3].map((v, i) => v.startsWith("~") ? base[i] + (v.length > 1 ? (Number(v.slice(1)) || 0) : 0) : Number(v));
            if (coords.some(v => !Number.isFinite(v))) { addChatLine("Использование: /tp <x> <y> <z>, /tp ~ ~ ~ или /tp spawn", "#c98b8b"); break; }
            PLAYER.pos.set(coords[0], coords[1], coords[2]);
          }
          PLAYER.vel.set(0, 0, 0);
          updateChunksAroundPlayer(true);
          resolveStuckInBlocks();
          logAndBroadcastCommand(`Телепортация в ${Math.floor(PLAYER.pos.x)}, ${Math.floor(PLAYER.pos.y)}, ${Math.floor(PLAYER.pos.z)}`);
          break;
        }

        case "spawnpoint":
          PLAYER.spawnPos = { dim: GAME.world.dimension, x: PLAYER.pos.x, y: PLAYER.pos.y, z: PLAYER.pos.z };
          logAndBroadcastCommand(`Точка возрождения установлена в ${Math.round(PLAYER.pos.x)}, ${Math.round(PLAYER.pos.y)}, ${Math.round(PLAYER.pos.z)}`);
          break;

        case "setworldspawn":
          PLAYER.spawnPos = { dim: "overworld", x: PLAYER.pos.x, y: PLAYER.pos.y, z: PLAYER.pos.z };
          logAndBroadcastCommand("Мировая точка появления установлена");
          break;

        case "summon": {
          const allowed = ["zombie", "skeleton", "creeper", "enderman", "cow", "pig", "sheep", "chicken", "rabbit", "villager_fletcher", "villager_farmer", "villager_blacksmith", "villager_cleric", "wither_skeleton", "blaze", "dragon"];
          const type = a1 || "pig";
          if (!allowed.includes(type)) { addChatLine(`Неизвестный тип существа: ${type}`, "#c98b8b"); break; }
          const dir = getLookDir();
          const x = PLAYER.pos.x + dir.x * 3, z = PLAYER.pos.z + dir.z * 3;
          const y = GAME.world.dimension === "overworld" ? Math.max(1, GAME.world.getSurfaceHeight(x, z) + 1) : PLAYER.pos.y;
          spawnMob(type, x, y, z);
          logAndBroadcastCommand(`Создано существо: ${type}`);
          break;
        }

        case "xp": {
          if (a1 !== "add" || !Number.isFinite(Number(a2))) { addChatLine("Использование: /xp add <количество>", "#c98b8b"); break; }
          const amount = Math.max(0, Math.min(100000, Math.floor(Number(a2))));
          PLAYER.xp += amount;
          while (PLAYER.xp >= (PLAYER.level + 1) * 100) { PLAYER.xp -= (PLAYER.level + 1) * 100; PLAYER.level++; }
          updateXP();
          logAndBroadcastCommand(`Добавлено опыта: ${amount}`);
          break;
        }

        case "setblock": {
          const base = [PLAYER.pos.x, PLAYER.pos.y, PLAYER.pos.z];
          const coords = parts.slice(1,4).map((v,i) => v?.startsWith("~") ? base[i] + (v.length > 1 ? Number(v.slice(1)) || 0 : 0) : Number(v));
          const token = parts[4] || "";
          const blockId = B[token.toUpperCase()] !== undefined ? B[token.toUpperCase()] : Number(token);
          if (coords.length !== 3 || coords.some(v => !Number.isFinite(v)) || !Number.isInteger(blockId) || !BLOCK_PROPS[blockId]) {
            addChatLine("Использование: /setblock <x> <y> <z> <block>", "#c98b8b"); break;
          }
          GAME.world.setBlock(Math.floor(coords[0]),Math.floor(coords[1]),Math.floor(coords[2]),blockId,true);
          logAndBroadcastCommand(`Блок ${token} установлен в ${coords.map(Math.floor).join(" ")}`);
          break;
        }

        case "fill": {
          const base = [PLAYER.pos.x, PLAYER.pos.y, PLAYER.pos.z];
          const coords = parts.slice(1,7).map((v,i) => v?.startsWith("~") ? base[i%3] + (v.length > 1 ? Number(v.slice(1)) || 0 : 0) : Number(v));
          const token = parts[7] || "";
          const blockId = B[token.toUpperCase()] !== undefined ? B[token.toUpperCase()] : Number(token);
          if (coords.length !== 6 || coords.some(v => !Number.isFinite(v)) || !Number.isInteger(blockId) || !BLOCK_PROPS[blockId]) {
            addChatLine("Использование: /fill <x1> <y1> <z1> <x2> <y2> <z2> <block>", "#c98b8b"); break;
          }
          const lo = [0,1,2].map(i => Math.floor(Math.min(coords[i],coords[i+3])));
          const hi = [0,1,2].map(i => Math.floor(Math.max(coords[i],coords[i+3])));
          const volume = (hi[0]-lo[0]+1)*(hi[1]-lo[1]+1)*(hi[2]-lo[2]+1);
          if (volume > 32768) { addChatLine("Слишком большая область: максимум 32768 блоков", "#c98b8b"); break; }
          for(let x=lo[0];x<=hi[0];x++) for(let y=lo[1];y<=hi[1];y++) for(let z=lo[2];z<=hi[2];z++) GAME.world.setBlock(x,y,z,blockId,true);
          logAndBroadcastCommand(`Заполнено блоками ${token}: ${volume}`);
          break;
        }

        case "say": {
          const message = parts.slice(1).join(" ");
          if (message) logAndBroadcastCommand(`[Объявление] ${message}`);
          else addChatLine("Использование: /say <сообщение>", "#c98b8b");
          break;
        }

        case "kill": {
          if (a1 === "@e" || a1 === "@e[type=mobs]") {
            let count = 0;
            for (let i=entities.length-1;i>=0;i--) {
              const ent = entities[i];
              if (!ent.cfg) continue;
              scene.remove(ent.mesh); entities.splice(i,1); count++;
            }
            logAndBroadcastCommand(`Уничтожено существ: ${count}`);
          } else {
            logAndBroadcastCommand("Использована команда /kill");
            damagePlayer(999, "Убит командой /kill", true);
          }
          break;
        }

        case "heal":
          PLAYER.health = 20;
          PLAYER.fireTicks = 0;
          updateHUD();
          logAndBroadcastCommand(`Здоровье восстановлено`);
          break;

        case "feed":
          PLAYER.hunger = 20;
          updateHUD();
          logAndBroadcastCommand(`Сытость восстановлена`);
          break;

        case "clear":
          PLAYER.inv.fill(null);
          PLAYER.offhand = null;
          updateHotbarUI();
          logAndBroadcastCommand(`Инвентарь очищен`);
          break;

        case "effect":
          if (a1 === "clear") {
            PLAYER.effects = { speed: 0, jump: 0, strength: 0, night_vision: 0 };
            logAndBroadcastCommand(`Сняты все эффекты`);
          } else if (PLAYER.effects[a1] !== undefined) {
            PLAYER.effects[a1] = 60;
            logAndBroadcastCommand(`Наложен эффект ${a1} на 60 сек.`);
          } else {
            addChatLine("Эффекты: speed, jump, strength, clear", "#c98b8b");
          }
          break;

        case "locate":
          if (a1 === "village") {
            const v = GAME.world.structures.villages[0] || { x: 38, y: 28, z: 32 };
            logAndBroadcastCommand(`Найдена деревня: X=${v.x}, Y=${v.y}, Z=${v.z}`);
          } else if (a1 === "pyramid") {
            const p = GAME.world.structures.pyramids[0] || { x: -58, y: 28, z: 64 };
            logAndBroadcastCommand(`Найдена пирамида: X=${p.x}, Y=${p.y}, Z=${p.z}`);
          } else if (a1 === "stronghold") {
            const s = GAME.world.structures.stronghold;
            logAndBroadcastCommand(`Найдена подземная крепость (Портал в Край): X=${s.x}, Y=${s.y}, Z=${s.z}`);
          } else {
            addChatLine("Использование: /locate <village|pyramid|stronghold>", "#c98b8b");
          }
          break;

        case "seed":
          addChatLine(`Сид мира: ${GAME.world.seed}`, "#a8c993");
          break;

        case "weather":
          if (a1 === "clear" || a1 === "rain") {
            GAME.weather = a1;
            logAndBroadcastCommand(`Погода изменена на ${a1}`);
          } else {
            addChatLine("Использование: /weather <clear|rain>", "#c98b8b");
          }
          break;

        default:
          logAndBroadcastCommand(`Выполнена команда: ${trimmed}`);
      }
    }

    function updateCommandSuggestions() {
      const input = document.getElementById("chat-input");
      const box = document.getElementById("chat-suggestions");
      const val = input.value.trim().toLowerCase();
      if (!val.startsWith("/")) { box.classList.add("hidden"); return; }
      const matches = ALL_COMMANDS.filter(c => c.toLowerCase().startsWith(val)).slice(0, 6);
      if (matches.length === 0) { box.classList.add("hidden"); return; }
      box.innerHTML = "";
      box.classList.remove("hidden");
      for (const m of matches) {
        const chip = document.createElement("span");
        chip.className = "cmd-chip";
        chip.textContent = m;
        chip.onclick = () => { input.value = m; input.focus(); updateCommandSuggestions(); };
        box.appendChild(chip);
      }
    }

    function openChat(prefill = "") {
      const row = document.getElementById("chat-input-row");
      const input = document.getElementById("chat-input");
      row.classList.remove("hidden");
      input.value = prefill;
      document.exitPointerLock?.();
      setTimeout(() => input.focus(), 10);
      updateCommandSuggestions();
    }

    function closeChat() {
      document.getElementById("chat-input-row").classList.add("hidden");
      document.getElementById("chat-suggestions").classList.add("hidden");
      document.getElementById("chat-input").blur();
      if (GAME.state === "playing") requestLock();
    }

    // =========================================================================
    // 16. HUD UPDATES & TIME-BUDGETED CHUNK MESH QUEUE (ANTI-LAG)
    // =========================================================================
    let bannerTimer = null;
    function showBanner(text) {
      const b = document.getElementById("action-banner");
      b.textContent = text;
      b.style.opacity = "1";
      clearTimeout(bannerTimer);
      bannerTimer = setTimeout(() => { b.style.opacity = "0"; }, 3600);
    }

    function updateXP() {
      while (PLAYER.xp >= 100) {
        PLAYER.xp -= 100;
        PLAYER.level++;
        SFX.levelUp();
      }
      document.getElementById("xp-fill").style.width = `${PLAYER.xp}%`;
      document.getElementById("xp-level").textContent = PLAYER.level > 0 ? PLAYER.level : "";
    }

    function updateHUD() {
      if (!GAME.world) return;
      const dimNames = { overworld: "Верхний мир", nether: "Нижний мир (Ад)", end: "Край (Энд)" };
      const modeNames = { survival: "Выживание", creative: "Творческий", adventure: "Приключение", spectator: "Наблюдатель" };
      document.getElementById("hud-dim").textContent = `Измерение: ${dimNames[GAME.world.dimension]}`;
      document.getElementById("hud-biome").textContent = `Биом: ${GAME.world.getBiome(PLAYER.pos.x, PLAYER.pos.z)} • День ${GAME.dayCount}`;
      document.getElementById("hud-coords").textContent = `XYZ: ${Math.floor(PLAYER.pos.x)} / ${Math.floor(PLAYER.pos.y)} / ${Math.floor(PLAYER.pos.z)}`;
      document.getElementById("hud-rules").textContent = `KeepInv: ${GAME.keepInventory ? "ВКЛ" : "ВЫКЛ"} • Режим: ${modeNames[GAME.gamemode]} • Сложность: ${GAME.difficulty}`;

      const hBox = document.getElementById("health-icons");
      hBox.innerHTML = "";
      if (GAME.gamemode === "survival" || GAME.gamemode === "adventure") {
        const hearts = Math.ceil(PLAYER.health / 2);
        for (let i = 0; i < 10; i++) {
          const s = document.createElement("span");
          s.textContent = "❤";
          s.style.color = i < hearts ? "#b83535" : "#3a3a3a";
          hBox.appendChild(s);
        }
      }

      const armorBox = document.getElementById("armor-icons");
      if (armorBox) {
        armorBox.innerHTML = "";
        for (const key of ["head", "chest", "legs", "feet"]) {
          const slot = document.createElement("span");
          const stack = PLAYER.armor?.[key];
          slot.textContent = stack ? "▣" : "□";
          slot.title = stack ? (ITEMS[stack.id]?.name || stack.id) : "Пустой слот брони";
          slot.style.cssText = "display:inline-flex;width:17px;height:17px;align-items:center;justify-content:center;border:1px solid #aaa;background:#333;color:" + (stack ? "#e7e7e7" : "#777");
          armorBox.appendChild(slot);
        }
      }

      const fBox = document.getElementById("hunger-icons");
      fBox.innerHTML = "";
      if (GAME.gamemode === "survival" || GAME.gamemode === "adventure") {
        const legs = Math.ceil(PLAYER.hunger / 2);
        for (let i = 0; i < 10; i++) {
          const s = document.createElement("span");
          s.textContent = "🍗";
          s.style.opacity = i < legs ? "0.9" : "0.25";
          fBox.appendChild(s);
        }
      }

      const aBox = document.getElementById("air-icons");
      aBox.innerHTML = "";
      if (PLAYER.air < 300) {
        const bubs = Math.ceil(PLAYER.air / 30);
        for (let i = 0; i < bubs; i++) {
          const s = document.createElement("span"); s.textContent = "🫧"; aBox.appendChild(s);
        }
      }
      let effectsBox = document.getElementById("active-effects-hud");
      if (!effectsBox) {
        effectsBox = document.createElement("div"); effectsBox.id = "active-effects-hud";
        effectsBox.style.cssText = "position:fixed;right:14px;top:14px;z-index:30;display:flex;flex-direction:column;gap:6px;pointer-events:auto;font:14px monospace";
        document.body.appendChild(effectsBox);
      }
      const effectMeta = { speed:["🏃","Скорость"], jump:["🦘","Прыгучесть"], strength:["⚔️","Сила"], night_vision:["🌙","Ночное зрение"] };
      effectsBox.innerHTML = "";
      for (const [key,value] of Object.entries(PLAYER.effects || {})) {
        if (!(value > 0) || !effectMeta[key]) continue;
        const chip = document.createElement("div"); chip.textContent = effectMeta[key][0] + " " + effectMeta[key][1];
        chip.title = effectMeta[key][1] + ": эффект активен";
        chip.style.cssText = "padding:5px 8px;background:#202020dd;border:1px solid #777;border-radius:4px;color:#fff;text-shadow:1px 1px #000;cursor:help";
        effectsBox.appendChild(chip);
      }
    }

    function updateChunksAroundPlayer(immediate = false) {
      if (!GAME.world) return;
      GAME.world.ensureStructuresInRegion(PLAYER.pos.x, PLAYER.pos.z);

      const pcx = Math.floor(PLAYER.pos.x / CHUNK_SIZE);
      const pcz = Math.floor(PLAYER.pos.z / CHUNK_SIZE);
      const r = GAME.renderDist;
      const needed = new Set();
      const toBuild = [];

      for (let dx = -r; dx <= r; dx++) {
        for (let dz = -r; dz <= r; dz++) {
          if (dx * dx + dz * dz > r * r) continue;
          const cx = pcx + dx, cz = pcz + dz;
          const key = GAME.world.chunkKey(cx, cz);
          needed.add(key);
          if (!GAME.world.meshes.has(key)) {
            toBuild.push({ cx, cz, dist: dx * dx + dz * dz });
          }
        }
      }

      toBuild.sort((a, b) => a.dist - b.dist);
      for (const item of toBuild) {
        if (immediate && item.dist <= 4) {
          GAME.world.rebuildChunkMesh(item.cx, item.cz);
        } else {
          GAME.world.enqueueChunkRebuild(item.cx, item.cz, item.dist <= 2);
        }
      }

      for (const [key, grp] of GAME.world.meshes.entries()) {
        if (!needed.has(key)) {
          scene.remove(grp);
          grp.traverse(o => { if (o.geometry) o.geometry.dispose(); });
          GAME.world.meshes.delete(key);
        }
      }
    }

    function processChunkMeshQueue(maxPerFrame = GAME.renderDist >= 24 ? 6 : 2) {
      if (!GAME.world || GAME.world.meshQueue.length === 0) return;
      let built = 0;
      while (built < maxPerFrame && GAME.world.meshQueue.length > 0) {
        const item = GAME.world.meshQueue.shift();
        GAME.world.meshQueueSet.delete(item.key);
        if (!GAME.world.meshes.has(item.key)) {
          GAME.world.rebuildChunkMesh(item.cx, item.cz);
          built++;
        }
      }
    }

    // =========================================================================
    // 17. WORLD START & MENU BINDINGS
    // =========================================================================
    function parseSeed(str) {
      if (!str || !str.trim()) return Math.floor(Math.random() * 899999 + 100000);
      if (!isNaN(Number(str))) return Math.abs(Math.floor(Number(str)));
      let h = 0;
      for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0;
      return Math.abs(h);
    }

    function findSafeSurfaceY(x, z) {
      const ix = Math.floor(x), iz = Math.floor(z);
      for (let y = WORLD_HEIGHT - 2; y >= 1; y--) {
        if (BLOCK_PROPS[GAME.world.getBlock(ix, y, iz)]?.solid) return y + 1.05;
      }
      return GAME.world.getSurfaceHeight(ix, iz) + 1.5;
    }


    // Local single-player world saves. World terrain is deterministic; only changed
    // blocks and player/world state need to be stored in localStorage.
    const WORLD_SAVES_KEY = "minecraft_web_world_saves_v1";
    let activeSaveId = null;
    let saveClock = 0;

    function readWorldSaves() {
      try { return JSON.parse(localStorage.getItem(WORLD_SAVES_KEY) || "[]"); }
      catch (error) { console.warn("Не удалось прочитать сохранения:", error); return []; }
    }

    function saveCurrentWorld() {
      if (!GAME.world || MP.active || GAME.state === "menu") return;
      try {
        const saves = readWorldSaves();
        const id = activeSaveId || ("world_" + Date.now().toString(36));
        activeSaveId = id;
        const data = {
          id,
          name: GAME.worldName || "Мой мир",
          seed: GAME.world.seed,
          dimension: GAME.world.dimension,
          modifications: Object.fromEntries(Object.entries(GAME.world.modifications).map(([dim, map]) => [dim, Array.from(map.entries())])),
          player: {
            pos: PLAYER.pos.toArray(), yaw: PLAYER.yaw, pitch: PLAYER.pitch,
            health: PLAYER.health, hunger: PLAYER.hunger, air: PLAYER.air,
            fireTicks: PLAYER.fireTicks, xp: PLAYER.xp, level: PLAYER.level,
            spawnPos: PLAYER.spawnPos, inv: PLAYER.inv, offhand: PLAYER.offhand,
            armor: PLAYER.armor, hotbarIdx: PLAYER.hotbarIdx, flying: PLAYER.flying
          },
          game: {
            gamemode: GAME.gamemode, difficulty: GAME.difficulty,
            keepInventory: GAME.keepInventory, allowCheats: GAME.allowCheats,
            doDaylightCycle: GAME.doDaylightCycle, timeOfDay: GAME.timeOfDay,
            dayCount: GAME.dayCount, weather: GAME.weather
          },
          updatedAt: Date.now()
        };
        const index = saves.findIndex(item => item.id === id);
        if (index >= 0) saves[index] = data; else saves.unshift(data);
        localStorage.setItem(WORLD_SAVES_KEY, JSON.stringify(saves));
        renderSavedWorlds();
      } catch (error) {
        console.warn("Не удалось сохранить мир (возможно, закончилось место):", error);
        showBanner("Не удалось сохранить мир: проверьте свободное место браузера");
      }
    }

    function renderSavedWorlds() {
      const list = document.getElementById("saved-world-list");
      if (!list) return;
      const saves = readWorldSaves();
      list.innerHTML = "";
      if (!saves.length) {
        list.innerHTML = '<div style="color:#aaa;text-align:center;padding:12px;font-size:19px;">Сохранённых миров пока нет</div>';
        return;
      }
      for (const save of saves) {
        const row = document.createElement("div");
        row.className = "room-item";
        const info = document.createElement("div");
        info.style.cssText = "display:flex;flex-direction:column;gap:2px;min-width:0";
        const name = document.createElement("strong");
        name.textContent = save.name || "Мир без названия";
        const meta = document.createElement("span");
        meta.style.cssText = "font-size:16px;color:#aaa";
        meta.textContent = "Сид: " + save.seed + " • " + new Date(save.updatedAt || Date.now()).toLocaleString();
        info.append(name, meta);
        const actions = document.createElement("div");
        actions.style.cssText = "display:flex;gap:5px;flex-shrink:0";
        const play = document.createElement("button");
        play.className = "mc-btn"; play.textContent = "Играть";
        play.onclick = () => loadSavedWorld(save.id);
        const del = document.createElement("button");
        del.className = "mc-btn"; del.textContent = "Удалить";
        del.onclick = () => {
          if (!confirm('Удалить мир "' + (save.name || "Мир") + '"?')) return;
          localStorage.setItem(WORLD_SAVES_KEY, JSON.stringify(readWorldSaves().filter(item => item.id !== save.id)));
          renderSavedWorlds();
        };
        actions.append(play, del); row.append(info, actions); list.appendChild(row);
      }
    }

    function loadSavedWorld(id) {
      const save = readWorldSaves().find(item => item.id === id);
      if (!save) { showBanner("Сохранение не найдено"); renderSavedWorlds(); return; }
      leaveMultiplayerRoom();
      clearAllEntities();
      if (GAME.world) GAME.world.clearAllMeshes();
      if (PLAYER.rig) scene.remove(PLAYER.rig.root);
      PLAYER.rig = createHumanoidRig(GAME.skin, null, GAME.skin === "custom" ? GAME.customSkinDataUrl : null);
      GAME.world = new VoxelWorld(Number(save.seed) || 12345);
      GAME.world.buildStructures();
      for (const dim of ["overworld", "nether", "end"]) {
        GAME.world.dimension = dim;
        const entries = save.modifications?.[dim] || [];
        const map = GAME.world.modifications[dim];
        for (const [key, value] of entries) {
          const [x, y, z] = key.split(",").map(Number);
          GAME.world.setBlockRaw(x, y, z, value);
        }
      }
      GAME.world.dimension = save.dimension || "overworld";
      const g = save.game || {};
      GAME.gamemode = g.gamemode || "survival";
      GAME.difficulty = g.difficulty || "normal";
      GAME.keepInventory = !!g.keepInventory;
      GAME.allowCheats = g.allowCheats !== false;
      GAME.doDaylightCycle = g.doDaylightCycle !== false;
      GAME.timeOfDay = Number(g.timeOfDay ?? 1800);
      GAME.dayCount = Number(g.dayCount ?? 1);
      GAME.weather = g.weather || "clear";
      const p = save.player || {};
      if (Array.isArray(p.pos)) PLAYER.pos.fromArray(p.pos);
      PLAYER.yaw = Number(p.yaw || 0); PLAYER.pitch = Number(p.pitch || 0);
      PLAYER.vel.set(0, 0, 0);
      PLAYER.health = Number(p.health ?? 20); PLAYER.hunger = Number(p.hunger ?? 20);
      PLAYER.air = Number(p.air ?? 300); PLAYER.fireTicks = Number(p.fireTicks || 0);
      PLAYER.xp = Number(p.xp || 0); PLAYER.level = Number(p.level || 0);
      PLAYER.spawnPos = p.spawnPos || {dim:"overworld",x:8.5,y:36,z:8.5};
      PLAYER.inv = Array.isArray(p.inv) ? p.inv : new Array(36).fill(null);
      PLAYER.offhand = p.offhand || null;
      PLAYER.armor = p.armor || {head:null,chest:null,legs:null,feet:null};
      PLAYER.hotbarIdx = Number(p.hotbarIdx || 0); PLAYER.flying = !!p.flying;
      GAME.worldName = save.name || "Мой мир";
      activeSaveId = save.id;
      updateChunksAroundPlayer(true);
      resolveStuckInBlocks();
      updateHotbarUI(); updateHUD();
      document.querySelectorAll(".screen-overlay").forEach(el => el.classList.add("hidden"));
      document.getElementById("hud").classList.remove("hidden");
      GAME.state = "playing";
      addChatLine('[Мир "' + GAME.worldName + '"] Сохранение загружено.', "#d6cf82");
      requestLock();
      showBanner("Мир загружен • Автосохранение включено");
    }

    function startNewWorld(cfg) {
      clearAllEntities();
      if (GAME.world) GAME.world.clearAllMeshes();
      if (PLAYER.rig) scene.remove(PLAYER.rig.root);
      PLAYER.rig = createHumanoidRig(GAME.skin);

      const numericSeed = parseSeed(cfg.seedInput);
      activeSaveId = "world_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 6);
      GAME.worldName = cfg.name || "Новый мир";
      GAME.gamemode = cfg.gamemode;
      GAME.difficulty = cfg.difficulty;
      GAME.keepInventory = cfg.keepInventory;
      GAME.allowCheats = cfg.allowCheats;
      GAME.doDaylightCycle = cfg.doDaylightCycle;
      GAME.weather = "clear";
      GAME.timeOfDay = 1800;
      GAME.dayCount = 1;

      GAME.world = new VoxelWorld(numericSeed);
      GAME.world.getChunk(0, 0);
      GAME.world.buildStructures();

      const sy = findSafeSurfaceY(8, 8);
      PLAYER.pos.set(8.5, sy, 8.5);
      PLAYER.spawnPos = { dim: "overworld", x: 8.5, y: sy, z: 8.5 };
      PLAYER.vel.set(0, 0, 0);
      PLAYER.yaw = 0;
      PLAYER.pitch = 0;
      PLAYER.health = 20;
      PLAYER.hunger = 20;
      PLAYER.air = 300;
      PLAYER.fireTicks = 0;
      PLAYER.blockingShield = false;
      PLAYER.isPullingBow = false;
      PLAYER.flying = (cfg.gamemode === "creative" || cfg.gamemode === "spectator");
      PLAYER.inv.fill(null);
      PLAYER.offhand = null;

      if (cfg.bonusChest) GAME.world.spawnBonusChestNear(8.5, 8.5);

      if (cfg.gamemode === "creative") {
        giveItem("diamond_sword", 1);
        giveItem("bow", 1);
        giveItem("arrow", 64);
        giveItem("ender_eye", 16);
        giveItem(B.END_PORTAL_FRAME, 16);
        giveItem(B.OBSIDIAN, 64);
        giveItem("flint_and_steel", 1);
        giveItem("bed", 1);
        giveItem(B.GRASS, 64);
        PLAYER.offhand = { id: "shield", count: 1 };
      } else {
        // A fresh survival world starts with an empty inventory.
      }

      // Villagers spawn alongside villages in distant generated regions.

      spawnMob("cow", 14, sy, 12);
      spawnMob("pig", 4, sy, 15);
      spawnMob("sheep", 11, sy, 17);
      spawnMob("chicken", 6, sy, 11);

      updateChunksAroundPlayer(true);
      resolveStuckInBlocks();
      updateHotbarUI();
      updateHUD();

      document.querySelectorAll(".screen-overlay").forEach(el => el.classList.add("hidden"));
      document.getElementById("hud").classList.remove("hidden");
      document.getElementById("chat-messages").innerHTML = "";
      addChatLine(`[Мир "${cfg.name}"] Сид: ${numericSeed}. Исследуй мир, чтобы найти деревни, пирамиды и порталы.`, "#d6cf82");

      GAME.state = "playing";
      requestLock();
      saveCurrentWorld();
      showBanner("Клик по экрану — захват мыши • Ctrl — бег • Shift — присесть • F — предмет во вторую руку • E — инвентарь/креатив");
    }

    function requestLock() {
      canvas.requestPointerLock?.();
    }

    // Menu Bindings
    document.getElementById("btn-open-saves").onclick = () => {
      SFX.click(); renderSavedWorlds();
      document.getElementById("main-menu").classList.add("hidden");
      document.getElementById("saved-worlds-screen").classList.remove("hidden");
    };
    document.getElementById("btn-saves-back").onclick = () => {
      SFX.click();
      document.getElementById("saved-worlds-screen").classList.add("hidden");
      document.getElementById("main-menu").classList.remove("hidden");
    };
    document.getElementById("btn-open-create").onclick = () => {
      SFX.click();
      document.getElementById("main-menu").classList.add("hidden");
      document.getElementById("create-world-screen").classList.remove("hidden");
    };
    document.getElementById("btn-create-cancel").onclick = () => {
      SFX.click();
      document.getElementById("create-world-screen").classList.add("hidden");
      document.getElementById("main-menu").classList.remove("hidden");
    };

    document.getElementById("btn-open-multiplayer").onclick = () => {
      SFX.click();
      document.getElementById("main-menu").classList.add("hidden");
      document.getElementById("multiplayer-screen").classList.remove("hidden");
      refreshRoomList();
    };
    document.getElementById("btn-mp-back").onclick = () => {
      SFX.click();
      document.getElementById("multiplayer-screen").classList.add("hidden");
      document.getElementById("main-menu").classList.remove("hidden");
    };
    document.getElementById("btn-mp-refresh").onclick = () => { SFX.click(); refreshRoomList(); };
    document.getElementById("btn-mp-create-room").onclick = () => {
      SFX.click();
      const code = Math.random().toString(36).substring(2, 7).toUpperCase();
      joinMultiplayerRoom(code, true);
    };
    document.getElementById("btn-mp-join-room").onclick = () => {
      SFX.click();
      const code = document.getElementById("mp-room-code").value.trim().toUpperCase();
      if (!code) { showBanner("Введите код комнаты!"); return; }
      joinMultiplayerRoom(code, false);
    };
    document.getElementById("btn-copy-room").onclick = () => {
      SFX.click();
      if (!MP.roomId) return;
      const tmp = document.createElement("input");
      tmp.value = MP.roomId;
      document.body.appendChild(tmp);
      tmp.select();
      document.execCommand("copy");
      document.body.removeChild(tmp);
      showBanner(`Код комнаты ${MP.roomId} скопирован!`);
    };

    document.getElementById("btn-open-skin").onclick = () => {
      SFX.click();
      document.getElementById("main-menu").classList.add("hidden");
      document.getElementById("skin-screen").classList.remove("hidden");
    };
    document.getElementById("btn-skin-back").onclick = () => {
      SFX.click();
      document.getElementById("skin-screen").classList.add("hidden");
      document.getElementById("main-menu").classList.remove("hidden");
    };
    document.querySelectorAll(".skin-preset").forEach(btn => {
      btn.onclick = () => {
        SFX.click();
        GAME.skin = btn.dataset.skin;
        document.getElementById("skin-current-label").textContent = `Текущий скин: ${SKIN_PRESETS[GAME.skin].name}`;
      };
    });
    function acceptMinecraftSkin(image) {
      if (![64, 128].includes(image.width) || ![32, 64, 128].includes(image.height) ||
          !(image.width === image.height || (image.width === 64 && image.height === 32))) {
        showBanner("Поддерживается PNG-скин 64×64 или классический 64×32");
        return;
      }
      const canvas = document.createElement("canvas"); canvas.width = 64; canvas.height = 64;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, 64, 64);
      if (image.width === 64 && image.height === 32) {
        ctx.drawImage(image, 0, 0, 64, 32);
        // Convert the classic 64×32 layout into the modern 64×64 left-limb UV regions.
        ctx.drawImage(canvas, 40, 16, 16, 16, 32, 48, 16, 16);
        ctx.drawImage(canvas, 0, 16, 16, 16, 16, 48, 16, 16);
      } else {
        ctx.drawImage(image, 0, 0, 64, 64);
      }
      const dataUrl = canvas.toDataURL("image/png");
      const sample = (x,y,w=4,h=4) => {
        const data = ctx.getImageData(x,y,w,h).data; let r=0,g=0,b=0,n=0;
        for(let i=0;i<data.length;i+=4) if(data[i+3]>32){r+=data[i];g+=data[i+1];b+=data[i+2];n++;}
        return n ? (Math.round(r/n)<<16)|(Math.round(g/n)<<8)|Math.round(b/n) : 0x888888;
      };
      SKIN_PRESETS.custom = { name: "Мой скин", skin: sample(8,8), hair: sample(40,0), shirt: sample(20,20), pants: sample(4,20) };
      GAME.skin = "custom";
      GAME.customSkinDataUrl = dataUrl;
      GAME.customSkinColors = SKIN_PRESETS.custom;
      try { localStorage.setItem("minecraft-custom-skin-v1", dataUrl); } catch (_) {}
      if (PLAYER.rig) applySkinAtlasToRig(PLAYER.rig, dataUrl);
      const label = document.getElementById("skin-current-label");
      if (label) label.textContent = "Текущий скин: Мой скин";
      if (MP.active && fbDb && MP.roomId) {
        update(ref(fbDb, `minecraft_game/rooms/${MP.roomId}/players/${MP.playerId}`), {
          skin: "custom", skinDataUrl: dataUrl, skinColors: SKIN_PRESETS.custom
        }).catch(err => console.warn("Skin sync failed:", err));
      }
      showBanner("Полный пиксельный скин применён к модели персонажа");
    }
    document.getElementById("skin-upload").addEventListener("change", event => {
      const file = event.target.files?.[0];
      if (!file) return;
      if (file.type !== "image/png") { showBanner("Нужен PNG-файл скина"); return; }
      const reader = new FileReader();
      reader.onload = () => {
        const image = new Image();
        image.onload = () => acceptMinecraftSkin(image);
        image.onerror = () => showBanner("Не удалось прочитать PNG-скин");
        image.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    });
    document.getElementById("btn-skin-load-url")?.addEventListener("click", () => {
      const url = document.getElementById("skin-url")?.value.trim();
      if (!url) return;
      try {
        const parsed = new URL(url);
        if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("invalid protocol");
        const image = new Image();
        image.crossOrigin = "anonymous";
        image.onload = () => {
          try { acceptMinecraftSkin(image); }
          catch (_) { showBanner("Сайт запретил загрузку изображения. Скачай PNG и выбери файл."); }
        };
        image.onerror = () => showBanner("Не удалось загрузить скин по ссылке. Попробуй прямую ссылку на PNG или загрузи файл.");
        image.src = parsed.href;
      } catch (_) { showBanner("Введи корректную HTTP/HTTPS-ссылку на PNG-скин"); }
    });

    const modesOrder = ["survival", "creative", "adventure", "spectator"];
    const modeLabels = { survival: "Выживание", creative: "Творческий", adventure: "Приключение", spectator: "Наблюдатель" };
    document.getElementById("btn-cfg-gamemode").onclick = (e) => {
      SFX.click();
      const next = modesOrder[(modesOrder.indexOf(WORLD_CONFIG.gamemode) + 1) % modesOrder.length];
      WORLD_CONFIG.gamemode = next;
      e.target.textContent = `Режим: ${modeLabels[next]}`;
    };

    const diffOrder = ["peaceful", "easy", "normal", "hard"];
    const diffLabels = { peaceful: "Мирная", easy: "Легкая", normal: "Нормальная", hard: "Сложная" };
    document.getElementById("btn-cfg-difficulty").onclick = (e) => {
      SFX.click();
      const next = diffOrder[(diffOrder.indexOf(WORLD_CONFIG.difficulty) + 1) % diffOrder.length];
      WORLD_CONFIG.difficulty = next;
      e.target.textContent = `Сложность: ${diffLabels[next]}`;
    };

    document.getElementById("btn-cfg-bonus-chest").onclick = (e) => {
      SFX.click();
      WORLD_CONFIG.bonusChest = !WORLD_CONFIG.bonusChest;
      e.target.textContent = `Бонусный сундук: ${WORLD_CONFIG.bonusChest ? "ВКЛ" : "ВЫКЛ"}`;
    };
    document.getElementById("btn-cfg-keep-inv").onclick = (e) => {
      SFX.click();
      WORLD_CONFIG.keepInventory = !WORLD_CONFIG.keepInventory;
      e.target.textContent = `Сохранять инвентарь: ${WORLD_CONFIG.keepInventory ? "ВКЛ" : "ВЫКЛ"}`;
    };
    document.getElementById("btn-cfg-cheats").onclick = (e) => {
      SFX.click();
      WORLD_CONFIG.allowCheats = !WORLD_CONFIG.allowCheats;
      e.target.textContent = `Читы и команды: ${WORLD_CONFIG.allowCheats ? "ВКЛ" : "ВЫКЛ"}`;
    };
    document.getElementById("btn-cfg-daycycle").onclick = (e) => {
      SFX.click();
      WORLD_CONFIG.doDaylightCycle = !WORLD_CONFIG.doDaylightCycle;
      e.target.textContent = `Смена дня/ночи: ${WORLD_CONFIG.doDaylightCycle ? "ВКЛ" : "ВЫКЛ"}`;
    };

    document.getElementById("btn-create-launch").onclick = () => {
      SFX.click();
      leaveMultiplayerRoom();
      WORLD_CONFIG.name = document.getElementById("cfg-world-name").value.trim() || "Новый мир";
      WORLD_CONFIG.seedInput = document.getElementById("cfg-seed").value;
      startNewWorld(WORLD_CONFIG);
    };

    // Creative Tabs & Search
    document.querySelectorAll(".cr-tab").forEach(btn => {
      btn.onclick = () => {
        SFX.click();
        document.querySelectorAll(".cr-tab").forEach(b => b.classList.remove("active-tab"));
        btn.classList.add("active-tab");
        creativeCategory = btn.dataset.cat;
        renderCreativeCatalog();
      };
    });
    document.getElementById("creative-search").addEventListener("input", renderCreativeCatalog);
    document.getElementById("btn-creative-clear").onclick = () => {
      SFX.click();
      PLAYER.inv.fill(null);
      PLAYER.offhand = null;
      updateHotbarUI();
      refreshGuiGrids();
    };

    // Settings
    document.getElementById("btn-open-settings").onclick = () => {
      SFX.click();
      document.getElementById("main-menu").classList.add("hidden");
      document.getElementById("settings-screen").classList.remove("hidden");
    };
    document.getElementById("btn-pause-settings").onclick = () => {
      SFX.click();
      document.getElementById("pause-menu").classList.add("hidden");
      document.getElementById("settings-screen").classList.remove("hidden");
    };
    document.getElementById("btn-settings-back").onclick = () => {
      SFX.click();
      document.getElementById("settings-screen").classList.add("hidden");
      if (GAME.world && GAME.state === "paused") document.getElementById("pause-menu").classList.remove("hidden");
      else document.getElementById("main-menu").classList.remove("hidden");
    };
    document.getElementById("btn-set-render").onclick = (e) => {
      SFX.click();
      GAME.renderDist = GAME.renderDist >= 12 ? 6 : GAME.renderDist + 2;
      e.target.textContent = `Дальность прорисовки: ${GAME.renderDist} чанков`;
      updateChunksAroundPlayer();
    };
    document.getElementById("btn-set-fov").onclick = (e) => {
      SFX.click();
      GAME.fov = GAME.fov >= 100 ? 65 : GAME.fov + 10;
      e.target.textContent = `Поле зрения (FOV): ${GAME.fov}`;
    };
    document.getElementById("btn-set-sens").onclick = (e) => {
      SFX.click();
      GAME.mouseSens = GAME.mouseSens >= 1.6 ? 0.6 : Number((GAME.mouseSens + 0.2).toFixed(1));
      e.target.textContent = `Чувствительность мыши: ${Math.round(GAME.mouseSens * 100)}%`;
    };
    document.getElementById("btn-set-vol").onclick = (e) => {
      SFX.click();
      SFX.volume = SFX.volume <= 0 ? 1.0 : Number((SFX.volume - 0.2).toFixed(1));
      e.target.textContent = `Громкость звуков: ${Math.round(SFX.volume * 100)}%`;
    };

    document.getElementById("btn-set-quality").onclick = (e) => {
      SFX.click();
      const levels = ["low", "medium", "high"];
      GAME.graphicsQuality = levels[(levels.indexOf(GAME.graphicsQuality) + 1) % levels.length];
      const cfg = {
        low: { pixelRatio: 0.65, shadows: false, label: "Низкое" },
        medium: { pixelRatio: 0.9, shadows: false, label: "Среднее" },
        high: { pixelRatio: 1.0, shadows: false, label: "Высокое" }
      }[GAME.graphicsQuality];
      adaptivePixelRatio = Math.min(window.devicePixelRatio || 1, cfg.pixelRatio);
      renderer.setPixelRatio(adaptivePixelRatio);
      renderer.setSize(window.innerWidth, window.innerHeight);
      renderer.shadowMap.enabled = cfg.shadows;
      sunLight.castShadow = cfg.shadows;
      e.target.textContent = "Качество графики: " + cfg.label;
      updateChunksAroundPlayer(true);
      showBanner("Графика: " + cfg.label.toLowerCase());
    };
    // Pause, Death, GUI & End Poem Buttons
    document.getElementById("btn-resume").onclick = () => {
      SFX.click();
      document.getElementById("pause-menu").classList.add("hidden");
      GAME.state = "playing";
      requestLock();
    };
    document.getElementById("btn-open-commands-help").onclick = () => {
      SFX.click();
      document.getElementById("pause-menu").classList.add("hidden");
      GAME.state = "playing";
      executeCommand("/help");
      openChat("/");
    };
    document.getElementById("btn-quit-menu").onclick = () => {
      SFX.click();
      saveCurrentWorld();
      leaveMultiplayerRoom();
      GAME.state = "menu";
      document.getElementById("hud").classList.add("hidden");
      document.getElementById("pause-menu").classList.add("hidden");
      document.getElementById("main-menu").classList.remove("hidden");
    };
    document.getElementById("btn-respawn").onclick = () => {
      SFX.click();
      document.getElementById("death-screen").classList.add("hidden");
      if (GAME.world.dimension !== PLAYER.spawnPos.dim) switchDimension(PLAYER.spawnPos.dim);
      PLAYER.pos.set(PLAYER.spawnPos.x, PLAYER.spawnPos.y, PLAYER.spawnPos.z);
      PLAYER.vel.set(0, 0, 0);
      PLAYER.health = 20;
      PLAYER.hunger = 20;
      PLAYER.fireTicks = 0;
      GAME.state = "playing";
      updateChunksAroundPlayer(true);
      resolveStuckInBlocks();
      updateHUD();
      requestLock();
    };
    document.getElementById("btn-death-menu").onclick = () => {
      SFX.click();
      saveCurrentWorld();
      leaveMultiplayerRoom();
      document.getElementById("death-screen").classList.add("hidden");
      document.getElementById("hud").classList.add("hidden");
      GAME.state = "menu";
      document.getElementById("main-menu").classList.remove("hidden");
    };
    document.getElementById("btn-gui-close").onclick = () => { SFX.click(); closeGUI(); };
    document.getElementById("btn-poem-close").onclick = () => {
      SFX.click();
      document.getElementById("end-poem-screen").classList.add("hidden");
      GAME.state = "playing";
      requestLock();
    };

    // Chat Input Events
    const chatInputEl = document.getElementById("chat-input");
    chatInputEl.addEventListener("input", updateCommandSuggestions);
    chatInputEl.addEventListener("keydown", e => {
      if (e.key === "Enter") {
        e.preventDefault();
        executeCommand(chatInputEl.value);
        closeChat();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeChat();
      } else if (e.key === "Tab") {
        e.preventDefault();
        const firstChip = document.querySelector("#chat-suggestions .cmd-chip");
        if (firstChip) {
          chatInputEl.value = firstChip.textContent;
          updateCommandSuggestions();
        }
      }
    });
    document.getElementById("btn-chat-send").onclick = () => {
      executeCommand(chatInputEl.value);
      closeChat();
    };

    // Keyboard & Mouse Controls
    let qDropHeld = false, qDropCooldown = 0;
    function dropHeldItem(amount = 1) {
      const held = PLAYER.inv[PLAYER.hotbarIdx];
      if (!held) return;
      const dir = getLookDir();
      const count = Math.min(amount, held.count);
      spawnDrop(PLAYER.pos.x + dir.x * 1.2, PLAYER.pos.y + 1.2, PLAYER.pos.z + dir.z * 1.2, held.id, count);
      consumeHeld(count);
    }
    window.addEventListener("keydown", e => {
      if ((e.ctrlKey || e.metaKey) && ["KeyS", "KeyD", "KeyP", "KeyR", "KeyF", "KeyG", "KeyU", "KeyH", "KeyJ", "KeyW"].includes(e.code)) {
        e.preventDefault();
      }
      if (e.code === "Tab") {
        e.preventDefault();
        if (GAME.state === "playing" && document.activeElement !== chatInputEl) {
          const tabEl = document.getElementById("tab-player-list");
          if (tabEl.classList.contains("hidden")) {
            renderTabPlayerList();
            tabEl.classList.remove("hidden");
          }
        }
        return;
      }

      if (document.activeElement === chatInputEl || document.activeElement === document.getElementById("creative-search")) return;

      if (e.code === "KeyW" && !keys["KeyW"]) {
        const now = performance.now();
        if (now - lastWPress < 280) doubleWSprint = true;
        lastWPress = now;
      }
      if (e.code === "Space" && !keys["Space"] && (GAME.gamemode === "creative" || GAME.gamemode === "spectator")) {
        const now = performance.now();
        if (now - lastSpacePress < 280) {
          PLAYER.flying = !PLAYER.flying;
          showBanner(PLAYER.flying ? "Режим полёта: ВКЛ" : "Режим полёта: ВЫКЛ");
        }
        lastSpacePress = now;
      }

      keys[e.code] = true;

      if (e.code === "KeyF" && !e.ctrlKey && (GAME.state === "playing" || GAME.state === "gui")) {
        swapOffhandItem();
      } else if (e.code === "KeyE") {
        if (GAME.state === "playing") openGUI("inventory");
        else if (GAME.state === "gui") closeGUI();
      } else if (e.code === "Escape") {
        document.getElementById("tab-player-list").classList.add("hidden");
        if (GAME.state === "gui") closeGUI();
        else if (GAME.state === "playing") {
          GAME.state = "paused";
          document.exitPointerLock?.();
          document.getElementById("pause-menu").classList.remove("hidden");
        }
      } else if (e.code === "Slash" && GAME.state === "playing") {
        e.preventDefault();
        openChat("/");
      } else if (e.code === "KeyT" && GAME.state === "playing") {
        e.preventDefault();
        openChat("");
      } else if (e.code === "F3") {
        e.preventDefault();
        document.getElementById("f3-overlay").classList.toggle("hidden");
      } else if (e.code === "F5") {
        e.preventDefault();
        GAME.cameraMode = (GAME.cameraMode + 1) % 3;
      } else if (e.code === "F11") {
        e.preventDefault();
        if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => {});
        else document.exitFullscreen?.().catch(() => {});
      } else if (e.code === "KeyQ" && GAME.state === "playing") {
        dropHeldItem(1);
        qDropHeld = true; qDropCooldown = 0;
      } else if (e.code.startsWith("Digit")) {
        const n = Number(e.code.replace("Digit", ""));
        if (n >= 1 && n <= 9) {
          PLAYER.hotbarIdx = n - 1;
          GAME.equipAnim = 1.0;
          updateHotbarUI();
        }
      }
    });

    window.addEventListener("keyup", e => {
      keys[e.code] = false;
      if (e.code === "KeyQ") qDropHeld = false;
      if (e.code === "Tab") {
        document.getElementById("tab-player-list").classList.add("hidden");
      }
    });

    window.addEventListener("wheel", e => {
      if (GAME.state !== "playing") return;
      PLAYER.hotbarIdx = (PLAYER.hotbarIdx + (e.deltaY > 0 ? 1 : -1) + 9) % 9;
      GAME.equipAnim = 1.0;
      updateHotbarUI();
    });

    canvas.addEventListener("mousedown", e => {
      if (GAME.state !== "playing") return;
      if (!document.getElementById("chat-input-row").classList.contains("hidden")) return;
      if (document.pointerLockElement !== canvas) {
        requestLock();
        return;
      }
      if (e.button === 0) {
        miningState.active = true;
        performLeftClickAction();
      } else if (e.button === 2) {
        performRightClickDown();
      }
    });

    window.addEventListener("mouseup", e => {
      if (e.button === 0) miningState.active = false;
      if (e.button === 2) performRightClickUp();
    });

    window.addEventListener("contextmenu", e => e.preventDefault());

    window.addEventListener("mousemove", e => {
      if (GAME.state === "playing" && document.pointerLockElement === canvas) {
        PLAYER.yaw -= e.movementX * 0.0022 * GAME.mouseSens;
        PLAYER.pitch = Math.max(-Math.PI / 2 + 0.02, Math.min(Math.PI / 2 - 0.02, PLAYER.pitch - e.movementY * 0.0022 * GAME.mouseSens));
        camera.rotation.order = "YXZ";
        camera.rotation.z = 0;
      }
    });

    window.addEventListener("resize", () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // =========================================================================
    // 18. INITIALIZATION & MAIN LOOP
    // =========================================================================
    applyReferenceAtlas();
    createIsometricBlockIcons();
    // Do not load modern remote textures: maksik.txt is the single visual source of truth.

    GAME.world = new VoxelWorld(12345);
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) GAME.world.rebuildChunkMesh(dx, dz);
    }

    let lastTime = performance.now();
    let chunkTimer = 0, hudTimer = 0, spawnTimer = 0, fpsFrames = 0, fpsTimer = 0;
    let adaptiveSampleFrames = 0, adaptiveSampleTime = 0;
    let adaptivePixelRatio = Math.min(window.devicePixelRatio || 1, 0.85);

    function animate(now) {
      requestAnimationFrame(animate);
      const dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;

      fpsFrames++;
      fpsTimer += dt;
      adaptiveSampleFrames++;
      adaptiveSampleTime += dt;
      if (adaptiveSampleTime >= 2.5) {
        const measuredFps = adaptiveSampleFrames / adaptiveSampleTime;
        const previousRatio = adaptivePixelRatio;
        if (measuredFps < 45) adaptivePixelRatio = Math.max(0.5, adaptivePixelRatio - 0.08);
        else if (measuredFps > 58) adaptivePixelRatio = Math.min(Math.min(window.devicePixelRatio || 1, GAME.graphicsQuality === "high" ? 1 : 0.9), adaptivePixelRatio + 0.04);
        if (Math.abs(previousRatio - adaptivePixelRatio) >= 0.04) {
          renderer.setPixelRatio(adaptivePixelRatio);
          renderer.setSize(window.innerWidth, window.innerHeight);
        }
        adaptiveSampleFrames = 0;
        adaptiveSampleTime = 0;
      }
      if (fpsTimer >= 0.5) {
        document.getElementById("f3-fps").textContent = `FPS: ${Math.round(fpsFrames / fpsTimer)}`;
        document.getElementById("f3-seed").textContent = `Seed: ${GAME.world?.seed || 0}`;
        document.getElementById("f3-chunks").textContent = `Chunks: ${GAME.world?.meshes.size || 0} (Q: ${GAME.world?.meshQueue.length || 0})`;
        document.getElementById("f3-mobs").textContent = `Entities: ${entities.length}`;
        if (GAME.world?.structures.stronghold) {
          const sh = GAME.world.structures.stronghold;
          document.getElementById("f3-stronghold").textContent = `Stronghold: X=${sh.x}, Z=${sh.z}`;
        }
        fpsFrames = 0;
        fpsTimer = 0;
      }

      // Smooth time-budgeted chunk building (eliminates micro-stutters)
      processChunkMeshQueue(1);

      // Update break particles
      for (let i = breakParticles.length - 1; i >= 0; i--) {
        const p = breakParticles[i];
        p.life -= dt;
        p.vel.y -= 12 * dt;
        p.mesh.position.addScaledVector(p.vel, dt);
        if (p.life <= 0) {
          scene.remove(p.mesh);
          breakParticles.splice(i, 1);
        }
      }

      if (GAME.state === "playing") {
        if (qDropHeld) {
          qDropCooldown += dt;
          if (qDropCooldown >= 0.18) { qDropCooldown = 0; dropHeldItem(1); }
        }
        tickPlayerPhysics(dt);
        saveClock += dt;
        if (saveClock >= 5) { saveClock = 0; saveCurrentWorld(); }
        updateRaycast();
        tickMining(dt);
        tickEntities(dt);
        if (GAME.fishing?.active && !GAME.fishing.bite) {
          GAME.fishing.timer -= dt;
          if (GAME.fishing.timer <= 0) {
            GAME.fishing.bite = true;
            GAME.fishing.mesh.position.y -= 0.18;
            showBanner("ПОКЛЁВКА! Нажми ПКМ, чтобы вытащить!");
            SFX.pickup();
          }
        }
        tickMultiplayer(dt);

        chunkTimer += dt;
        if (chunkTimer >= 0.45) {
          chunkTimer = 0;
          updateChunksAroundPlayer(false);
        }

        hudTimer += dt;
        if (hudTimer >= 0.25) {
          hudTimer = 0;
          updateHUD();
        }

        spawnTimer += dt;
        if (spawnTimer >= 6.0 && entities.length < 16) {
          spawnTimer = 0;
          const ang = Math.random() * Math.PI * 2;
          const sx = PLAYER.pos.x + Math.cos(ang) * 14;
          const sz = PLAYER.pos.z + Math.sin(ang) * 14;

          if (GAME.world.dimension === "overworld") {
            const isNight = GAME.timeOfDay > 12500 && GAME.timeOfDay < 23000;
            const sy = GAME.world.getSurfaceHeight(sx, sz);
            if (sy >= 27) {
              if (isNight && GAME.difficulty !== "peaceful") {
                const hostiles = ["zombie", "skeleton", "creeper", "enderman"];
                spawnMob(hostiles[Math.floor(Math.random() * hostiles.length)], sx, sy + 1, sz);
              } else {
                const passives = ["cow", "pig", "sheep", "chicken"];
                spawnMob(passives[Math.floor(Math.random() * passives.length)], sx, sy + 1, sz);
              }
            }
          } else if (GAME.world.dimension === "nether" && GAME.difficulty !== "peaceful") {
            const netherMobs = ["blaze", "wither_skeleton"];
            spawnMob(netherMobs[Math.floor(Math.random() * netherMobs.length)], sx, 22, sz);
          }
        }
      }

      updateEnvironment(dt);
      updateCameraAndViewmodel(dt);
      renderer.render(scene, camera);
    }

    window.addEventListener("pagehide", saveCurrentWorld);
    window.addEventListener("beforeunload", saveCurrentWorld);
    window.onload = () => { renderSavedWorlds(); requestAnimationFrame(animate); };
